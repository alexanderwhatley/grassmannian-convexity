# A halfspace hierarchy for the (3,7) problem

Let \(M=(v_1,\dots,v_7)\in\mathbb R^{3\times7}\), with all 35 ordered
three-column minors nonzero. Assume positive elementary moves
\(v_j\mapsto v_j+t v_{j+1}\), \(t>0\), and count sign changes of
\(p_{123}=\det(v_1,v_2,v_3)\).

## Theorem

If the indicated **initial** suffix lies in a common open halfspace, every
finite generic positive-move trajectory has at most the following number
of target sign changes:

| Common open halfspace | Bound | Sharpness |
|---|---:|---|
| \(v_3,\dots,v_7\) | 12 | At least 10; 12 not established here |
| \(v_2,\dots,v_7\) | 9 | Sharp: exact rational example below |
| \(v_1,\dots,v_7\) | 8 | Sharp: exact rational example below |

The halfspace may be any open halfspace through the origin; equivalently,
there exists a linear functional \(\omega\) that is strictly positive on
the indicated vectors. The same functional remains positive on the suffix
throughout every positive-move trajectory. This is stronger than the
previous hypothesis that \(p_{367},p_{467},p_{567}\) have the same sign.

## Proof

Fix such an \(\omega\), set \(H=\ker\omega\), and write
\(x_i=\omega(v_i)\). Generic perturbation allows us to separate all
finite events and assume the nonzero scalar chart conditions wherever
needed. On a chart where all \(x_i\ne0\), set
\[
w_i=v_{i+1}-\frac{x_{i+1}}{x_i}v_i\in H,\qquad 1\le i\le6.
\]
Choose an orientation of \(H\) and a vector \(e\) with \(\omega(e)=1\).
Then, up to the fixed sign of the chosen ambient orientation,
\[
p_{123}=x_1\det_H(w_1,w_2),\qquad
p_{567}=x_5\det_H(w_5,w_6).\tag{1}
\]
Because \(p_{567}\) is invariant under all elementary moves and \(x_5>0\),
the sign of \(\det_H(w_5,w_6)\) is constant; orient \(H\) so it is positive.

A move at \(j=1\) positively rescales \(w_1\) inside the chart. For
every \(2\le j\le6\), put
\(\alpha=x'_j/x_j=1+t x_{j+1}/x_j>0\). Direct substitution gives
\[
w'_{j-1}=\alpha w_{j-1}+t w_j,\qquad
w'_j=\alpha^{-1}w_j,\tag{2}
\]
with all the other \(w_i\) unchanged. This includes \(j=6\): both
\(w_5\) and \(w_6\) are updated by (2). Thus the six-vector projected
trajectory follows positive rank-two moves up to positive column rescalings.

The rank-two cyclic-word rank from Saldanha–Shapiro–Shapiro takes values
in \(\{0,\ldots,8\}\), is nonincreasing under these moves, and drops by
at least one at each change in \(\det_H(w_1,w_2)\). Two additional facts
of the same construction are used: deleting the first vector changes the
rank by 0, 1, or 2, and its parity is the sign of the first pair determinant
relative to the fixed positive last-pair determinant.

At a generic \(x_1\)-pole only \(w_1\) reverses direction. The suffix
rank is unchanged, while full-rank parity flips. Both full ranks are within
0, 1, or 2 of the suffix rank, so the upward jump is at most 1.

At a generic \(x_2\)-pole, deleting \(w_1\) leaves a five-vector system
whose first vector reverses, so its rank jumps upward by at most 1 by the
same argument. Reinserting \(w_1\) can increase the jump by at most 2.
However the full rank has the same parity before and after: \(p_{123}\)
is constant during move 2, \(x_1\) has no zero there, and (1) applies on
both sides. Consequently the upward jump is at most 2, rather than 3.

If \(x_3,\dots,x_7>0\) initially, they remain positive. Then \(x_2\)
can change sign at most once, and \(x_1\) at most twice. The target-flip
count is therefore at most \(8+2\cdot1+1\cdot2=12\). If
\(x_2,\dots,x_7>0\), only \(x_1\) can change sign, at most once,
giving \(8+1=9\). If every \(x_i>0\), no poles occur, giving 8.
Finite generic perturbations preserve the strict halfspace and all strict
target signs around an arbitrary finite collection of crossings. \(\square\)

## Strict improvement over the previous sufficient condition

Take the columns
\[
\begin{array}{lll}
v_1=(-1,1,4),&v_2=(-1,5,-4),&v_3=(1,0,1),\\
v_4=(1,2,-2),&v_5=(1,5,3),&v_6=(1,0,0),&v_7=(1,1,0).
\end{array}
\]
All 35 three-column minors are nonzero. The first-coordinate functional
is positive on \(v_3,\dots,v_7\), yet
\((p_{367},p_{467},p_{567})=(1,-2,3)\). The new theorem applies even
though the previous equal-sign test fails. `verify_halfspace_example.py`
checks these assertions exactly.

## Recognizing a common halfspace from signs of minors

For generic columns, the suffix \(v_s,\ldots,v_7\) lies in a common
open halfspace **if and only if**, for every four indices
\(s\le a<b<c<d\le7\), the four signs
\[
\bigl(\operatorname{sgn}p_{bcd},-\operatorname{sgn}p_{acd},
\operatorname{sgn}p_{abd},-\operatorname{sgn}p_{abc}\bigr)
\]
are not all equal. The four coefficients in that expression give the
unique dependence
\[
p_{bcd}v_a-p_{acd}v_b+p_{abd}v_c-p_{abc}v_d=0.
\]
If they all have one sign, no linear functional is positive on the four
columns. Conversely, Gordan's theorem rules out a positive functional
exactly when the origin belongs to the convex hull of the suffix vectors;
Carathéodory supplies a positive dependence supported on at most four.
Since every three-column minor is nonzero, such a minimal dependence has
exactly four columns and the above cofactor signs are all equal. Thus this
condition requires only the original 35 Plücker signs, although the proof
uses a common *fixed* functional along the whole trajectory.

## Exact sharpness certificates for 9 and 8

`sharp_nine_generic_trajectory.json` gives seven rational initial columns,
one fixed rational functional, and 37 strictly positive elementary-move
times. `verify_sharp_nine.py`, using Python's standard library and exact
rational arithmetic, verifies every 3×3 minor is nonzero at all 38 vertices,
the functional is positive on columns 2 through 7 at every vertex, and
there are exactly 9 target sign changes. After the third move, the same
functional is positive on **all seven** columns, and the remaining 34 moves
give exactly 8 target changes. This proves sharpness of both bounds.

The construction starts with a rank-two 1-change path, a scalar-pole move
that reverses the first projected direction without changing the target,
and then an 8-change rank-two path. `verify_rank2_nine.py` checks the
projected schedule; `lift_nine_to_rank3.py` creates the rational lift and
an explicit generic rational perturbation. The final verifier does not rely
on the construction or on floating-point arithmetic.

`suffix5_extended_trajectory.json` gives a 149-move generic rational
trajectory with **10** target changes and one fixed functional positive on
\(v_3,\dots,v_7\). It was formed by adding a backward extension to the
sharp-nine example and reversing that extension. Two independent checkers,
`verify_suffix5_lower10.py` and `verify_suffix5_lower10_fast.py`, verify
all positive move times, all 35 minors at every vertex, the common
halfspace, and the 10 target changes exactly. The latter uses primitive
integer coordinates as an additional check against rational arithmetic.
At the initial vertex, \((\operatorname{sgn}p_{167},\dots,
\operatorname{sgn}p_{567})=(+,-,+,-,+)\). Thus the maximum for the
suffix-five class is between 10 and 12. Whether 11 or 12 is attainable
remains open in this note.
