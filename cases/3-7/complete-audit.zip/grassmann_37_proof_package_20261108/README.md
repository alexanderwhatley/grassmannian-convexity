# Grassmann (3,7): complete research audit

Status: candidate computer-assisted proof; the mathematical coverage and
perturbation arguments and the software remain subject to outside review.
Start with `Proof_and_Sharp_Bounds.md` and `Review_Guide.md`. The elementary
28-move witness is printed in the report; the exact simple-moment example
is `trajectory_search_20261108/moment_curve_28_exact.json`.

* `./run_all.sh` checks the main 52-sign certificates, older independent
  audits, the 28-move lower bound, and many exact examples. Its successful
  frozen-run output is `verification_final_complete.log`.
* `./run_supplement.sh` checks both independent 41-sign potential audits,
  12 additional exact 40-move constructions, the shortest simple-moment
  witness, and the latest 28-move refinements. Its successful output is
  `verification_supplement_final4.log`.
* `grassmann_37_continuation/history_20261108/41_sign_unfiltered_certificate.md`
  explains the 41-sign result and its hidden-state enumeration.
* `NEXT_STEPS.md` records the remaining review obligations and open questions.

Both scripts require Python 3 and a GCC/Clang-compatible C++17 compiler;
the complete audit also uses SymPy. Run with assertions enabled. The smaller
separate archive has a data-free verifier and a lower-memory option.
