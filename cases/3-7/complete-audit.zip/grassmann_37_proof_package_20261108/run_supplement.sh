#!/usr/bin/env bash
set -euo pipefail
root="$(cd -- "$(dirname -- "$0")" && pwd)"
build_dir="$(mktemp -d)"
trap 'rm -rf -- "$build_dir"' EXIT
cxx="${CXX:-c++}"
python3 "$root/grassmann_37_continuation/new_work/verify_compact_witness.py" "$root/trajectory_search_20261108/moment_curve_28_exact.json"
python3 "$root/m1_analytic_20261108/verify_28_witness_direct.py" "$root/trajectory_search_20261108/moment_curve_28_exact.json"
python3 "$root/grassmann_37_continuation/history_20261108/verify_optimal_p345.py"
python3 "$root/m1_analytic_20261108/verify_3x5_group_rank_jump.py"
python3 "$root/m1_analytic_20261108/verify_rank2_cyclic_jump.py"
for file in "$root"/m1_analytic_20261108/constructive_40_certificates/certificate_*.json; do
  python3 "$root/m1_analytic_20261108/verify_constructive_transfer_40.py" "$file" >/dev/null
done
printf 'PASS independently replayed 40-move certificates in all 12 chambers\n'
base="$root/grassmann_37_continuation/history_20261108"
"$cxx" -O3 -std=c++17 -pthread "$base/verify_rank41_unfiltered_all_edges.cpp" -o "$build_dir/verify_rank41"
"$build_dir/verify_rank41" "$base/rank_41_unfiltered.bin"
"$cxx" -O3 -std=c++17 -pthread "$root/m1_analytic_20261108/verify_projected41_bound_independent.cpp" -o "$build_dir/verify_rank41_independent"
cd "$root/m1_analytic_20261108"
"$build_dir/verify_rank41_independent"
python3 "$root/m1_analytic_20261108/verify_3x5_chain_formula.py"
python3 "$root/m1_analytic_20261108/verify_moment_first_parameter.py"
python3 "$root/m1_analytic_20261108/verify_moment_covector.py"
python3 "$root/m1_analytic_20261108/audit_moment_first_shear_variation.py"
python3 "$root/trajectory_search_20261108/verify_moment_integer_word_obstruction.py"
printf '\nAll supplementary checks passed.\n'
