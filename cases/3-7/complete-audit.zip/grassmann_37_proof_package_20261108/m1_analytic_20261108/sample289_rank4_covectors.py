#!/usr/bin/env python3
"""Exact arrangement cells of rank-4 positive covectors for sample 289."""
from fractions import Fraction as Q
from pathlib import Path
from itertools import combinations
from math import gcd,lcm
import sys,json,contextlib,io
sys.path.insert(0,'../analytic_agent')
with contextlib.redirect_stdout(io.StringIO()):
 from optimize_fixed_functional import normal,val,clip,det,signature_to_rank,G
v=[None]+[tuple(map(Q,x)) for x in [[-79,-53,1],[-18,-70,1],[22,36,1],[-8,62,1],[51,-99,1],[86,-24,1],[89,38,1]]]
def p(a,b,c):return det(v[a],v[b],v[c])
scale=p(5,6,7);assert scale>0
coeff=[None]+[(p(i,6,7)/scale,p(5,i,7)/scale,p(5,6,i)/scale) for i in range(1,8)]
affine=lambda c:(c[0]-c[2],c[1]-c[2],c[2])
xi=[None]+[affine(c) for c in coeff[1:]]
def sub(u,s,v,t):return tuple(s*u[i]-t*v[i] for i in range(3))
lines=set();pair={}
for i in range(1,5):
 q=normal(xi[i]);
 if q:lines.add(q)
for i in range(1,7):
 for j in range(i+1,7):
  L=sub(xi[j],p(i,i+1,j+1),xi[j+1],p(i,i+1,j));pair[i,j]=L
  q=normal(L)
  if q:lines.add(q)
polys=[[(Q(0),Q(0)),(Q(1),Q(0)),(Q(0),Q(1))]]
for L in sorted(lines):
 out=[]
 for poly in polys:
  z=[val(L,p) for p in poly]
  if any(t>0 for t in z) and any(t<0 for t in z):out.extend((clip(poly,L,1),clip(poly,L,-1)))
  else:out.append(poly)
 polys=out
sig_to_word={tuple(G.orient(w,i,j) for i,j in combinations(range(1,7),2)):w for w in G.words}
res=[]
for poly in polys:
 c=tuple(sum(z[k] for z in poly)/len(poly) for k in range(2));X=[None]+[val(xi[i],c) for i in range(1,8)]
 if not all(x>0 for x in X[1:]):continue
 sig=tuple(1 if val(L,c)>0 else -1 for L in pair.values());R=signature_to_rank[sig]
 if R!=4:continue
 # Solve omega dot v_i = X_i for i=5,6,7 using reciprocal row cross products.
 def cross(a,b):return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
 c1,c2,c3=cross(v[6],v[7]),cross(v[7],v[5]),cross(v[5],v[6]);om=[(X[5]*c1[i]+X[6]*c2[i]+X[7]*c3[i])/scale for i in range(3)]
 d=lcm(*(q.denominator for q in om));o=[int(q*d) for q in om];g=gcd(*map(abs,o));o=[z//g for z in o]
 assert all(sum(o[j]*v[i][j] for j in range(3))>0 for i in range(1,8))
 word=sig_to_word[sig];assert G.rank(word)==4
 res.append({'word':list(word),'omega':o,'u5':str(c[0]),'u6':str(c[1]),'u7':str(1-c[0]-c[1])})
print('rank4_positive_cells',len(res),'distinct_words',len({tuple(z['word']) for z in res}))
Path('sample289_rank4_covectors.json').write_text(json.dumps(res,indent=2)+'\n')
for i,z in enumerate(res):print(i,'omega',z['omega'],'word',z['word'])
