#!/usr/bin/env python3
"""Independent exact 13-shear witness and sign-only residual checks.

Uses only Python's standard library. The rank-two angular-rank upper bound is
an external mathematical theorem; the integer cyclic-word computation here
checks its input and value exactly.
"""
from fractions import Fraction as Q
from functools import cmp_to_key
from itertools import combinations,permutations

V0=[[-89,3,1],[-78,-49,1],[-12,-16,1],[-79,74,1],[-89,-80,1],[8,-41,1],[5,-2,1]]
moves=[(1,Q(7)),(4,Q(1)),(3,Q(5,2)),(4,Q(18)),(3,Q(3,10)),(2,Q(1,6)),(3,Q(3,5)),(1,Q(8,3)),(5,Q(1)),(4,Q(10)),(3,Q(12,5)),(2,Q(1,40)),(3,Q(18))]
I=list(combinations(range(7),3));idx={a:i for i,a in enumerate(I)}
def det(a,b,c):return a[0]*(b[1]*c[2]-b[2]*c[1])-b[0]*(a[1]*c[2]-a[2]*c[1])+c[0]*(a[1]*b[2]-a[2]*b[1])
def minor(v):return [det(*(v[z] for z in a)) for a in I]
p=minor(V0);assert all(p) and p[0]>0 and p[-1]>0
# Independently reconstruct the 52-bit sign key.
def P(a,b,c):return p[idx[(a-1,b-1,c-1)]]
F=[(1,2,3,4),(1,3,2,4),(1,4,2,3),(1,2,3,5),(1,3,2,5),(1,5,2,3),(1,2,4,5),(1,4,2,5),(1,5,2,4),(1,3,4,5),(1,4,3,5),(1,5,3,4),(2,3,4,5),(2,4,3,5),(2,5,3,4)]
fs=[P(a,b,6)*P(c,d,7)-P(a,b,7)*P(c,d,6) for a,b,c,d in F]
gs=[P(1,2,5)*P(3,4,j)-P(1,2,j)*P(3,4,5) for j in (6,7)]
assert all(fs+gs)
key=sum((v>0)<<i for i,v in enumerate(p+fs+gs));assert key==331055874502971
# The best of all 21 pencil lower bounds is 2.
def variation(z):return sum((a>0)!=(b>0) for a,b in zip(z,z[1:]))
Pmax=max(variation([p[0]]+[p[idx[tuple(sorted(s+(j,)))]] for j in range(7) if j not in s]+[p[-1]]) for s in combinations(range(7),2))
assert Pmax==2
# Independently test all 5,040 ordered power-of-two weight assignments.
feasible=[[u for u,K in enumerate(I) if all(a<=b for a,b in zip(T,K))] for T in I]
covers=[]
for a,T in enumerate(I):
 for j in T:
  if j+1<7 and j+1 not in T:covers.append((a,idx[tuple(sorted(set(T)-{j}|{j+1}))]))
assert len(covers)==60
for order in permutations(range(7)):
 w=[0]*7
 for h,j in enumerate(order):w[j]=1<<h
 scores=[sum(w[j] for j in T) for T in I]
 dom=[max(choices,key=scores.__getitem__) for choices in feasible]
 assert not (p[dom[0]]<0 and any(p[dom[a]]>0>p[dom[b]] for a,b in covers))
# Fixed positive covector omega=z; sort projected rays exactly, no atan2.
w=[(V0[j+1][0]-V0[j][0],V0[j+1][1]-V0[j][1]) for j in range(6)]
rays=[(a,b,i+1) for i,(a,b) in enumerate(w)]+[(-a,-b,-i-1) for i,(a,b) in enumerate(w)]
def cmp(a,b):
 ha=a[1]>0 or (a[1]==0 and a[0]>=0);hb=b[1]>0 or (b[1]==0 and b[0]>=0)
 if ha!=hb:return -1 if ha else 1
 cross=a[0]*b[1]-a[1]*b[0]
 assert cross!=0
 return -1 if cross>0 else 1
rays.sort(key=cmp_to_key(cmp));word=[x[2] for x in rays];r=word.index(1);word=word[r:]+word[:r]
assert word==[1,-3,5,2,-4,6,-1,3,-5,-2,4,-6]
pos=[word.index(i) for i in range(1,7)];increments=[]
for a,b in zip(pos,pos[1:]):
 d=(b-a)%12
 assert d not in (0,6)
 if d>6:d-=12
 increments.append(d)
assert increments==[3,4,3,4,3]
# Single positive angular run; its rank is 2*floor(17/6)=4.
assert 2*(sum(increments)//6)==4
# Replay the 13 positive shears directly on 3-vectors, not corner-cutting.
v=[[Q(x) for x in col] for col in V0];old=minor(v)[0]>0;flips=[]
for step,(j,t) in enumerate(moves,1):
 assert t>0
 v[j-1]=[v[j-1][a]+t*v[j][a] for a in range(3)]
 pnew=minor(v);assert all(pnew),(step,'non-generic vertex')
 now=pnew[0]>0
 if now!=old:flips.append(step)
 old=now
assert flips==[5,7,11,13] and all(x>0 for x in pnew)
print('PASS exact 52-feature key',key,'and m=0 via omega=z')
print('PASS pencil lower bound 2 and no 5040-weight sign-dominance witness')
print('PASS exact projected cyclic word',word,'rank 4')
print('PASS 13 exact rational positive shears, all 35 minors strict at 14 vertices')
print('PASS target flips',flips,'and final all minors positive')
