#!/usr/bin/env python3
"""Independently check two GP sign implications on formal and real states.

The 48 orientations of three disjoint pairs, for each of G56 and G57,
are generated independently from pair permutations and pair reversals.
"""
from collections import Counter
from itertools import combinations,permutations,product
from pathlib import Path
from random import Random
P=list(combinations(range(1,8),3));pid={p:i for i,p in enumerate(P)}
def triple_mask(terms):
 mask=flip=0
 for abc in terms:
  mask ^= 1<<pid[tuple(sorted(abc))]
  flip ^= sum(abc[i]>abc[j] for i in range(3) for j in range(i+1,3))&1
 return mask,flip
def rules():
 for e,gbit in [(6,50),(7,51)]:
  base=[(1,2),(3,4),(5,e)]
  for perm in permutations(range(3)):
   pp=sum(perm[i]>perm[j] for i in range(3) for j in range(i+1,3))&1
   for flip in product(range(2),repeat=3):
    ps=[base[perm[i]][::-1] if flip[i] else base[perm[i]] for i in range(3)]
    (a,b),(c,d),(i,j)=ps;gf=pp^sum(flip)%2
    A,af=triple_mask([(a,b,c),(a,d,i),(a,b,i),(a,c,d)])
    B,bf=triple_mask([(a,c,i),(d,i,j),(a,i,j),(c,d,i)])
    C,cf=triple_mask([(a,b,d),(c,i,j)])
    # bit convention 1=positive; conclusion has three factors (G,p,p).
    parent=(A,af,B,bf,C^(1<<gbit),1^cf^gf)
    D,df=triple_mask([(a,b,i),(a,c,d),(d,i,j),(a,b,d),(a,i,j),(c,d,i)])
    E,ef=triple_mask([(a,d,i),(a,b,i),(a,c,d),(d,i,j)])
    # Conclusion has five factors (G,p,p,p,p).
    short=(D,df,E^(1<<gbit),1^ef^gf)
    yield e,parent,short
R=list(rules());assert len(R)==96
par=lambda x:x.bit_count()&1
def violation_parent(k,r):
 a,af,b,bf,c,cf=r
 return par(k&a)==af and par(k&b)==bf and par(k&c)!=cf
def violation_short(k,r):
 a,af,b,bf=r
 return par(k&a)==af and par(k&b)!=bf

def det(a,b,c):return a[0]*(b[1]*c[2]-b[2]*c[1])-a[1]*(b[0]*c[2]-b[2]*c[0])+a[2]*(b[0]*c[1]-b[1]*c[0])
def actual_key(v):
 def p(a,b,c):return det(v[a-1],v[b-1],v[c-1])
 val=[p(*x) for x in P]
 val += [p(1,2,5)*p(3,4,j)-p(1,2,j)*p(3,4,5) for j in (6,7)]
 if not all(val):return None
 return sum(1<<i for i,x in enumerate(val[:35]) if x>0)|sum(1<<(50+i) for i,x in enumerate(val[35:]) if x>0)
rng=Random(821413);n=0
while n<2000:
 v=[[rng.randint(-30,30) for _ in range(3)] for _ in range(7)];k=actual_key(v)
 if k is None:continue
 for e,parent,short in R:
  assert not violation_parent(k,parent),(n,e,parent)
  assert not violation_short(k,short),(n,e,short)
 n+=1
print('PASS both rule masks on',n,'exact random real matrices, all 96 oriented G instances')
m4=[tuple(map(int,line.split())) for line in Path('m4_augmented_keys.txt').read_text().splitlines()]
assert len(m4)==36
for mode,fn,off in [('parent',violation_parent,1),('two-term',violation_short,2)]:
 tally=Counter()
 for k,h in m4:
  bad=any(fn(k,r[off]) for r in R);tally[h,bad]+=1
 print(mode,'m4 (H,rule_violation) counts',dict(tally))
 assert tally[12,False]==12 and tally[10,True]==24 and not tally[12,True] and not tally[10,False]
traps=[int(x) for x in Path('h0_negative_keys.txt').read_text().splitlines()];assert len(traps)==25519
for mode,fn,off in [('parent',violation_parent,1),('two-term',violation_short,2)]:
 tally=Counter()
 for k in traps:
  failed=[r[0] for r in R if fn(k,r[off])];tally['excluded']+=bool(failed);tally['G56']+=6 in failed;tally['G57']+=7 in failed
 print(mode,'H0-negative traps',len(traps),'excluded',tally['excluded'],'by G56',tally['G56'],'by G57',tally['G57'])
 assert tally['excluded']==len(traps)
