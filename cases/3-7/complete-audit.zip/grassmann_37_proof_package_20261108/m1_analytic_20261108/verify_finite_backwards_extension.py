#!/usr/bin/env python3
"""Exact example of finite positive-word backward extension to m=4."""
from fractions import Fraction as Q
from itertools import combinations
V=[[5,1,6],[-3,0,-7],[3,0,-7],[4,-1,-7],[3,-7,-3],[3,4,1],[1,-1,7]]
def det(a,b,c):return a[0]*(b[1]*c[2]-b[2]*c[1])-a[1]*(b[0]*c[2]-b[2]*c[0])+a[2]*(b[0]*c[1]-b[1]*c[0])
P=list(combinations(range(1,8),3))
def ps(v):return {I:det(*(v[j-1] for j in I)) for I in P}
if det(*V[4:7])<0:V=[[-c[0],c[1],c[2]] for c in V]
M=[[Q(x) for x in v] for v in V];assert all(ps(M).values()) and ps(M)[5,6,7]>0
def act(v,j,t):
 v=[q[:] for q in v];v[j-1]=[v[j-1][r]+t*v[j][r] for r in range(3)];return v
for k in range(1,15):
 e=Q(1,10**k);d=[Q(1)]*4+[e]*3
 moves=[(j,Q(1000+6*row+j,1000)*d[j-1]/d[j]) for row in range(12) for j in range(1,7)]
 begin=[v[:] for v in M]
 for j,t in reversed(moves):begin=act(begin,j,-t)
 p=ps(begin)
 if all(v and ((v>0)==(sum(I)%2==0)) for I,v in p.items()):
  end=[v[:] for v in begin];strict=True
  for j,t in moves:
   end=act(end,j,t)
   if not all(ps(end).values()):strict=False;break
  if strict:
   assert end==M;print('PASS exact 72 positive moves from alternating m4 start to chosen generic matrix; epsilon=10^-',k,sep='');break
else:raise AssertionError('no successful epsilon in search')
