# A sign-dominance criterion for at least four future changes

This note supplements `pencil_variation_lower_bound.md` and
`rank_one_ideal_theorem.md`. Its criterion applies in every dimension, uses
only maximal-minor signs, and provides a genuine finite positive-move path
for every actual matrix satisfying it. The `(3,7)` counts below use the
separate certified upper-bound graph.

## Criterion

Let `M` be generic, with positive target `p_[k]` and positive last minor.
Choose a real weight `w_i` for each column so every two `k`-subsets have
different total weights. For each `k`-subset `T`, let
\[
 \kappa(T)=\arg\max_{K\ge T}\sum_{i\in K}w_i.
\]
If there is a cover `A<B` in componentwise subset order with
\[
 p_{\kappa([k])}<0,\qquad
 p_{\kappa(A)}>0>p_{\kappa(B)},\tag{1}
\]
then `r(M)>=4`.

**Proof.** With `L_0` as in §2 of `rank_one_ideal_theorem.md`, put
`D_t=diag(t^{w_i})` and apply the positive word `D_t^{-1}L_0D_t`.
In Cauchy–Binet, all terms indexed by `K` not at least `T` vanish; by
uniqueness of `kappa(T)`, the initial minor `p_kappa(T)` gives the sign of
the transformed `p_T` for every sufficiently small `t>0`. Hence at the
endpoint the target is negative and the cover `A<B` has a positive lower
and negative upper minor. A finite perturbation makes every recorded minor
strict while preserving these endpoint signs. The first endpoint requires at
least one change from the positive initial target; by the general rank-one
theorem, the negative-target endpoint has at least three further changes.
The last minor is unchanged and positive throughout. ∎

An exhaustive **sufficient** test needs only the `n!` weight assignments
obtained by permuting distinct powers of two. These assignments need not
represent every possible real weight: a state that fails them remains
unresolved. For `(3,7)`, a single such assignment induces one of 1,066
unique maps `kappa`.

The same argument applies after a finite composition of such sign maps. It
also applies after any very large individual shear: at a generic current
matrix, a sufficiently large `U_j(t)` replaces the sign of each active
minor `p_I` by the sign of `p_{I^j}`, while leaving inactive minors unchanged.
In all cases each required strict sign is attained at some finite parameter;
no infinite limiting matrix is asserted. A finite set of intermediate walls
can be avoided.

## Exact `(3,7)` counts and limits

The graph has 2,441,204 formal `H=4` states. The pencil bound `P` from
`pencil_variation_lower_bound.md` accounts for 2,318,427 states with `P=4`,
48 states with `P=6` that are unrealizable, and 122,729 with `P=2`.

For the 122,729 states, enumerate all 5,040 assignments of power-of-two
weights and all 60 subset covers. The criterion proves rank at least four
for 75,979. A separate finite closure search allows **arbitrary compositions**
of the 1,066 resulting dense sign maps and the six large-shear maps. It
explores 928 distinct relevant triples `(target, A, B)` and finds no further
promotion among these states. Thus:

* `2,394,406 = 2,318,427 + 75,979` H=4 formal states have a proven lower
  bound 4, so every actual strict matrix in one of them has true rank 4.
* 48 states are unrealizable because the pencil lower bound is 6.
* 46,750 states remain unresolved by these two lower tests. Among them,
  1,007 violate a necessary cubic sign rule and are unrealizable; 45,743 pass
  that rule and all 105 three-term Plücker sign tests. Passing these tests is
  not a realization certificate, and neither does failure of the dominance
  criterion imply true rank 2.

The closure only rules out this specific family of sign-dominance arguments;
a positive trajectory may use finite parameters, other sign tests, or
quantitative information. All state counts refer to the formal 52-sign graph,
not to a count or measure of real matrices.

## Reproduction

From this directory:

```sh
c++ -O3 -std=c++17 -pthread analyze_rank4_dominance.cpp -o analyze_rank4_dominance
./analyze_rank4_dominance
c++ -O3 -std=c++17 -pthread analyze_rank4_composed_dominance.cpp -o analyze_rank4_composed_dominance
./analyze_rank4_composed_dominance
c++ -O3 -std=c++17 -pthread analyze_rank4_residual_filters.cpp -o analyze_rank4_residual_filters
./analyze_rank4_residual_filters
```

The last checker reads `cubic_rule_masks.txt`, generated from the independently
symbolically verified rule in `verify_three_product_sign_rule.py`; all three
reconstruct accepted states and read
`../grassmann_37_continuation/new_work/augmented_optimal_rank.bin`. Their
outputs are saved as corresponding `.log` files. The graph upper-bound
and coverage dependencies are in `verify_optimal_rank_bound_independent.cpp`
and `audit_50_and_g_coverage.md`; criterion (1) and its proof do not need them.
