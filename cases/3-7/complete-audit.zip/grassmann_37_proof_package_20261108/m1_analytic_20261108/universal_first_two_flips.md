# Two universal target flips from the alternating chamber

This is an elementary result. It shows that every strictly alternating
\(3\times7\) start admits **two** positive-move target sign changes and can
be placed afterwards in one fixed \(m=2\) minor-sign chamber. It does not
prove that every such start admits ten further changes.

Let \(M=(v_1,\ldots,v_7)\), normalize \(p_{567}(M)>0\), and suppose
\(\operatorname{sgn}p_{abc}(M)=(-1)^{a+b+c}\) for every \(a<b<c\). Put
\(D=\operatorname{diag}((-1)^1,\ldots,(-1)^7)\) and \(W=MD\). All ordered
maximal minors of \(W\) are positive. A positive original move at column
\(j\) becomes the negative shear \(W_j\leftarrow W_j-tW_{j+1}\).

We show that three such shears, with labels \(3,4,3\), can be chosen so
that the successive negative-minor sets of \(W\) are
\[
\varnothing,\quad \{123\},\quad
\{123,124,134,234\},\quad \{124,134,234\}.\tag{1}
\]
Every displayed vertex has all 35 minors nonzero. Since the reorientation
preserves the sign of \(p_{123}\), these shears change the target sign
exactly twice.

## The first shear

Let all brackets without a superscript denote the initial positive minors.
Along \(W_3\leftarrow W_3-tW_4\), the root of \(p_{123}\) is
\(t_0=p_{123}/p_{124}>0\). It occurs strictly before every other affected
minor. For \(k\in\{5,6,7\}\), the Plücker relations give
\[
\begin{aligned}
p_{124}p_{13k}-p_{123}p_{14k}&=p_{12k}p_{134}>0,\\
p_{124}p_{23k}-p_{123}p_{24k}&=p_{12k}p_{234}>0.
\end{aligned}
\]
For \(5\le k<l\le7\), the cyclic bracket identity and the cubic positive
identity in `cubic_plucker_sign_rule.md` give
\[
\begin{aligned}
p_{124}p_{3kl}-p_{123}p_{4kl}
 &=p_{12k}p_{34l}-p_{12l}p_{34k}>0.
\end{aligned}
\]
These are precisely the other nine affected minors. Hence for sufficiently
small \(\epsilon>0\), choosing \(t=t_0+\epsilon\) leaves only \(p_{123}\)
negative.

## The middle shear

First set \(\epsilon=0\) temporarily. At the first wall,
\[
W_3^*=\frac{-p_{234}W_1+p_{134}W_2}{p_{124}}.
\]
Now shear \(W_4\leftarrow W_4-sW_5\). The minors \(p_{124},p_{134},p_{234}\)
vanish together at \(s_0=p_{124}/p_{125}\), and each crosses from positive
to negative there. All seven other affected minors are **strictly positive**
at that point. In fact, for \(k=6,7\),
\[
p_{14k}^*=\frac{p_{12k}p_{145}}{p_{125}},\quad
p_{24k}^*=\frac{p_{12k}p_{245}}{p_{125}},\quad
p_{34k}^*=\frac{p_{12k}p_{345}}{p_{125}}>0.
\]
The seventh is \(p_{467}^*\), and its positivity follows from
\[
p_{156}(p_{125}p_{467}-p_{124}p_{567})
=p_{126}p_{145}p_{567}+p_{125}p_{167}p_{456}>0.
\]
All brackets on the right are initial positive minors.

Choose a fixed sufficiently small \(\delta>0\) such that at
\((t_0,s_0+\delta)\), the three listed minors are negative and the seven
others remain positive. Now choose \(\epsilon>0\) sufficiently small.
Continuity preserves those signs at \((t_0+\epsilon,s_0+\delta)\); the
first target minor remains negative throughout the middle shear. This gives
the third sign set in (1).

## The last shear and the variation

At the end of the middle shear,
\[
p_{123}=-p_{124}^{\mathrm{initial}}\epsilon<0,\qquad
p_{124}=-p_{125}^{\mathrm{initial}}\delta<0.
\]
A further negative shear of column 3 therefore flips \(p_{123}\) back to
positive at a parameter of order \(\epsilon/\delta\). As \(\epsilon\to0\)
with \(\delta\) fixed this parameter tends to zero, so after crossing it
slightly, every other minor retains its sign. The final sign set is the
last one in (1).

The final minimum row variation of \(M=WD\) is exactly 2. For the upper
bound, a small perturbation of \(-\det(W_1,W_2,\cdot)\) gives the signs
\(+++++-+\) on \(M_1,\ldots,M_7\), using the last sign set in (1).
For the lower bound, the signed cofactor circuits force positive
coefficients \(a_i,b_i\) in
\[
a_1M_1+a_2M_2+a_3M_3=a_7M_7,\qquad
b_3M_3+b_4M_4+b_5M_5+b_6M_6=0.
\]
Up to overall sign, any zero- or one-variation strict word has the form
\((-^r,+^{7-r})\). The second dependence excludes \(r\le2\), while the
first excludes \(r\ge3\). Thus no row covector has variation at most 1.
The same conclusion holds if zero entries are deleted, since genericity
allows their signs to be perturbed without increasing variation.

## Exact example

`verify_universal_two_flip_example.py` starts with positive Vandermonde
columns \((1,t_i,t_i^2)\), \(t_i=0,1,\ldots,6\), and uses the negative
shear parameters
\[
(3,1000003/3000000),\quad(4,51/100),\quad(3,1/10000).
\]
It checks (1), all 35 minors at all four vertices, two target changes and
final minimum variation 2 using exact rational arithmetic. The original
positive-move example is obtained by alternating the column signs.
