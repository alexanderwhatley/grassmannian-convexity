# Every positive projection has rank 8, but the actual rank is 4

Consider the integer matrix with columns
\[
\begin{aligned}
v_1&=(0,0,1),&v_2&=(5,25,1),&v_3&=(-3,-7,1),\\
v_4&=(-2,-5,1),&v_5&=(-7,0,1),&v_6&=(5,-24,1),&v_7&=(4,-10,1).
\end{aligned}
\tag{1}
\]
All 35 maximal minors and all 17 auxiliary features in the 52-sign model
are nonzero, and \(p_{567}>0\). The covector \(\omega=z\) is positive on
every column. More strongly, **every** covector positive on every column
gives a projected six-vector cyclic rank of 8.

Yet the independently checked 52-sign rank certificate assigns the exact
52-sign key `580502729194919` the rank \(H=4\), proving at most four future
target changes, subject to the sign-graph proof audit. The 13 positive
shears below attain four, so this matrix has actual rank exactly 4. This is
a concrete obstruction to concluding that the projected rank-8 upper bound
is attainable under fixed-covector corner cutting.

## Why all common-positive projections have rank 8

For a covector \(\omega\), write \(x_i=\omega(v_i)\) and
\(w_i=v_{i+1}-(x_{i+1}/x_i)v_i\in\ker\omega\), \(1\le i\le6\). If all
\(x_i>0\), then for \(i<j\) the sign of the projected pair determinant is
\(\operatorname{sgn}\omega(L_{ij})\), where
\[
L_{ij}=p_{i,i+1,j+1}v_j-p_{i,i+1,j}v_{j+1}.
\]
The denominator in the determinant formula is \(x_i x_j>0\). The exact
identities checked in `verify_uniform_rank8_example.py` show that every
\(\widetilde L_{ij}=(-1)^{i+j+1}L_{ij}\) is a nonzero positive combination
of the seven columns. For adjacent pairs, the multiples are
\(40v_2,16v_3,15v_4,60v_5,144v_6\), respectively. The ten nonadjacent
identities are:

| \(ij\) | Positive combination |
|:---:|---|
| 13 | \(8\widetilde L_{13}=85v_1+30v_4+5v_7\) |
| 14 | \(24\widetilde L_{14}=1500v_1+1225v_5+875v_6\) |
| 15 | \(\widetilde L_{15}=245v_5+175v_6\) |
| 16 | \(\widetilde L_{16}=49v_1+46v_2\) |
| 24 | \(\widetilde L_{24}=15v_2+185v_3\) |
| 25 | \(\widetilde L_{25}=392v_5+184v_6\) |
| 26 | \(\widetilde L_{26}=95v_2+49v_3\) |
| 35 | \(\widetilde L_{35}=33v_5+15v_6\) |
| 36 | \(196\widetilde L_{36}=1584v_2+539v_5+1013v_6\) |
| 46 | \(\widetilde L_{46}=5v_6+60v_7\) |

Thus for every common-positive covector the 15 projected determinant signs
are exactly \((-1)^{i+j+1}\). The associated standard cyclic word is
\[
(1,6,-5,4,-3,2,-1,-6,5,-4,3,-2),
\]
whose rank is 8. In particular, optimizing the rank over all fixed
common-positive covectors cannot improve that 8-bound for this matrix.

As a separate elementary upper bound, \(\omega'=(-1,-1,-3)\) has values
\((-3,-33,7,4,4,16,3)\), signs `--+++++`, and projected rank 3. The
previously proved scalar-pole bounds charge at most 2 for the sole possible
\(x_2\)-crossing and 1 for the sole possible \(x_1\)-crossing, giving
at most \(3+2+1=6\) target changes. The sharper upper bound 4 uses the
finite graph rank \(H\).

## A matching four-change path

A move \((j,t)\) means \(v_j\leftarrow v_j+t v_{j+1}\). The exact path is
\[
\begin{aligned}
&(2,15),(4,1/9),(5,2),(3,99/10),(4,10/27),(5,3),(1,7/16),\\
&(3,27/5),(1,23/2),(2,4/3),(3,54/5),(4,10/27),(3,54/5).
\end{aligned}
\]
Its target signs change at moves 4, 8, 11, and 13. Every maximal minor is
nonzero at each of the 14 recorded matrices, and all 35 are positive at the
end. The last statement is consistent with the general zero-future-flips
criterion, but is not needed for the four-change lower bound.

## Reproduction

From this directory:

```sh
python3 verify_uniform_rank8_example.py
c++ -O3 -std=c++17 -pthread verify_uniform_rank8_h4.cpp -o verify_uniform_rank8_h4
./verify_uniform_rank8_h4
python3 verify_uniform_rank8_four_flips.py uniform_rank8_four_tiny_lambdas.txt
```

The 13 original shear parameters are also saved in
`uniform_rank8_four_tiny_moves.json`. The H lookup uses the shared key
generator and the saved `augmented_optimal_rank.bin`; the 15 cone identities,
minor signs, projected cyclic words, and four-flip replay are exact rational
arithmetic and do not use that rank file.
