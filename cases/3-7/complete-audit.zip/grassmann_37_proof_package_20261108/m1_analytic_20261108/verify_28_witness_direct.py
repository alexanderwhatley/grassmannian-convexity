#!/usr/bin/env python3
"""Independent direct 3-vector rational replay of a 28-shear certificate."""
from fractions import Fraction as Q
from itertools import combinations
from collections import Counter
from pathlib import Path
import json,sys
if hasattr(sys,'set_int_max_str_digits'):sys.set_int_max_str_digits(0)
path=Path(sys.argv[1]) if len(sys.argv)>1 else Path('../trajectory_search_20261108/prefixfit_28_result_single_1.json')
x=json.loads(path.read_text());v=[[Q(z) for z in col] for col in x['initial_columns']];moves=[(int(j),Q(t)) for j,t in x['moves']]
assert len(v)==7 and all(len(c)==3 for c in v) and len(moves)==28
I=list(combinations(range(1,8),3));F=[(1,2,3,4),(1,3,2,4),(1,4,2,3),(1,2,3,5),(1,3,2,5),(1,5,2,3),(1,2,4,5),(1,4,2,5),(1,5,2,4),(1,3,4,5),(1,4,3,5),(1,5,3,4),(2,3,4,5),(2,4,3,5),(2,5,3,4)]
def det(a,b,c):return a[0]*(b[1]*c[2]-b[2]*c[1])-b[0]*(a[1]*c[2]-a[2]*c[1])+c[0]*(a[1]*b[2]-a[2]*b[1])
def feat(v):
 p={T:det(*(v[z-1] for z in T)) for T in I}
 fs=[p[a,b,6]*p[c,d,7]-p[a,b,7]*p[c,d,6] for a,b,c,d in F]
 gs=[p[1,2,5]*p[3,4,j]-p[1,2,j]*p[3,4,5] for j in (6,7)]
 return p,fs+gs
p,f=feat(v);assert all(p.values()) and all(f) and p[5,6,7]>0
assert all((p[T]>0)==(sum(T)%2==0) for T in I)
last=p[5,6,7];old=p[1,2,3]>0;old124=p[1,2,4]>0;flips=[];sep=[]
for step,(j,t) in enumerate(moves,1):
 assert 1<=j<=6 and t>0
 v[j-1]=[v[j-1][a]+t*v[j][a] for a in range(3)]
 p,f=feat(v);assert all(p.values()) and all(f),(step,'feature vanishes');assert p[5,6,7]==last
 now=p[1,2,3]>0;now124=p[1,2,4]>0
 if now!=old:flips.append(step)
 if now124!=old124:sep.append(step)
 old,old124=now,now124
assert len(flips)==12 and all(moves[i-1][0]==3 for i in flips)
assert len(sep)==11 and all(moves[i-1][0] in (2,4) for i in sep)
counts=Counter(j for j,t in moves);assert counts[1]==2 and counts[5]==2 and counts[6]==1 and counts[3]==12 and counts[2]+counts[4]==11
print('PASS exact rational input, 28 positive shears and strict alternating start')
print('PASS all 35 minors and 17 auxiliary features are nonzero at all 29 vertices')
print('PASS target flips:',flips,'and 11 p124 separators:',sep)
print('PASS generator counts:',dict(sorted(counts.items())))
