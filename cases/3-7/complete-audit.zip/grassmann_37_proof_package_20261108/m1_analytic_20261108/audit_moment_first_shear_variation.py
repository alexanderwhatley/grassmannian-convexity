#!/usr/bin/env python3
"""Exact m on every strict Pluecker-sign interval after a first U3(a)."""
from fractions import Fraction as Q
from itertools import combinations
I=list(combinations(range(7),3));C=list(combinations(range(7),4));v=[[Q((-1)**i),Q((-1)**i*i),Q((-1)**i*i*i)] for i in range(1,8)]
def det(a,b,c):return a[0]*(b[1]*c[2]-b[2]*c[1])-b[0]*(a[1]*c[2]-a[2]*c[1])+c[0]*(a[1]*b[2]-a[2]*b[1])
def ps(v):return {T:det(*(v[j] for j in T)) for T in I}
p=ps(v);v1=[x[:] for x in v];v1[2]=[v1[2][k]+v1[3][k] for k in range(3)];q=ps(v1);roots=sorted({-p[T]/(q[T]-p[T]) for T in I if p[T]*(q[T]-p[T])<0});bounds=[Q(0)]+roots
observed=[]
for a,b in zip(bounds,bounds[1:]+[None]):
 t=(a+b)/2 if b is not None else a+1;w=[x[:] for x in v];w[2]=[w[2][k]+t*w[3][k] for k in range(3)];r=ps(w);assert all(r.values());best=7
 for bits in range(64):
  s=[-1 if bits>>i&1 else 1 for i in range(6)]+[1]
  if any(len({s[i]*r[j,k,l]>0,-s[j]*r[i,k,l]>0,s[k]*r[i,j,l]>0,-s[l]*r[i,j,k]>0})==1 for i,j,k,l in C):continue
  best=min(best,sum(s[i]!=s[i+1] for i in range(6)))
 observed.append(best)
 print('a in',a,b if b is not None else 'infinity','m=',best,'target+',r[0,1,2]>0)
assert roots==list(map(Q,['1/3','2/3','3/4','8/9','1','4/3','2','8/3','3']))
assert observed==[4,3,2,2,2,2,2,2,2,2]
print('PASS exact variation table and strict positive roots',roots)
