#!/usr/bin/env python3
"""Exact obstruction to the shortest abstract first-flip path.

Path feature 37 uses move 1, followed by feature 48 using move 2. The latter
and a prior wall both involve no column 1, so their root order is independent
of the parameter in the first move.
"""
from fractions import Fraction as Q
from itertools import combinations
V=[[-79,-53,1],[-18,-70,1],[22,36,1],[-8,62,1],[51,-99,1],[86,-24,1],[89,38,1]]
I=list(combinations(range(1,8),3));F=[(1,2,3,4),(1,3,2,4),(1,4,2,3),(1,2,3,5),(1,3,2,5),(1,5,2,3),(1,2,4,5),(1,4,2,5),(1,5,2,4),(1,3,4,5),(1,4,3,5),(1,5,3,4),(2,3,4,5),(2,4,3,5),(2,5,3,4)]
def det(a,b,c):return a[0]*(b[1]*c[2]-b[2]*c[1])-b[0]*(a[1]*c[2]-a[2]*c[1])+c[0]*(a[1]*b[2]-a[2]*b[1])
def feat(v):
 p={T:det(*(v[z-1] for z in T)) for T in I}
 x=[p[T] for T in I]+[p[a,b,6]*p[c,d,7]-p[a,b,7]*p[c,d,6] for a,b,c,d in F]
 x += [p[1,2,5]*p[3,4,j]-p[1,2,j]*p[3,4,5] for j in (6,7)]
 return x

f=feat(V);v=[z[:] for z in V];v[1]=[v[1][k]+v[2][k] for k in range(3)];f1=feat(v)
p126=f[I.index((1,2,6))];p136=f[I.index((1,3,6))];p236=f[I.index((2,3,6))]
F48=f[48];dF48=f1[48]-f[48]
assert (p126,p136,p236,F48,dF48)==(4574,-11756,-9184,-30775004,13671808)
r_max=Q(p126,-p136);r_F=-Q(F48,dF48);assert r_max<r_F
print('after arbitrary positive U1(s), p126 under U2(t): 4574 - (11756+9184s)t')
print('F48 under U2(t): -30775004 + 13671808t')
print('earlier p126 root <=',r_max,'< feature 48 root',r_F)
print('PASS shortest abstract path cannot realize its first two feature flips for any s>0')
