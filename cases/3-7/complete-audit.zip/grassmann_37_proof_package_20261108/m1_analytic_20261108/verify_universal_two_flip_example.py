#!/usr/bin/env python3
"""Exact simple example of the universal j3,j4,j3 two-flip construction."""
from fractions import Fraction as Q
from itertools import combinations

def det(a,b,c):return a[0]*(b[1]*c[2]-b[2]*c[1])-a[1]*(b[0]*c[2]-b[2]*c[0])+a[2]*(b[0]*c[1]-b[1]*c[0])
P=list(combinations(range(1,8),3))
def ps(v):return {I:det(*(v[i-1] for i in I)) for I in P}
def mvar(p):
 best=0
 for a,b in combinations(range(1,8),2):
  signs=[]
  for i in range(1,8):
   if i in (a,b):continue
   I=tuple(sorted((a,b,i)));x=p[I]*(-1)**sum(I)*(-1)**i
   signs.append(x>0)
  best=max(best,sum(x!=y for x,y in zip(signs,signs[1:])))
 return 4-best
W=[[Q(1),Q(t),Q(t*t)] for t in range(7)]
steps=[(3,Q(1000003,3000000)),(4,Q(51,100)),(3,Q(1,10000))]
expected=[set(),{(1,2,3)},{(1,2,3),(1,2,4),(1,3,4),(2,3,4)},
          {(1,2,4),(1,3,4),(2,3,4)}]
last=0;flips=0
for step in range(4):
 p=ps(W);assert all(p.values());neg={I for I,x in p.items() if x<0};assert neg==expected[step],(step,neg)
 sg=p[1,2,3]>0
 if step and sg!=last:flips+=1
 print('vertex',step,'m',mvar(p),'negative W minors',sorted(neg))
 last=sg
 if step<3:
  j,t=steps[step];assert t>0
  W[j-1]=[W[j-1][r]-t*W[j][r] for r in range(3)]
assert flips==2 and mvar(p)==2
print('PASS all 35 minors strict at each vertex; two target flips in 3 positive original moves')
