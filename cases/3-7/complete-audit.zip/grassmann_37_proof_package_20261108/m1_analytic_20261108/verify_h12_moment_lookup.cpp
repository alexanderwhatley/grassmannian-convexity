// Verify exact moment-example 52 keys have graph optimal rank H=12.
#define main old_graph_main_unused
#include "../grassmann_37_continuation/rebuild_full_graph.cpp"
#undef main
int main(){
 init();auto dirs=direction_types(true);auto masks=sign_masks();Hash H(1ull<<25);
 uint32_t n=0;for(auto&w:dirs)for(auto&z:add_axes(w)){uint64_t b=word_key(z);for(auto m:masks)H.insert(b^m,n++);}assert(n==16051200);
 vector<uint8_t>h(uint64_t(n)*4);ifstream hf("../grassmann_37_continuation/new_work/augmented_optimal_rank.bin",ios::binary);
 hf.read((char*)h.data(),h.size());assert(hf.gcount()==int64_t(h.size()));
 ifstream in("moment_example_keys.txt");int f,count=0;uint64_t k;
 while(in>>f>>k){uint32_t u=H.find(k&((1ull<<50)-1));assert(u!=UINT32_MAX);int g=k>>50;assert(g==2&&h[4*u+g]==12);count++;}
 assert(count==12);cout<<"PASS all 12 independent moment-curve keys belong to H=12 graph states\n";
}
