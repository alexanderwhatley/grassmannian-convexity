# An elementary positive rectangular chart for every Grassmannian

This note gives a source-free proof of the rectangular chart used in the
universal alternating-start rank argument. It uses only Cauchy–Binet,
adjacent particle moves, and the polynomial identity principle. The finite
script `audit_rectangular_chart_particles.py` independently checks the
particle counts and monomials for all \(n\le10\); that check is diagnostic,
not a substitute for the proof below.

## Chart and monomial minors

Let \(0<k<n\), \(r=n-k\), \(E=[0_{k\times r}\mid I_k]\), and
\(U_j(t)=I+tE_{j+1,j}\). For positive parameters \(t_{ij}\), in row-major
order \(i=1,\ldots,k\), \(j=1,\ldots,r\), define
\[
T(t)=\prod_{i=1}^k\ \prod_{j=1}^r U_{r+i-j}(t_{ij}),\qquad
\Phi(t)=\operatorname{row}(E T(t)).\tag{1}
\]
The trailing \(k\times k\) block of \(ET(t)\) is lower unipotent, so its
determinant is 1 and the trailing row-space chart is defined for all \(t\).

For \(0\le h\le k\) and \(0\le l\le r\), set
\[
I_{h,l}=\{1,\ldots,h\}\cup\{h+l+1,\ldots,k+l\},\qquad
C_{h,l}=\Delta_{I_{h,l}}(ET(t)).
\]
Then
\[
C_{h,l}=
\prod_{i\le h,\ j\le r}t_{ij}
\;\prod_{i>h,\ j\le r-l}t_{ij}.\tag{2}
\]
Here \(C_{0,r}=1\) and \(C_{h,0}=C_{k,l}=\Delta_{1,\ldots,k}\).

To prove (2), expand
\(\Delta_{I}(ET)=\Delta_{K_*,I}(T)\), with \(K_*=\{r+1,\ldots,n\}\),
in exterior power. Each factor \(U_j(t)\) either leaves a set of occupied
indices unchanged or moves an occupied \(j\) to an unoccupied \(j+1\)
with coefficient \(t\); there are no negative coefficients. Factors act
from right to left, so block \(i\) is encountered for \(i=k,k-1,\ldots,1\),
and its available edges are \(i,i+1,\ldots,r+i-1\) in that order.

Start with \(I_{h,l}\). In block \(i\), the rightmost particle not already
finished is at \(i+l\) if \(i>h\), and at \(i\) if \(i\le h\). It must
reach \(r+i\) in that block: all later blocks have largest available edge
at most \(r+i-2\). Earlier edges in the block cannot move another particle:
the relevant lower particles form a contiguous occupied run, so they are
blocked; after the rightmost particle advances, those edges have already
passed. Thus exactly the edges from its current index through \(r+i-1\) are
used, and the other particles remain unchanged. Inducting from \(i=k\) down
to 1 gives exactly one history and exactly the factors in (2).

For an arbitrary \(k\)-subset \(I=(i_1<\cdots<i_k)\), there is at least one
history to \(K_*\): in descending block \(s\), move particle \(i_s\) along
all edges to \(r+s\), skipping other factors. Already-finished particles are
to its right and the unfinished ones to its left. Thus every Plücker
coordinate of \(ET(t)\) is positive for \(t>0\).

## Rational inverse and surjectivity

For \(1\le i\le k\), \(1\le j\le r\), equation (2) gives the explicit
cross-ratio inverse
\[
t_{ij}=\frac{C_{i,r-j+1}\,C_{i-1,r-j}}
 {C_{i-1,r-j+1}\,C_{i,r-j}}.\tag{3}
\]
The expression is invariant under a common scaling of Plücker coordinates.
Let \(\Psi\) denote the rational map (3) on the trailing affine chart. On
\((0,\infty)^{kr}\), (2) proves \(\Psi\circ\Phi=\mathrm{id}\). Hence the
Jacobian of \(\Phi\) has full rank everywhere in that positive orthant,
and its image contains a nonempty open subset of the full affine chart
\(\mathbb R^{kr}\).

On that open subset, \(\Phi\circ\Psi=\mathrm{id}\). Both sides are
rational functions in the trailing-chart coordinates; after clearing
nonzero denominators their differences are polynomials vanishing on an
open subset of \(\mathbb R^{kr}\), hence vanish identically. Thus
\(\Phi\circ\Psi=\mathrm{id}\) wherever the displayed denominators are
nonzero. If \(X\) is any Plücker-positive \(k\)-plane, every \(C_{h,l}(X)\)
is positive, so \(\Psi(X)>0\) and \(\Phi(\Psi(X))=X\). This proves
surjectivity and the global positive rational inverse. In particular,
\(\Phi:(0,\infty)^{kr}\to Gr_{>0}(k,n)\) is a diffeomorphism.

The proof uses no positive-flag completion, reduced-word factorization, or
connectedness theorem. Once this chart is established, the alternating-start
transfer and the finite backward extension in
`alternating_chamber_universal_rank.md` work in every dimension, with
\(kr\) preparation shears.
