#!/usr/bin/env python3
"""Search exact alternating signed moment-curve realizations of H=12 keys."""
from itertools import combinations
from random import Random
from pathlib import Path
import json
P=list(combinations(range(1,8),3))
F=[(1,2,3,4),(1,3,2,4),(1,4,2,3),(1,2,3,5),(1,3,2,5),(1,5,2,3),(1,2,4,5),(1,4,2,5),(1,5,2,4),(1,3,4,5),(1,4,3,5),(1,5,3,4),(2,3,4,5),(2,4,3,5),(2,5,3,4)]
target={3640,3608,3612,3864,3868,20024,19992,19996,20248,20252,18200,18204}
def d(a,b,c):return a[0]*(b[1]*c[2]-b[2]*c[1])-a[1]*(b[0]*c[2]-b[2]*c[0])+a[2]*(b[0]*c[1]-b[1]*c[0])
rng=Random(720573);found={}
for trial in range(500000):
 ts=sorted(rng.sample(range(-200,201),7));v=[[(-1)**i,(-1)**i*t,(-1)**i*t*t] for i,t in enumerate(ts,1)]
 def p(a,b,c):return d(v[a-1],v[b-1],v[c-1])
 q=[p(a,b,6)*p(c,d,7)-p(a,b,7)*p(c,d,6) for a,b,c,d in F]
 if not all(q):continue
 f=sum((1<<i) for i,x in enumerate(q) if x>0)
 if f not in target or f in found:continue
 g=[p(1,2,5)*p(3,4,j)-p(1,2,j)*p(3,4,5) for j in (6,7)]
 assert g[0]<0<g[1] and q[0]<0
 assert all((p(*I)>0)==(sum(I)%2==0) for I in P)
 found[f]={'t':ts,'initial_columns':v,'Fword':f,'g':2}
 print('found',len(found),'Fword',f,'t',ts,flush=True)
 if len(found)==len(target):break
Path('h12_moment_examples.json').write_text(json.dumps(found,indent=2)+'\n')
print('found total',len(found),'of',len(target),'missing',sorted(target-set(found)))
