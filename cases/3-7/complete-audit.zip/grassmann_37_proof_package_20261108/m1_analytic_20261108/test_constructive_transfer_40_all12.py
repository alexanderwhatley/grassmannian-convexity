#!/usr/bin/env python3
"""Reproduce and independently replay the 40-move transfer in all 12 chambers."""
from pathlib import Path
import json,re,subprocess,sys
examples=json.loads(Path('h12_moment_examples.json').read_text());out=Path('constructive_40_certificates');out.mkdir(exist_ok=True)
assert len(examples)==12
for name,obj in examples.items():
 inp=out/f'input_{name}.json';inp.write_text(json.dumps({'initial_columns':obj['initial_columns']})+'\n')
 p=subprocess.run([sys.executable,'constructive_transfer_40.py',str(inp)],capture_output=True,text=True,check=True)
 (out/f'log_{name}.txt').write_text(p.stdout);cert=out/f'certificate_{name}.json';cert.write_text(Path('constructive_transfer_40.json').read_text())
 q=subprocess.run([sys.executable,'verify_constructive_transfer_40.py',str(cert)],capture_output=True,text=True,check=True)
 (out/f'verify_{name}.txt').write_text(q.stdout)
 ep=re.search(r'epsilon=2\^\(-([0-9]+)\)',p.stdout);assert ep,p.stdout
 print('Fword',name,'epsilon 2^-'+ep.group(1),'PASS 40 exact shears and independent direct replay',flush=True)
