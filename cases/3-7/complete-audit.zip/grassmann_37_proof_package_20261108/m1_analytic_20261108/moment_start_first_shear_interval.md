# First-shear interval for the simple moment start

Let
\[
 v_i=(-1)^i(1,i,i^2),\qquad i=1,\ldots,7,
\]
and let the first positive shear be `U3(a)`. If `a>2/3` and the recorded
vertex is generic, the entire trajectory has **at most 10** target sign
changes, regardless of how many later moves it uses. Consequently, any
strictly generic 28-move, 12-change trajectory from this fixed start must
have
\[
 \boxed{\frac13<a<\frac23.}\tag{1}
\]
This is a necessary condition, not a construction for any value in the
interval. It does not address other starting matrices or paths permitting a
zero minor at a recorded vertex.

The upper exclusion follows analytically from the independently certified
`r<=8+m` bound. After the first shear the columns are unchanged except
\[
 v_3'=(-1,-3,-9)+a(1,4,16).
\]
For any `a>2/3`, choose
\[
 \omega_\epsilon=(14-3\epsilon,-9+\epsilon,1),\qquad
 0<\epsilon<\min\!\left(\frac12,\frac{6a-4}{2a}\right).
\]
Its seven values are
\[
 (-6+2\epsilon,\ -\epsilon,\ 4-6a+a\epsilon,\ -6+\epsilon,\
  6-2\epsilon,\ -4+3\epsilon,\ -4\epsilon),
\]
with strict sign sequence `----+--`. Hence the new minimum row-space
variation satisfies `m<=2`, so at most `8+m<=10` target changes remain.
The target is negative at this point and the invariant last minor is
positive. If ten further changes occurred, the target would again be
negative, and the terminal dominance lemma would force an eleventh,
contradicting the bound. Hence at most nine further changes are possible.
The first `U3(a)` has exactly one target change, giving at most 10 in total.
At the boundary `a=2/3`, the minor `p237` vanishes, so that
recorded vertex is not generic.

For the lower endpoint, every globally shortest 12-change trajectory must
begin with a target-flipping move: otherwise delete its first move and
start at the resulting generic vertex, contradicting the certified
28-move minimum. Only `U3` changes the target, and here
\[
 p_{123}\bigl(M U_3(a)\bigr)=2-6a,
\]
so a strict first target change requires `a>1/3`. Combining this with the
upper exclusion and the singular boundary proves (1).

The lower restriction **does not apply** to an arbitrary longer 12-change
trajectory: it may begin with a nonflipping `U3(a<1/3)` and make its first
target change later. The upper exclusion `a>2/3`, by contrast, does not
assume optimal length or that the first shear has already been chosen as
part of a shortest path.

`audit_moment_first_shear_variation.py/.log` independently enumerates the
finite 35-minor sign intervals and computes `m` by exact four-circuit tests:
`m=4` on `(0,1/3)`, `m=3` on `(1/3,2/3)`, and `m=2` on every strict
interval above `2/3`. That enumeration corroborates the explicit covector
argument but is not needed for the upper exclusion. The `8+m` bound and
28-move minimum have the separate computer-assisted dependencies recorded in
`independent_41_sign_audit.md` and `restriction_28_move_profile.md`.
