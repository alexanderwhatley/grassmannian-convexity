// Necessary 3x6-sign overapproximation for bounded U1 and U5 runs, <=1 U6.
// A surviving abstract path is not claimed realizable.  Unbounded U2,U3,U4.
#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <deque>
#include <iostream>
#include <string>
#include <vector>
using namespace std;
struct Edge {int dest;uint8_t j,w,f;};
int main(int argc,char**argv){
 int R=argc>1?stoi(argv[1]):1,T=argc>2?stoi(argv[2]):3;assert(1<=R&&R<=2&&2<=T&&T<=3);
 vector<array<int,3>> P;int ix[7][7][7]={};for(int a=1;a<=6;a++)for(int b=a+1;b<=6;b++)for(int c=b+1;c<=6;c++){ix[a][b][c]=P.size();P.push_back({a,b,c});}
 vector<array<int,6>>rel;for(int s=1;s<=6;s++)for(int a=1;a<=6;a++)for(int b=a+1;b<=6;b++)for(int c=b+1;c<=6;c++)for(int d=c+1;d<=6;d++){
  if(s==a||s==b||s==c||s==d)continue;auto f=[&](int x,int y){array<int,3> t={s,x,y};sort(t.begin(),t.end());return ix[t[0]][t[1]][t[2]];};rel.push_back({f(a,b),f(c,d),f(a,c),f(b,d),f(a,d),f(b,c)});
 }
 assert(P.size()==20&&rel.size()==30);vector<uint32_t>keys;vector<int>ident(1<<20,-1);vector<vector<int>> groups(1024);vector<int>grp;
 vector<int>first5;for(int a=1;a<=5;a++)for(int b=a+1;b<=5;b++)for(int c=b+1;c<=5;c++)first5.push_back(ix[a][b][c]);assert(first5.size()==10);
 for(uint32_t x=0;x<(1u<<20);x++){
  auto s=[&](int k){return (x>>k&1)?1:-1;};bool good=true;for(auto t:rel)if(abs(s(t[0])*s(t[1])-s(t[2])*s(t[3])+s(t[4])*s(t[5]))==3){good=false;break;}
  if(!good)continue;int id=keys.size(),g=0;for(int i=0;i<10;i++)if(x>>first5[i]&1)g|=1<<i;ident[x]=id;keys.push_back(x);grp.push_back(g);groups[g].push_back(id);
 }
 int N=keys.size();assert(N==23808);vector<vector<Edge>>edge(N);uint64_t total=0;
 for(int u=0;u<N;u++)for(int j=1;j<=5;j++)for(int k=0;k<20;k++){
  auto A=P[k];auto it=find(A.begin(),A.end(),j);if(it==A.end()||find(A.begin(),A.end(),j+1)!=A.end())continue;
  *it=j+1;sort(A.begin(),A.end());int b=ix[A[0]][A[1]][A[2]];if(((keys[u]>>k)^(keys[u]>>b))%2==0)continue;
  int v=ident[keys[u]^(1u<<k)];if(v<0)continue;edge[u].push_back({v,(uint8_t)j,(uint8_t)(k==ix[1][2][3]),(uint8_t)k});total++;
 }
 uint32_t startbits=0;for(int k=0;k<20;k++){auto A=P[k];if((A[0]+A[1]+A[2])%2==0)startbits|=1u<<k;}

 int start=ident[startbits];assert(start>=0);int K1=R+1,K5=T+1;
 // idle, U1, U5, U3-before, U3-after, U2-before, U2-after, U4-before, U4-after
 const int NM=9;
 auto code=[&](int s,int a,int b,int g,int need,int mode){return ((((((g*K1+a)*K5+b)*2+need)*NM+mode)*N)+s);};
 auto ngroup=[&](int group,int a,int b,int need){return (((a*K5+b)*2+need)*1024+group);};
 size_t SZ=size_t(N)*2*K1*K5*2*NM;vector<int8_t>score(SZ,-1),ins(SZ,0),groupbest(size_t(K1)*K5*2*1024,-1);deque<int>Q;int root=code(start,0,0,0,0,0);score[root]=0;Q.push_back(root);ins[root]=1;uint64_t processed=0,improved=0,jumps=0;int maxval=0;
 auto push=[&](int id,int z){if(z>=12){cout<<"ABSTRACT 12-FLIP PATH SURVIVES exact separator constraint; NOT a realization\n";exit(0);}if(z<=score[id])return;score[id]=z;improved++;maxval=max(maxval,z);if(!ins[id]){ins[id]=1;Q.push_back(id);}};
 while(!Q.empty()){
  int C=Q.front();Q.pop_front();ins[C]=0;int s=C%N;int t=C/N;int mode=t%NM;t/=NM;int need=t%2;t/=2;int b=t%K5;t/=K5;int a=t%K1;int g=t/K1;int val=score[C];
  if(mode==1||mode==2)push(code(s,a,b,g,need,0),val);
  if(mode==4)push(code(s,a,b,g,1,0),val);
  if(mode==6||mode==8)push(code(s,a,b,g,0,0),val);
  for(auto e:edge[s]){
   if(e.j==5&&e.f==ix[3][4][5])continue;
   int aa=a,bb=b,mm=mode,z=val;
   if(mode==0){
    if(e.j==1){if(a==R)continue;aa++;mm=1;}
    else if(e.j==5){if(b==T)continue;bb++;mm=2;}
    else if(e.j==3){if(need)continue;mm=e.w?4:3;z+=e.w;}
    else if(e.j==2||e.j==4){if(!need)continue;bool sep=e.f==ix[1][2][4];mm=e.j==2?(sep?6:5):(sep?8:7);}
    else continue;
   }else if(mode==1){if(e.j!=1)continue;}
   else if(mode==2){if(e.j!=5)continue;}
   else if(mode==3){if(e.j!=3)continue;if(e.w){mm=4;z++;}}
   else if(mode==4){if(e.j!=3||e.w)continue;}
   else if(mode==5||mode==7){int j=mode==5?2:4;if(e.j!=j)continue;if(e.f==ix[1][2][4])mm=mode+1;}
   else if(mode==6||mode==8){int j=mode==6?2:4;if(e.j!=j||e.f==ix[1][2][4])continue;}
   push(code(e.dest,aa,bb,g,need,mm),z);
  }
  if(mode==0&&g==0){int gc=ngroup(grp[s],a,b,need);if(groupbest[gc]<val){groupbest[gc]=val;for(int v:groups[grp[s]])push(code(v,a,b,1,need,0),val);jumps++;}}
  if(++processed%10000000==0){cerr<<"processed="<<processed<<" queue="<<Q.size()<<" max="<<maxval<<"\n";cerr.flush();}
 }
 cout<<"PASS 3x6 necessary_states="<<N<<" event_edges="<<total<<" U1_runs<="<<R<<" U5_runs<="<<T<<" U6_jumps<=1 with exact target/separator runs and invariant p345 max_flips="<<maxval<<" processed="<<processed<<" improvements="<<improved<<" group_broadcasts="<<jumps<<"\n";
}
