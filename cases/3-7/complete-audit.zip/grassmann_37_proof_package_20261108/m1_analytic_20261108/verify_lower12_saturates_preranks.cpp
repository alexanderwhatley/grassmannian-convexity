// Link exact 52-sign keys of the independent 207-move witness to graph ranks.
#define main old_graph_main_unused
#include "../grassmann_37_continuation/rebuild_full_graph.cpp"
#undef main
int main(){
 init();auto dirs=direction_types(true);auto masks=sign_masks();Hash H(1ull<<25);
 uint32_t n=0;for(auto&w:dirs)for(auto&z:add_axes(w)){uint64_t b=word_key(z);for(auto m:masks)H.insert(b^m,n++);}assert(n==16051200);
 vector<uint8_t>R(n),bad((uint64_t(n)*4+7)/8),opt(uint64_t(n)*4);
 ifstream rf("../grassmann_37_continuation/filtered_rank.bin",ios::binary);rf.read((char*)R.data(),R.size());assert(rf.gcount()==int64_t(R.size()));
 ifstream bf("tight_to_rank01.bin",ios::binary);bf.read((char*)bad.data(),bad.size());assert(bf.gcount()==int64_t(bad.size()));
 ifstream hf("../grassmann_37_continuation/new_work/augmented_optimal_rank.bin",ios::binary);hf.read((char*)opt.data(),opt.size());assert(hf.gcount()==int64_t(opt.size()));
 ifstream in("lower12_vertex_keys.txt");uint64_t k,lastkey=0;int step,flips,nread=0,prev=-1,lastflips=0;
 while(in>>step>>k>>flips){assert(step==nread);if(nread)assert(flips==lastflips+int(bool((k^lastkey)&1)));lastkey=k;lastflips=flips;uint32_t bi=H.find(k&((1ull<<50)-1));assert(bi!=UINT32_MAX);int g=k>>50;assert(g>=0&&g<4);
  uint32_t c=4*bi+g;int h=opt[c],q=int(R[bi])-2*int(!(bad[c/8]&(1u<<(c%8))));
  assert(h==12-flips&&q==h);if(flips!=prev){cout<<"step="<<step<<" flips="<<flips<<" H=Q="<<h<<"\n";prev=flips;}nread++;
 }
 assert(nread==208&&prev==12);cout<<"PASS H=Q=12−completed_flips at all 208 exact witness vertices\n";
}
