#!/usr/bin/env python3
"""Prove the four 3x6 bracket identities by formal integer polynomials.

No symbolic algebra package is needed. Variables x_rc are represented by
integers 6*r+c; a monomial is a sorted tuple of variable indices.
"""
from collections import Counter
from itertools import permutations

def mul(f,g):
 h=Counter()
 for a,x in f.items():
  for b,y in g.items():h[tuple(sorted(a+b))]+=x*y
 return {a:x for a,x in h.items() if x}
def det(a,b,c):
 cols=[a-1,b-1,c-1];out=Counter()
 for perm in permutations(range(3)):
  parity=sum(perm[i]>perm[j] for i in range(3) for j in range(i+1,3))&1
  mon=tuple(sorted(6*r+cols[perm[r]] for r in range(3)))
  out[mon]+= -1 if parity else 1
 return {a:x for a,x in out.items() if x}
def relation(terms):
 out=Counter()
 for sign,triples in terms:
  p={():1}
  for I in triples:p=mul(p,det(*I))
  for m,c in p.items():out[m]+=sign*c
 assert all(c==0 for c in out.values()),[(k,v) for k,v in out.items() if v]
 return len(out)
rels={
 'first GP': [(1,[(1,2,3),(1,4,5)]),(-1,[(1,2,4),(1,3,5)]),(1,[(1,2,5),(1,3,4)])],
 'second GP': [(1,[(1,3,5),(4,5,6)]),(-1,[(1,4,5),(3,5,6)]),(1,[(1,5,6),(3,4,5)])],
 'cyclic G': [(1,[(1,2,5),(3,4,6)]),(-1,[(1,2,6),(3,4,5)]),(-1,[(1,2,4),(3,5,6)]),(1,[(1,2,3),(4,5,6)])],
 'two-term positivity': [(1,[(1,4,5),(1,2,5),(3,4,6)]),(-1,[(1,4,5),(1,2,6),(3,4,5)]),(-1,[(1,2,5),(1,3,4),(4,5,6)]),(-1,[(1,2,4),(1,5,6),(3,4,5)])],
}
for name,terms in rels.items():print('PASS',name,'zero polynomial; monomials',relation(terms))
