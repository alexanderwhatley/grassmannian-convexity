# Independent audit of the 41-sign projected rank

The saved `rank_41_unfiltered.bin` assigns an integer potential to a
projection of the full 52-sign graph. It uses the 35 maximal-minor signs,
four selected 67-features with original bit numbers `35,41,44,47`, and the
two signs `G56,G57`: 41 signs in total. This note records an independent
direct verification against **all full unfiltered 52-sign states and
edges**, rather than relying on the construction of the projected graph.

The verifier `verify_projected41_bound_independent.cpp` obtains:

| Check | Exact result |
|---|---:|
| Full accepted augmented states | 23,246,848 |
| Distinct eligible full-state edges | 144,788,896 |
| Target-changing edges | 663,552 |
| Maximum rank at `m=0,1,2,3,4` | 8, 9, 10, 11, 12 |
| States violating `rank<=8+m` | 0 |

It checks `rank(source)>=rank(destination)+weight` on every listed edge,
where the weight is 1 for a `p123` sign change and 0 otherwise. It does not
use a cubic sign filter. Some assigned ranks do not have target-sign parity;
parity is not needed for a nonnegative upper potential. The separate
real-trajectory coverage, including generic perturbation of coincident
feature events, is in `audit_50_and_g_coverage.md`.

## Inputs and shared components

The checker **does not read any saved full sign-key list**. It reconstructs
all 16,051,200 full 50-sign base keys using `direction_types(true)`,
`add_axes`, `word_key`, `sign_masks`, and `Hash` from
`../grassmann_37_continuation/rebuild_full_graph.cpp`. Those state-generation
routines are shared with the original certificate; this is not an
independent reconstruction of that basis. It masks each key by
\[
 ((1\ll36)-1)\;|\;(1\ll41)\;|\;(1\ll44)\;|\;(1\ll47),
\]
sorts and deduplicates the results, and gets 3,378,432 projected base keys.
The binary file contains one unsigned byte for each `4*projected_index+g`;
`g` bit 0 is the sign of `G56` and bit 1 is the sign of `G57`. Byte 255
marks an unavailable projected state. A full invalid G lift may still map
to a valid projected state through a different hidden lift; the checker
correctly ignores such invalid full lifts rather than requiring byte 255.

The only rank data read are
`../grassmann_37_continuation/history_20261108/rank_41_unfiltered.bin`
(13,513,728 bytes), SHA-256
`79defa24dc15f85dde4530941a6d478c9dbaabe56e90e0e98fee63dd97043553`.
The verifier also reads the shared 108-record
`../grassmann_37_continuation/event_table.txt`, SHA-256
`aae450f554ed04d8300e8f04acc48bd3836c4b5f0f0af9059693294dac025558`.
Those original derivative records are independently checked symbolically by
`../grassmann_37_continuation/verify_event_table_symbolic.py`. The verifier
adds the six G derivatives explicitly and calculates each event's sign
eligibility itself; it does **not** call the original `eligible` function
or read any saved transition list.

The G validity code is separate from `g_features.hpp`: it checks three cyclic
G decompositions and five rank-two three-term Plücker sign relations. For
`m`, the checker uses the four-circuit/Gordan criterion over all 64 sign
vectors modulo global reversal. This is independent of the Karp/Plücker
variation implementation used by the companion all-move-labeled audit.

The output in `verify_projected41_bound_independent.log` includes the exact
counts by `m`, the 132,196,512 base and 12,592,384 G distinct edges, and
counts of excluded missing 50-key or invalid G destinations. The companion
checker `../grassmann_37_continuation/history_20261108/verify_rank41_unfiltered_all_edges.cpp`
checks the same rank on all 230,629,888 **move-labeled** full edges using a
separate symbolic event reconstruction and Karp variation computation.

## Reproduction

From this directory:

```sh
c++ -O3 -std=c++17 -pthread verify_projected41_bound_independent.cpp -o verify_projected41_bound_independent
./verify_projected41_bound_independent
```

The input rank file and the shared generator/table must be present at the
relative paths above. This is a computer-assisted finite certificate, with
the stated shared-basis dependency; it is not a hand-verifiable replacement
for the underlying graph-coverage proof.
