#!/usr/bin/env python3
"""Independently check all 12 moment-curve examples by Vandermonde formulas."""
from fractions import Fraction
from itertools import combinations
from pathlib import Path
import json
P=list(combinations(range(1,8),3))
F=[(1,2,3,4),(1,3,2,4),(1,4,2,3),(1,2,3,5),(1,3,2,5),(1,5,2,3),(1,2,4,5),(1,4,2,5),(1,5,2,4),(1,3,4,5),(1,4,3,5),(1,5,3,4),(2,3,4,5),(2,4,3,5),(2,5,3,4)]
z=json.loads(Path('h12_moment_examples.json').read_text());assert len(z)==12
out=[]
for name,obj in z.items():
 t=obj['t'];assert len(t)==7 and all(t[i]<t[i+1] for i in range(6))
 assert obj['initial_columns']==[[(-1)**i,(-1)**i*t[i-1],(-1)**i*t[i-1]**2] for i in range(1,8)]
 def p(i,j,k):
  a,b,c=t[i-1],t[j-1],t[k-1]
  return (-1)**(i+j+k)*(b-a)*(c-a)*(c-b)
 minors=[p(*I) for I in P];assert all(x and ((x>0)==(sum(I)%2==0)) for x,I in zip(minors,P))
 fs=[p(a,b,6)*p(c,d,7)-p(a,b,7)*p(c,d,6) for a,b,c,d in F];assert all(fs)
 gs=[p(1,2,5)*p(3,4,j)-p(1,2,j)*p(3,4,5) for j in (6,7)];assert gs[0]<0<gs[1] and fs[0]<0
 ratios=[Fraction(p(1,2,i),p(3,4,i)) for i in (5,6,7)];assert ratios[0]>ratios[1]>ratios[2]>0
 fword=sum((1<<i) for i,x in enumerate(fs) if x>0);assert fword==int(name)==obj['Fword'] and obj['g']==2
 key=sum(1<<i for i,x in enumerate(minors+fs+gs) if x>0);out.append((fword,key))
assert len({f for f,k in out})==12
Path('moment_example_keys.txt').write_text(''.join(f'{f} {k}\n' for f,k in sorted(out)))
print('PASS 12 exact alternating Vandermonde configurations, 52 strict signs and strict r5>r6>r7')
