# Integer-time obstruction for the simple moment start

Let the fixed initial columns be
\[
 v_i=(-1)^i(1,i,i^2),\qquad i=1,\ldots,7.
\]
There is **no** 12-target-change trajectory of exactly 28 positive shears
from this start with all 28 shear parameters positive integers and all 35
maximal minors nonzero at every recorded vertex. This statement uses the
computer-assisted 28-move lower certificate and a small finite sign-graph
check. It does **not** exclude rational shear times, other starting matrices,
or a path allowed to have an incidental zero minor at a recorded vertex.

Every 28-move 12-change trajectory must begin with a target-flipping `U3`:
otherwise delete the first move and use its generic endpoint as the new
start, contradicting the 28-move lower bound. Write its positive integer
parameter as `a`. Direct determinant calculation gives
\[
 p_{123}=2-6a,\qquad p_{135}=-16+12a,\qquad p_{235}=6-6a.\tag{1}
\]
At `a=1` the third minor is zero at the recorded vertex, violating the
strictness assumption. For every integer `a>=2`, exactly the same three
first-five-column signs change: `p123` and `p235` become negative, while
`p135` becomes positive. The other first-five signs do not change.

The mandatory move-count argument leaves the two `(U1,U5)` budgets `(2,2)`
and `(1,3)`. Between the remaining 11 target-flipping `U3` moves, each of
the 11 available `U2/U4` moves must flip `p124`. The first-five
whole-shear sign overapproximation allows arbitrary sign-event order inside
each `U1`–`U4` move, and relaxes each `U5` to any jump preserving the four
first-four-column minors. `U6` is invisible to these five columns. It
therefore contains every true strict continuation. From the fixed sign
state after any `a>=2`, `probe_moment_integer_first_move.py` exhausts this
finite model and finds no 12-change continuation: 4,335 states for budget
`(2,2)` and 4,970 for `(1,3)`. The newer 3-by-6 profile certificate
independently excludes `(1,3)`, but is not needed for this two-case check.

From `../trajectory_search_20261108`, reproduce the calculation with

```sh
python3 probe_moment_integer_first_move.py
```

Its output is `probe_moment_integer_first_move.log`. The sign-graph
construction is in `probe_exact_28_move_patterns.py` and
`verify_at_most_one_j1_two_j5.py`; the global 28 lower bound and exact
rational 28 witness are documented separately in
`restriction_28_move_profile.md`.
