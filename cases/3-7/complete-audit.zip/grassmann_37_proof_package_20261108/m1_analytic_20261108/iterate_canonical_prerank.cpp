// Independent direct 12-prerank verifier for the 50+2 G lift.
// Shares only the original 50-state generator and rank certificate.  It does
// NOT include g_features.hpp or call GFeatures, eligible(), or SCC code.
// G static validity is implemented via five rank-two Pluecker sign relations
// plus explicit cyclic G decompositions; events come from the independently
// symbolically checked event_table.txt and six explicit G derivatives.
#define main old_graph_main_unused
#include "../grassmann_37_continuation/rebuild_full_graph.cpp"
#undef main

struct Test {int move,target,a,b,sign;};
int main(){
 init();auto dirs=direction_types(true);auto masks=sign_masks();
 Hash H(1ull<<25);vector<uint64_t>keys;keys.reserve(16051200);
 for(auto&w:dirs)for(auto&z:add_axes(w)){uint64_t base=word_key(z);for(auto m:masks){uint64_t k=base^m;H.insert(k,keys.size());keys.push_back(k);}}
 uint32_t n=keys.size();assert(n==16051200);
 vector<uint8_t>rank(n);ifstream in("../grassmann_37_continuation/filtered_rank.bin",ios::binary);
 in.read((char*)rank.data(),n);assert(in.gcount()==n);
 auto sg=[](uint64_t k,int bit){return k&(1ull<<bit)?1:-1;};
 auto p=[&](uint64_t k,int a,int b,int c){return sg(k,pid[a][b][c]);};
 auto valid=[&](uint64_t k,int g){
  int A[2][3][2]={
   {{p(k,1,2,5)*p(k,3,4,6),p(k,1,2,6)*p(k,3,4,5)},
    {p(k,1,3,4)*p(k,2,5,6),p(k,2,3,4)*p(k,1,5,6)},
    {p(k,1,2,4)*p(k,3,5,6),p(k,1,2,3)*p(k,4,5,6)}},
   {{p(k,1,2,5)*p(k,3,4,7),p(k,1,2,7)*p(k,3,4,5)},
    {p(k,1,3,4)*p(k,2,5,7),p(k,2,3,4)*p(k,1,5,7)},
    {p(k,1,2,4)*p(k,3,5,7),p(k,1,2,3)*p(k,4,5,7)}}};
  for(int i=0;i<2;i++){int desired=(g>>i&1)?1:-1;
   for(int r=0;r<3;r++)if(A[i][r][0]!=A[i][r][1]&&A[i][r][0]!=desired)return false;}
  int q[6]={p(k,1,2,5),p(k,3,4,5),p(k,1,2,6),p(k,3,4,6),p(k,1,2,7),p(k,3,4,7)};
  int B[6][6]{};B[1][2]=1;B[1][3]=q[1];B[2][3]=-q[0];B[1][4]=q[3];B[2][4]=-q[2];
  B[1][5]=q[5];B[2][5]=-q[4];B[3][4]=(g&1)?1:-1;B[3][5]=(g&2)?1:-1;B[4][5]=sg(k,35);
  for(int a=1;a<=2;a++)for(int b=a+1;b<=3;b++)for(int c=b+1;c<=4;c++)for(int d=c+1;d<=5;d++){
   int z=B[a][b]*B[c][d]-B[a][c]*B[b][d]+B[a][d]*B[b][c];if(abs(z)==3)return false;}
  return true;
 };
 vector<Test>E;ifstream ef("../grassmann_37_continuation/event_table.txt");Test t;
 while(ef>>t.move>>t.target>>t.a>>t.b>>t.sign)if(t.target<50)E.push_back(t);
 assert(E.size()==108);
 E.push_back({2,50,pid[1][3][4],pid[3][5][6],1});
 E.push_back({4,50,pid[1][2][5],pid[3][5][6],1});
 E.push_back({6,50,51,-1,1});
 E.push_back({2,51,pid[1][3][4],pid[3][5][7],1});
 E.push_back({4,51,pid[1][2][5],pid[3][5][7],1});
 E.push_back({5,51,35,-1,1});assert(E.size()==114);
 // Start with the independently computed BAD complement for round 0.
 // At later rounds, every state already outside C remains unchanged and
 // retains its previous tight path to rank<=1. So it suffices to reverse
 // search inside the previous C, seeding rank<=1 and tight exits from it.
 for(auto e:E)assert(e.target!=e.a&&e.target!=e.b);
 uint64_t N=uint64_t(n)*4;vector<uint8_t>bad((N+7)/8),active((N+7)/8),found((N+7)/8),F(N,255);
 ifstream badfile("tight_to_rank01.bin",ios::binary);badfile.read((char*)bad.data(),bad.size());assert(badfile.gcount()==int64_t(bad.size()));char extra;assert(!badfile.read(&extra,1));
 auto bit=[](const vector<uint8_t>&a,uint32_t c){return bool(a[c/8]&(1u<<(c%8)));};
 auto put=[](vector<uint8_t>&a,uint32_t c){a[c/8]|=1u<<(c%8);};
 auto clear=[](vector<uint8_t>&a,uint32_t c){a[c/8]&=~(1u<<(c%8));};
 vector<uint32_t>cur;cur.reserve(11000000);
 for(uint32_t u=0;u<n;u++)for(int g=0;g<4;g++)if(valid(keys[u],g)){
  uint32_t c=4*u+g;F[c]=rank[u];if(!bit(bad,c)){assert(F[c]>=2);put(active,c);F[c]-=2;cur.push_back(c);}
 }
 cout<<"round=0 reduced="<<cur.size()<<"\n";cout.flush();int round=1;
 while(!cur.empty()){
  vector<uint32_t>queue;queue.reserve(cur.size());
  // Seed active states that are already low or have a tight transition to
  // previously proven BAD. Their predecessors are propagated below.
  for(uint32_t c:cur){uint32_t u=c/4;int g=c%4;uint64_t k=keys[u],whole=k|(uint64_t(g)<<50);bool seed=F[c]<=1;
   uint64_t cand=0;if(!seed)for(auto e:E){int d=e.sign*sg(whole,e.a)*(e.b>=0?sg(whole,e.b):1);if(sg(whole,e.target)!=d)cand|=1ull<<e.target;}
   while(cand&&!seed){int t=__builtin_ctzll(cand);cand&=cand-1;uint32_t v=u;int h=g;
    if(t<50){v=H.find(k^(1ull<<t));if(v==UINT32_MAX)continue;}
    else h^=1<<(t-50);
    uint32_t d=4*v+h;if(F[d]==255||bit(active,d))continue;
    if(int(F[c])==int(F[d])+int(t==pid[1][2][3]))seed=true;
   }
   if(seed){put(found,c);queue.push_back(c);}
  }
  uint64_t seeds=queue.size();
  for(size_t head=0;head<queue.size();head++){
   uint32_t c=queue[head],u=c/4;int g=c%4;uint64_t k=keys[u],whole=k|(uint64_t(g)<<50),cand=0;
   for(auto e:E){int d=e.sign*sg(whole,e.a)*(e.b>=0?sg(whole,e.b):1);if(sg(whole,e.target)==d)cand|=1ull<<e.target;}
   while(cand){int t=__builtin_ctzll(cand);cand&=cand-1;uint32_t v=u;int h=g;
    if(t<50){v=H.find(k^(1ull<<t));if(v==UINT32_MAX)continue;}
    else h^=1<<(t-50);
    uint32_t d=4*v+h;if(F[d]==255||!bit(active,d)||bit(found,d))continue;
    if(int(F[d])!=int(F[c])+int(t==pid[1][2][3]))continue;
    put(found,d);queue.push_back(d);
   }
   if((head+1)%1000000==0){cerr<<"round="<<round<<" reverse-examined="<<head+1<<" queued="<<queue.size()<<"\n";}
  }
  vector<uint32_t>next;next.reserve(cur.size()-queue.size());
  for(uint32_t c:cur){if(bit(found,c)){clear(active,c);clear(found,c);}else{
    assert(F[c]>=2);F[c]-=2;next.push_back(c);}}
  cout<<"round="<<round<<" previous_active="<<cur.size()<<" boundary_seeds="<<seeds<<" newly_bad="<<queue.size()<<" reduced="<<next.size()<<"\n";cout.flush();
  cur.swap(next);round++;
 }
 vector<uint8_t>opt(N);ifstream oi("../grassmann_37_continuation/new_work/augmented_optimal_rank.bin",ios::binary);
 oi.read((char*)opt.data(),opt.size());assert(oi.gcount()==int64_t(opt.size()));uint64_t checked=0;
 for(uint32_t c=0;c<N;c++)if(F[c]!=255){int h=opt[c];assert(h<=12);int pi=!(keys[c/4]&1);int hp=h+((h+pi)&1);
  if(F[c]!=hp){cerr<<"iteration mismatch "<<c<<" F="<<int(F[c])<<" Hpi="<<hp<<"\n";abort();}checked++;
 }else assert(opt[c]==255);
 cout<<"PASS explicit fixed point equals parity-rounded optimal H on all "<<checked<<" states\n";
 ofstream out("iterated_canonical_prerank.bin",ios::binary);out.write((char*)F.data(),F.size());assert(out);
}
