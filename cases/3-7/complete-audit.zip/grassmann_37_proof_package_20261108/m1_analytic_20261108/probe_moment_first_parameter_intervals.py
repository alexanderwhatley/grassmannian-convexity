#!/usr/bin/env python3
"""Rule out integer first j3 time >=2 in any optimal 28-move moment path.

Uses the strict-separator first-five overapproximation. The result is a
computer-assisted necessary condition, not a claim about other start matrices.
"""
from collections import deque
from contextlib import redirect_stdout
from pathlib import Path
import io,runpy
with redirect_stdout(io.StringIO()):n=runpy.run_path(str(Path('../trajectory_search_20261108/probe_exact_28_move_patterns.py')))
start,at,cl,groups,group=[n[k] for k in ('start','at','closures','groups','group')]
def set_sign(w,I,positive):
    bit=1<<at[I];return w|bit if positive else w&~bit
# After first shear j3(a), a>=2 integer, the only first-five minors it can
# change are p123=2-6a<0, p135=-16+12a>0, p235=6-6a<0.
w=set_sign(set_sign(set_sign(start,(1,2,3),False),(1,3,5),True),(2,3,5),False)
assert w in set(n['states'])
def search(max1,max5):
    root=(w,1,True,0,0);todo=deque([root]);seen={root}
    while todo:
        x,k,need,a,b=todo.popleft()
        assert k<12,('formal 12-flip continuation found',max1,max5,x)
        def push(z):
            if z not in seen:seen.add(z);todo.append(z)
        if not need:
            for y in cl[x,3]:
                if (x^y)>>at[1,2,3]&1:push((y,k+1,True,a,b))
        if need:
            for j in (2,4):
                for y in cl[x,j]:
                    if (x^y)>>at[1,2,4]&1:push((y,k,False,a,b))
        if a<max1:
            for y in cl[x,1]:push((y,k,need,a+1,b))
        if b<max5:
            for y in groups[group(x)]:push((y,k,need,a,b+1))
    return len(seen)

for name,sg135,sg235 in [('one_third_to_one',False,True),('one_to_four_thirds',False,False),('above_four_thirds',True,False)]:
 w=set_sign(set_sign(set_sign(start,(1,2,3),False),(1,3,5),sg135),(2,3,5),sg235)
 assert w in set(n['states'])
 for a,b in ((2,2),(1,3)):
  try:
   count=search(a,b);print(name,(a,b),'visited',count,'no formal 12-flip continuation')
  except AssertionError as e:print(name,(a,b),'FORMAL 12-path survives',e)
