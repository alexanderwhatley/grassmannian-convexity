#!/usr/bin/env python3
"""Exact four-flip witness from the all-positive-covector rank-8 example.

The data give rational corner-cutting factors lambda in (0,1).  We track
v_j=x_j q_j with fixed omega=z and convert each factor to the positive
original shear t=lambda*x_j/((1-lambda)*x_{j+1}).  All 35 minors are checked
at every vertex with exact rational arithmetic.
"""
from fractions import Fraction as Q
from itertools import combinations
from pathlib import Path
import json,sys
V=[[Q(0),Q(0),Q(1)],[Q(5),Q(25),Q(1)],[Q(-3),Q(-7),Q(1)],[Q(-2),Q(-5),Q(1)],[Q(-7),Q(0),Q(1)],[Q(5),Q(-24),Q(1)],[Q(4),Q(-10),Q(1)]]
q=[a[:] for a in V];x=[Q(1)]*7;I=list(combinations(range(7),3))
def det(a,b,c):return a[0]*(b[1]*c[2]-b[2]*c[1])-a[1]*(b[0]*c[2]-b[2]*c[0])+a[2]*(b[0]*c[1]-b[1]*c[0])
def minors(v):return [det(*(v[j] for j in ix)) for ix in I]
p=minors(V);assert all(p);old=p[0]>0;flips=[];moves=[]
source=Path(sys.argv[1]) if len(sys.argv)>1 else Path('uniform_rank8_four_lambdas.txt')
rows=[tuple(map(int,line.split())) for line in source.read_text().splitlines()]
for step,(j,a,b) in enumerate(rows,1):
 j-=1;lam=Q(a,b);assert 0<=j<6 and 0<lam<1
 t=lam*x[j]/((1-lam)*x[j+1]);assert t>0;moves.append([j+1,str(t)])
 V[j]=[V[j][k]+t*V[j+1][k] for k in range(3)]
 q[j]=[(1-lam)*q[j][k]+lam*q[j+1][k] for k in range(3)]
 x[j]/=1-lam
 assert all(V[j][k]==x[j]*q[j][k] for k in range(3))
 p=minors(V);assert all(p),(step,'zero minor')
 now=p[0]>0
 if now!=old:flips.append(step)
 old=now
assert len(flips)==4
print('PASS',len(rows),'exact positive rational shears, all 35 minors strict at all vertices')
print('PASS target changes at steps',flips,'and final all minors positive:',all(t>0 for t in p))
Path('uniform_rank8_four_tiny_moves.json' if 'tiny' in source.name else 'uniform_rank8_four_short_moves.json' if 'short' in source.name else 'uniform_rank8_four_moves.json').write_text(json.dumps({'initial_columns':[[int(z) for z in row] for row in [[0,0,1],[5,25,1],[-3,-7,1],[-2,-5,1],[-7,0,1],[5,-24,1],[4,-10,1]]], 'moves':moves,'flips':flips},indent=2)+'\n')
