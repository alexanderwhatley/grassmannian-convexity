#!/usr/bin/env python3
"""Exact data for the sample-289 open rank case; stdlib only."""
from functools import cmp_to_key
from itertools import combinations
V0=[[-79,-53,1],[-18,-70,1],[22,36,1],[-8,62,1],[51,-99,1],[86,-24,1],[89,38,1]]
I=list(combinations(range(1,8),3));F=[(1,2,3,4),(1,3,2,4),(1,4,2,3),(1,2,3,5),(1,3,2,5),(1,5,2,3),(1,2,4,5),(1,4,2,5),(1,5,2,4),(1,3,4,5),(1,4,3,5),(1,5,3,4),(2,3,4,5),(2,4,3,5),(2,5,3,4)]
def det(a,b,c):return a[0]*(b[1]*c[2]-b[2]*c[1])-b[0]*(a[1]*c[2]-a[2]*c[1])+c[0]*(a[1]*b[2]-a[2]*b[1])
def minors(v):return {T:det(*(v[x-1] for x in T)) for T in I}
p=minors(V0);assert all(p.values()) and p[1,2,3]==7146 and p[5,6,7]>0
fs=[p[a,b,6]*p[c,d,7]-p[a,b,7]*p[c,d,6] for a,b,c,d in F];gs=[p[1,2,5]*p[3,4,j]-p[1,2,j]*p[3,4,5] for j in (6,7)]
assert all(fs+gs)
key=sum((v>0)<<i for i,v in enumerate(list(p.values())+fs+gs));assert key==10135984468027
# omega=z is positive on all seven initial columns.
assert all(col[2]==1 for col in V0)
w=[(V0[j+1][0]-V0[j][0],V0[j+1][1]-V0[j][1]) for j in range(6)]
rays=[(a,b,i+1) for i,(a,b) in enumerate(w)]+[(-a,-b,-i-1) for i,(a,b) in enumerate(w)]
def cmp(a,b):
 ha=a[1]>0 or (a[1]==0 and a[0]>=0);hb=b[1]>0 or (b[1]==0 and b[0]>=0)
 if ha!=hb:return -1 if ha else 1
 z=a[0]*b[1]-a[1]*b[0];assert z;return -1 if z>0 else 1
rays.sort(key=cmp_to_key(cmp));word=[x[2] for x in rays];r=word.index(1);word=word[r:]+word[:r]
assert word==[1,5,2,6,-4,3,-1,-5,-2,-6,4,-3]
pos=[word.index(i) for i in range(1,7)];d=[]
for a,b in zip(pos,pos[1:]):
 z=(b-a)%12;assert z not in (0,6)
 if z>6:z-=12
 d.append(z)
assert d==[2,3,5,3,2] and 2*(sum(d)//6)==4
v=[z[:] for z in V0];targets=[p[1,2,3]]
for j,t in [(4,14),(3,2000),(5,1),(4,1),(3,100)]:
 v[j-1]=[v[j-1][k]+t*v[j][k] for k in range(3)];p=minors(v);assert all(p.values());targets.append(p[1,2,3])
assert targets==[7146,7146,-236854,-236854,-236854,148746] and all(z>0 for z in p.values())
print('PASS 52 strict initial features; key',key,'and omega=z>0')
print('PASS cyclic word',word,'increments',d,'projected rank 4')
print('PASS five exact positive integer shears, 35 minors strict at all six vertices')
print('PASS two target changes:',targets,'and all final minors positive')
