#!/usr/bin/env python3
"""Exact bilinear verification of the 2/3 moment-start covector proof."""
from fractions import Fraction as Q
from itertools import product
v0=[[(-1)**i,(-1)**i*i,(-1)**i*i*i] for i in range(1,8)]
def dot(a,b):return sum(x*y for x,y in zip(a,b))
for a,e in product((0,1),repeat=2):
 v=[x[:] for x in v0];v[2]=[v[2][k]+a*v[3][k] for k in range(3)];w=(14-3*e,-9+e,1)
 actual=[dot(w,z) for z in v];expected=[-6+2*e,-e,4-6*a+a*e,-6+e,6-2*e,-4+3*e,-4*e];assert actual==expected
# Both sides are bilinear in a,e, so these four exact evaluations establish
# all seven displayed polynomial identities.
def det(a,b,c):return a[0]*(b[1]*c[2]-b[2]*c[1])-b[0]*(a[1]*c[2]-a[2]*c[1])+c[0]*(a[1]*b[2]-a[2]*b[1])
for a in (Q(0),Q(1),Q(2,3)):
 v=[list(map(Q,x)) for x in v0];v[2]=[v[2][k]+a*v[3][k] for k in range(3)]
 assert det(*v[:3])==2-6*a
 if a==Q(2,3):assert det(v[1],v[2],v[6])==0
print('PASS all seven exact bilinear covector identities')
print('PASS p123=2−6a and p237=0 at a=2/3')
