// Find an abstract H-tight path from sample 289 to its first target flip.
// An edge model path is not a real positive trajectory.
#define main gc37_old_main
#include "../grassmann_37_continuation/rebuild_full_graph.cpp"
#undef main
#include "../grassmann_37_continuation/history_20261108/g_features.hpp"
int main(){
 init();GFeatures G;auto dirs=direction_types(true);auto masks=sign_masks();Hash lookup(1ull<<25);vector<uint64_t>keys;keys.reserve(16051200);
 for(auto&w:dirs)for(auto&z:add_axes(w)){uint64_t base=word_key(z);for(auto m:masks){lookup.insert(base^m,keys.size());keys.push_back(base^m);}}
 const uint32_t n=keys.size();assert(n==16051200);vector<uint8_t>rank(uint64_t(n)*4);ifstream in("../grassmann_37_continuation/new_work/augmented_optimal_rank.bin",ios::binary);in.read((char*)rank.data(),rank.size());assert(in.gcount()==int64_t(rank.size()));
 uint64_t sample=10135984468027ull;int g=sample>>50;uint32_t u=lookup.find(sample&((1ull<<50)-1));assert(u!=UINT32_MAX&&rank[4ull*u+g]==4);uint32_t start=4*u+g;

 struct EdgeRec{uint32_t a,b;uint8_t f,j;};vector<EdgeRec> arcs;vector<uint8_t>dist(uint64_t(n)*4,255);vector<uint32_t>queue;queue.push_back(start);dist[start]=0;int goaldepth=255;vector<uint32_t>goals;
 auto enqueue=[&](uint32_t cur,uint32_t next,int f,int j){
  int nd=dist[cur]+1;if(nd>goaldepth)return;
  if(dist[next]==255){dist[next]=nd;queue.push_back(next);}
  if(dist[next]==nd){arcs.push_back({cur,next,(uint8_t)f,(uint8_t)j});if(f==0&&nd<=goaldepth){goaldepth=nd;goals.push_back(next);}}
 };
 for(size_t h=0;h<queue.size();h++){
  uint32_t curr=queue[h],b=curr/4;int gg=curr%4,rv=rank[curr];if(dist[curr]>=goaldepth)continue;
  uint64_t key=keys[b],full=key|(uint64_t(gg)<<50);
  for(auto&e:events)if(eligible(key,e)){
   uint32_t v=lookup.find(key^(1ull<<e.target));if(v==UINT32_MAX)continue;uint32_t next=4*v+gg;int r2=rank[next];if(r2==255||rv!=r2+(e.target==0))continue;
   enqueue(curr,next,e.target,e.move);
  }
  for(auto&e:G.new_events)if(eligible(full,e)){
   int gg2=gg^(1<<(e.target-50));uint32_t next=4*b+gg2;int r2=rank[next];if(r2==255||rv!=r2)continue;enqueue(curr,next,e.target,e.move);
  }
 }
 assert(goaldepth<255);vector<uint8_t>good(uint64_t(n)*4);for(auto x:goals)if(dist[x]==goaldepth)good[x]=1;
 for(int d=goaldepth-1;d>=0;d--)for(auto e:arcs)if(dist[e.a]==d&&good[e.b])good[e.a]=1;
 assert(good[start]);vector<EdgeRec>first;for(auto e:arcs)if(e.a==start&&good[e.b])first.push_back(e);
 cout<<"minimum_abstract_length="<<goaldepth<<" visited="<<queue.size()<<" arcs="<<arcs.size()<<" goal_vertices="<<goals.size()<<" first_edges="<<first.size()<<"\n";
 ofstream out("sample289_shortest_first2.txt");int pairs=0;
 for(auto f:first)for(auto e:arcs)if(e.a==f.b&&good[e.b]){
  uint64_t k1=keys[f.b/4]|(uint64_t(f.b%4)<<50),k2=keys[e.b/4]|(uint64_t(e.b%4)<<50);
  out<<int(f.j)<<' '<<int(f.f)<<' '<<k1<<' '<<int(e.j)<<' '<<int(e.f)<<' '<<k2<<'\n';pairs++;
 }
 cout<<"shortest_first_two_labeled_pairs="<<pairs<<"\n";
}
