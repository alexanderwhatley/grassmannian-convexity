#!/usr/bin/env python3
"""Exact certificate: every positive covector yields projected rank 8.

The 15 displayed positive-cone identities are verified with Fractions.
A second fixed covector has signs --+++++ and projected cyclic rank 3.
"""
from fractions import Fraction as Q
from functools import cmp_to_key
from itertools import combinations
V=[None,[0,0,1],[5,25,1],[-3,-7,1],[-2,-5,1],[-7,0,1],[5,-24,1],[4,-10,1]]
F=[(1,2,3,4),(1,3,2,4),(1,4,2,3),(1,2,3,5),(1,3,2,5),(1,5,2,3),(1,2,4,5),(1,4,2,5),(1,5,2,4),(1,3,4,5),(1,4,3,5),(1,5,3,4),(2,3,4,5),(2,4,3,5),(2,5,3,4)]
def det(a,b,c):return a[0]*(b[1]*c[2]-b[2]*c[1])-a[1]*(b[0]*c[2]-b[2]*c[0])+a[2]*(b[0]*c[1]-b[1]*c[0])
def p(a,b,c):return det(V[a],V[b],V[c])
D={
 (1,2):[(2,40)],(1,3):[(1,Q(85,8)),(4,Q(15,4)),(7,Q(5,8))],
 (1,4):[(1,Q(125,2)),(5,Q(1225,24)),(6,Q(875,24))],(1,5):[(5,245),(6,175)],(1,6):[(1,49),(2,46)],
 (2,3):[(3,16)],(2,4):[(2,15),(3,185)],(2,5):[(5,392),(6,184)],(2,6):[(2,95),(3,49)],
 (3,4):[(4,15)],(3,5):[(5,33),(6,15)],(3,6):[(2,Q(396,49)),(5,Q(11,4)),(6,Q(1013,196))],
 (4,5):[(5,60)],(4,6):[(6,5),(7,60)],(5,6):[(6,144)]}
for i,j in combinations(range(1,7),2):
 s=(-1)**(i+j+1);L=[s*(p(i,i+1,j+1)*V[j][r]-p(i,i+1,j)*V[j+1][r]) for r in range(3)]
 assert all(c>0 for _,c in D[i,j])
 assert L==[sum(c*V[k][r] for k,c in D[i,j]) for r in range(3)]
print('PASS 15 exact positive-cone identities; every common-positive covector has alternating projected signs')
mins=[p(*I) for I in combinations(range(1,8),3)];fs=[p(a,b,6)*p(c,d,7)-p(a,b,7)*p(c,d,6) for a,b,c,d in F];gs=[p(1,2,5)*p(3,4,j)-p(1,2,j)*p(3,4,5) for j in (6,7)]
assert all(mins+fs+gs) and p(5,6,7)>0
key=sum(1<<i for i,x in enumerate(mins+fs+gs) if x>0);assert key==580502729194919
print('PASS 52 features strict; exact key',key)
def cyclic(w):
 x=[None]+[sum(w[k]*V[i][k] for k in range(3)) for i in range(1,8)];assert all(x[1:])
 vec=[None]+[[Q(V[i+1][k])-Q(x[i+1],x[i])*V[i][k] for k in range(3)] for i in range(1,7)]
 z=[Q(V[5][k],x[5]) for k in range(3)];pair={}
 for i,j in combinations(range(1,7),2):
  a=det(vec[i],vec[j],z);assert a;pair[i,j]=1 if a>0 else -1
 assert pair[5,6]>0
 def orient(a,b):
  s=1
  if a<0:s=-s;a=-a
  if b<0:s=-s;b=-b
  if a>b:a,b=b,a;s=-s
  return s*pair[a,b]
 def half(a):return 0 if a==1 else 2 if a==-1 else 1 if orient(1,a)>0 else 3
 def cmp(a,b):
  u,v=half(a),half(b)
  return (-1 if u<v else 1) if u!=v else 0 if a==b else -1 if orient(a,b)>0 else 1
 labels=[z for i in range(1,7) for z in (i,-i)];labels.sort(key=cmp_to_key(cmp));pos=[labels.index(i) for i in range(1,7)]
 ds=[(b-a)%12 for a,b in zip(pos,pos[1:])];assert all(d not in (0,6) for d in ds);ds=[d if d<6 else d-12 for d in ds]
 runs=[]
 for a in ds:
  if not runs or a*runs[-1][0]<0:runs.append([a,abs(a)])
  else:runs[-1][1]+=abs(a)
 rank=len(runs)-1+2*sum(t//6 for _,t in runs)
 return x[1:],labels,rank
for omega,expected in [((0,0,1),8),((-1,-1,-3),3)]:
 x,word,r=cyclic(omega);assert r==expected;print('omega',omega,'x',x,'word',word,'rank',r)
