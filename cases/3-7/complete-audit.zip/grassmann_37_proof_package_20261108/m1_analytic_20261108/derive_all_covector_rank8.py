#!/usr/bin/env python3
"""Exact positive-cone certificates for universal projected rank 8."""
from fractions import Fraction as Q
from itertools import combinations
V=[[0,0,1],[5,25,1],[-3,-7,1],[-2,-5,1],[-7,0,1],[5,-24,1],[4,-10,1]]
def det(a,b,c):return a[0]*(b[1]*c[2]-b[2]*c[1])-a[1]*(b[0]*c[2]-b[2]*c[0])+a[2]*(b[0]*c[1]-b[1]*c[0])
def p(a,b,c):return det(V[a-1],V[b-1],V[c-1])
for i,j in combinations(range(1,7),2):
 a=p(i,i+1,j+1);b=p(i,i+1,j);s=(-1)**(i+j+1)
 L=[s*(a*V[j-1][k]-b*V[j][k]) for k in range(3)];assert any(L)
 cand=[]
 for A,B,C in combinations(range(1,8),3):
  den=p(A,B,C);assert den
  co=(Q(det(L,V[B-1],V[C-1]),den),Q(det(V[A-1],L,V[C-1]),den),Q(det(V[A-1],V[B-1],L),den))
  if all(x>=0 for x in co) and any(co):
   cand.append((sum(x!=0 for x in co),sum(x.denominator for x in co),A,B,C,co))
 assert cand,('no positive-cone decomposition',i,j,L)
 _,_,A,B,C,co=min(cand)
 assert [sum(co[t]*V[(A,B,C)[t]-1][k] for t in range(3)) for k in range(3)]==L
 terms=[f'{x}*v{q}' for q,x in zip((A,B,C),co) if x]
 print(f'{i}{j}:', ' + '.join(terms))
print('PASS all 15 signed projected-determinant coefficient vectors are in the positive column cone')
