# Canonical prerank reduction and the exact graph rank

## General theorem

Let \(G\) be a finite directed graph with edge weights \(w\in\{0,1\}\).
Assume there is a vertex parity \(\pi\in\{0,1\}\) satisfying
\(\pi(u)-\pi(v)\equiv w(u,v)\pmod2\) on every edge. Assume a nonnegative
integer prerank exists, so the total edge weight of any directed walk is
bounded. Let \(H(s)\) be the maximum total edge weight of a finite walk
starting at \(s\), with the empty walk permitted. Set
\[
\widehat H(s)=H(s)+(\pi(s)-H(s)\bmod2),
\]
where the remainder is in \(\{0,1\}\). Thus \(\widehat H\) is the smallest
integer at least \(H\) having parity \(\pi\).

A nonnegative integer prerank \(F\) is **parity-correct** when
\(F(s)\equiv\pi(s)\pmod2\). Let
\[
C(F)=\{s:\text{no $F$-tight path from $s$ reaches a state with }F\le1\},
\quad
\mathcal T(F)=F-2\mathbf1_{C(F)},
\]
where an edge is \(F\)-tight if \(F(u)=F(v)+w(u,v)\).

**Theorem.** \(\widehat H\) is the pointwise least nonnegative
parity-correct prerank and
\[
C(F)=\{s:F(s)>\widehat H(s)\},\qquad
\mathcal T(F)=\max\{\widehat H,F-2\}.\tag{1}
\]
Consequently
\[
\mathcal T^k(F)=\max\{\widehat H,F-2k\},\tag{2}
\]
and the iteration reaches its unique fixed point \(\widehat H\) after
\(\max_s(F(s)-\widehat H(s))/2\) reductions.

**Proof.** Every nonnegative prerank \(F\) dominates \(H\): sum its edge
inequalities along any walk. If \(F\) is parity-correct, it therefore
pointwise dominates \(\widehat H\). To see that \(\widehat H\) is itself a
prerank, consider an edge \(u\to v\). If
\(H(u)=H(v)+w(u,v)\), then the parity corrections in \(\widehat H(u)\) and
\(\widehat H(v)\) agree. If the \(H\)-inequality has at least one unit of
slack, changing the correction by at most one cannot violate it.

Suppose an \(F\)-tight path from \(s\) ends at \(t\) with \(F(t)\le1\).
Its weight is \(F(s)-F(t)\ge F(s)-1\), so
\(H(s)\ge F(s)-1\). Because \(\widehat H(s)\) and \(F(s)\) have the same
parity and \(\widehat H(s)\le F(s)\), this forces equality. Hence a state
with \(F>\widehat H\) lies in \(C(F)\).

Conversely, suppose \(F(s)=\widehat H(s)\). Choose a finite walk from \(s\)
of total weight \(H(s)\). Every edge in it is \(H\)-tight, and its endpoint
has \(H=0\); otherwise it could be extended to achieve a larger weight.
Along each such edge the parity correction is unchanged, so the walk is
also \(\widehat H\)-tight. Since \(F\ge\widehat H\), equality at the
starting vertex and the prerank inequalities force equality at every vertex
of this walk. Its endpoint has \(F=\widehat H\in\{0,1\}\). Thus
\(s\notin C(F)\), proving the first part of (1). Parity makes every positive
value of \(F-\widehat H\) at least 2, proving the second part. Equation (2)
then follows by induction. ∎

The theorem is graph-theoretic and does not require the sign graph in the
application to be realizable by actual matrices. It also explains why a
parity-correct fixed point may differ from \(H\): the unrestricted optimal
rank need not itself have parity \(\pi\).

## The (3,7) sign graph

Apply the theorem to the 23,246,848 accepted 52-sign states, with weight 1
exactly on target changes and \(\pi=[p_{123}<0]\). The old 50-sign rank
\(R\) is a parity-correct prerank. The exact 52-sign graph optimal rank
\(H\) was constructed by SCC contraction in
`../grassmann_37_continuation/new_work/augmented_scc_optimal.cpp` and saved
as `../grassmann_37_continuation/new_work/augmented_optimal_rank.bin`.
The direct checker `verify_optimal_rank_bound_independent.cpp` verifies the
rank inequalities and \(H\le8+m\) on every accepted state and every edge,
without reading the old rank, any closed-set bitset, or SCC code. The proof
of the upper bound only needs these direct inequalities, not optimality.
Independently, `verify_optimal_rank_independent.cpp` verifies the graph
inequalities and reaches every accepted state backward from \(H=0\) along
\(H\)-tight edges; this certifies that every H value is attained by a
finite abstract path, and hence is the exact graph optimal rank.

The full iteration was then performed independently by repeated reverse
reachability, without consulting \(H\) to select states. These are the
numbers of states reduced by 2 in each successive round:
\[
10{,}855{,}286,\quad62{,}806,\quad42{,}601,\quad28{,}355,\quad8{,}546,
\quad634,\quad0.
\]
The resulting fixed point equals \(\widehat H\) on all 23,246,848 accepted
states. The original difference \((R-\widehat H)/2\) has distribution

| Difference | Number of states |
|---:|---:|
| 0 | 12,391,562 |
| 1 | 10,792,480 |
| 2 | 20,205 |
| 3 | 14,246 |
| 4 | 19,809 |
| 5 | 7,912 |
| 6 | 634 |

Thus six reductions are necessary and sufficient. The optimal rank \(H\)
itself disagrees with the prescribed vertex parity on 25,519 states; those
are raised by 1 in \(\widehat H\).

## Reproduction

```sh
c++ -O3 -std=c++17 -pthread compare_canonical_iteration_to_H.cpp -o compare_canonical_iteration_to_H
./compare_canonical_iteration_to_H
c++ -O3 -std=c++17 -pthread iterate_canonical_prerank.cpp -o iterate_canonical_prerank
./iterate_canonical_prerank
c++ -O3 -std=c++17 -pthread verify_optimal_rank_bound_independent.cpp -o verify_optimal_rank_bound_independent
./verify_optimal_rank_bound_independent
c++ -O3 -std=c++17 -pthread verify_optimal_rank_independent.cpp -o verify_optimal_rank_independent
./verify_optimal_rank_independent
```

The corresponding `.log` files contain recorded outputs. These computations
share the old 50-key generator and event table, whose coverage and symbolic
checks are described in `audit_50_and_g_coverage.md`. In particular, no
claim of external review or of an elementary proof is implied by this note.
