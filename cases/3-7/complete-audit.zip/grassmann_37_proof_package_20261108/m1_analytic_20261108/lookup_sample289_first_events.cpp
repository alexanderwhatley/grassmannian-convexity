// Direct lookup for the explicit rank-8 projection example.
#define main old_graph_main_unused
#include "../grassmann_37_continuation/rebuild_full_graph.cpp"
#undef main
int main(){
 init();auto dirs=direction_types(true);auto masks=sign_masks();Hash H(1ull<<25);uint32_t n=0;
 for(auto&w:dirs)for(auto&z:add_axes(w)){uint64_t b=word_key(z);for(auto m:masks)H.insert(b^m,n++);}assert(n==16051200);
 vector<uint8_t>h(uint64_t(n)*4);ifstream in("../grassmann_37_continuation/new_work/augmented_optimal_rank.bin",ios::binary);
 in.read((char*)h.data(),h.size());assert(in.gcount()==int64_t(h.size()));

 const uint64_t kk[]={10135984468027ull,9998545514555ull,10135984468019ull,10136118685755ull,10135984468031ull,10135917359163ull};
 for(auto key:kk){uint32_t u=H.find(key&((1ull<<50)-1));assert(u!=UINT32_MAX);int g=key>>50;cout<<key<<" rank="<<int(h[4ull*u+g])<<"\n";}
}
