#!/usr/bin/env python3
"""Relaxed simultaneous rank-2 projection paths for sample 289.

Each factor permits every cyclic-word event allowed in its own projection;
non-target events may occur independently, while target events synchronize.
This over-approximates real positive paths. A surviving path proves no
realizability claim. It checks whether two projections can rule out four flips.
"""
import json,sys,contextlib,io
from itertools import combinations
from collections import deque
sys.path.insert(0,'../analytic_agent')
with contextlib.redirect_stdout(io.StringIO()):from optimize_fixed_functional import G
rows=json.load(open('sample289_rank4_covectors.json'));starts=[G.WI[tuple(x['word'])] for x in rows]
assert all(G.rank(G.words[i])==4 for i in starts)
silent=[[] for _ in G.words];target=[[] for _ in G.words]
for i,w in enumerate(G.words):
 r=G.rank(w)
 for j,weight,move in G.CE[i]:
  rj=G.rank(G.words[j]);assert rj<=r-weight
  if weight==0 and r==rj:silent[i].append(j)
  if weight==1 and r==rj+1:target[i].append(j)

def bfs(a,b):
 seen={(a,b)};Q=deque([(a,b)])
 while Q:
  x,y=Q.popleft();rx=G.rank(G.words[x]);ry=G.rank(G.words[y]);assert rx==ry
  if rx==0:return True,len(seen)
  for xx in silent[x]:
   z=(xx,y)
   if z not in seen:seen.add(z);Q.append(z)
  for yy in silent[y]:
   z=(x,yy)
   if z not in seen:seen.add(z);Q.append(z)
  for xx in target[x]:
   for yy in target[y]:
    z=(xx,yy)
    if z not in seen:seen.add(z);Q.append(z)
 return False,len(seen)
for i,j in combinations(range(len(starts)),2):
 ok,n=bfs(starts[i],starts[j]);print('pair',i,j,'abstract_4_possible',ok,'visited',n,flush=True)
 if not ok:
  print('PROMISING relaxed product rejects four for pair',i,j);break
else:print('All tested projection pairs have an abstract four-flip path; no new upper bound')
