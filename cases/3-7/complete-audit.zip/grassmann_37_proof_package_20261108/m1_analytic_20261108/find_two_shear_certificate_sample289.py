#!/usr/bin/env python3
"""Find a 1-shear transition to an elementary four-flip certificate.

Every candidate is selected strictly between exact rational minor roots. A
positive target is accepted if the dense-weight sign criterion proves rank 4;
a negative target is accepted if the negative minors fail to be an order
ideal, since the preceding target crossing plus rank-one theorem gives 4.
"""
from fractions import Fraction as Q
from itertools import combinations,permutations

V=[[-79,-53,1],[-18,-70,1],[22,36,1],[-8,62,1],[51,-99,1],[86,-24,1],[89,38,1]]
I=list(combinations(range(7),3));idx={a:i for i,a in enumerate(I)}
def det(a,b,c):return a[0]*(b[1]*c[2]-b[2]*c[1])-b[0]*(a[1]*c[2]-a[2]*c[1])+c[0]*(a[1]*b[2]-a[2]*b[1])
def minors(v):return [det(*(v[j] for j in T)) for T in I]
p=minors(V);assert all(p) and p[0]>0 and p[-1]>0
active=[];covers=[]
for j in range(6):
 act=[]
 for a,T in enumerate(I):
  if j in T and j+1 not in T:
   B=tuple(sorted(set(T)-{j}|{j+1}));act.append((a,idx[B]));covers.append((a,idx[B]))
 active.append(act)
assert len(covers)==60
feasible=[[u for u,K in enumerate(I) if all(a<=b for a,b in zip(T,K))] for T in I]
N={}
for order in permutations(range(7)):
 w=[0]*7
 for h,j in enumerate(order):w[j]=1<<h
 scores=[sum(w[j] for j in T) for T in I]
 dom=[max(choices,key=scores.__getitem__) for choices in feasible];top=dom[0]
 for a,b in covers:
  x,y=dom[a],dom[b]
  if x!=y and x!=top:N[x,y]=N.get((x,y),0)|(1<<top)

def reason(p):
 if p[0]<0:
  for a,b in covers:
   if p[a]>0>p[b]:return ('negative_target_inversion',I[a],I[b])
 else:
  pos=sum((x>0)<<i for i,x in enumerate(p));neg=((1<<35)-1)^pos
  for (a,b),tops in N.items():
   if (pos>>a&1) and (neg>>b&1) and (tops&neg):return ('positive_target_dominance',I[a],I[b],I[(tops&neg).bit_length()-1])
 return None
assert reason(p) is None

def intervals(p,j):
 act=active[j];roots=sorted(set(-Q(p[a],p[b]) for a,b in act if p[a]*p[b]<0));bounds=[Q(0)]+roots
 values=[]
 for x,y in zip(bounds,bounds[1:]):values.extend([(3*x+y)/4,(x+y)/2,(x+3*y)/4])
 values.extend([bounds[-1]+1,2*bounds[-1]+1,10*bounds[-1]+1])
 for t in values:
  q=p[:]
  for a,b in act:q[a]+=t*p[b]
  assert all(q)
  yield t,q
attempts=0
for j in range(6):
 for t,q in intervals(p,j):
  if q[0]<0:continue
  for h in range(6):
   for u,r in intervals(q,h):
    attempts+=1;how=reason(r)
    if how:
     print('PASS two positive shears',j+1,t,'then',h+1,u,'reason',how,'attempts',attempts)
     raise SystemExit
print('No two-shear witness found after',attempts,'tested')
