#!/usr/bin/env python3
"""Exact row-space variation and suffix flip counts of the 28 witness."""
from fractions import Fraction as Q
from itertools import combinations
from math import gcd
from functools import reduce
from pathlib import Path
import json
z=json.loads(Path('../trajectory_search_20261108/witness_28_integer.json').read_text());v=[tuple(map(int,c)) for c in z['initial_columns']];scale=[Q(1)]*7
I=list(combinations(range(7),3));C=list(combinations(range(7),4))
def det(a,b,c):return a[0]*(b[1]*c[2]-b[2]*c[1])-b[0]*(a[1]*c[2]-a[2]*c[1])+c[0]*(a[1]*b[2]-a[2]*b[1])
def properties(v):
 p={T:det(*(v[i] for i in T)) for T in I};assert all(p.values());best=7
 for bits in range(64):
  s=[-1 if bits>>i&1 else 1 for i in range(6)]+[1]
  if any(len({(s[a]*p[b,c,d]>0),(-s[b]*p[a,c,d]>0),(s[c]*p[a,b,d]>0),(-s[d]*p[a,b,c]>0)})==1 for a,b,c,d in C):continue
  best=min(best,sum(s[i]!=s[i+1] for i in range(6)))
 assert best<=4
 return best,p[0,1,2]>0
oldm,oldsign=properties(v);rows=[(0,oldm,0)];flips=0
for step,(j,t) in enumerate(z['moves'],1):
 j-=1;u=Q(t)*scale[j+1]/scale[j];a=[u.denominator*v[j][i]+u.numerator*v[j+1][i] for i in range(3)];g=reduce(gcd,map(abs,a));assert g;v[j]=tuple(x//g for x in a);scale[j]*=Q(g,u.denominator)
 m,sign=properties(v);flips+=sign!=oldsign;assert m<=oldm;oldm,oldsign=m,sign;rows.append((step,m,flips))
assert flips==12
for m in range(4,-1,-1):
 eligible=[(i,f) for i,mm,f in rows if mm==m and f==4-m]
 if eligible:
  step,f=eligible[-1];print('m=',m,'sharp suffix begins after move',step,'with',12-f,'target changes in',28-step,'moves')
 else:print('m=',m,'no suffix sharp for 8+m found in this witness')
print('variation drops:',[(i,m,f) for k,(i,m,f) in enumerate(rows) if k==0 or m<rows[k-1][1]])
