#!/usr/bin/env python3
from itertools import combinations
v=[[-79,-53,1],[-18,-70,1],[22,36,1],[-8,62,1],[51,-99,1],[86,-24,1],[89,38,1]]
I=list(combinations(range(7),3))
def det(a,b,c):return a[0]*(b[1]*c[2]-b[2]*c[1])-b[0]*(a[1]*c[2]-a[2]*c[1])+c[0]*(a[1]*b[2]-a[2]*b[1])
def minor():return [det(*(v[i] for i in z)) for z in I]
p=minor();assert all(p);targets=[p[0]]
for j,t in [(4,14),(3,2000),(5,1),(4,1),(3,100)]:
 v[j-1]=[v[j-1][k]+t*v[j][k] for k in range(3)];p=minor();assert all(p);targets.append(p[0])
assert targets==[7146,7146,-236854,-236854,-236854,148746] and all(x>0 for x in p)
print('PASS five positive integer shears, all 35 minors strict at every recorded vertex')
print('PASS target values',targets,'and all final minors positive')
