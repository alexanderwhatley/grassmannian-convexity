#!/usr/bin/env python3
"""Independent direct 3-vector rational replay of the 40-move transfer."""
from fractions import Fraction as Q
from itertools import combinations
from pathlib import Path
import json,sys
if hasattr(sys,'set_int_max_str_digits'):sys.set_int_max_str_digits(0)
path=Path(sys.argv[1]) if len(sys.argv)>1 else Path('constructive_transfer_40.json')
x=json.loads(path.read_text());v=[[Q(z) for z in col] for col in x['initial_columns']];moves=[(int(j),Q(t)) for j,t in x['moves']]
I=list(combinations(range(7),3))
def det(a,b,c):return a[0]*(b[1]*c[2]-b[2]*c[1])-b[0]*(a[1]*c[2]-a[2]*c[1])+c[0]*(a[1]*b[2]-a[2]*b[1])
def minors():return [det(*(v[i] for i in T)) for T in I]
p=minors();assert all(p) and p[-1]>0
assert all((p[k]>0)==(sum(i+1 for i in T)%2==0) for k,T in enumerate(I))
old=p[0]>0;flip=[]
for step,(j,t) in enumerate(moves,1):
 assert 1<=j<=6 and t>0
 v[j-1]=[v[j-1][k]+t*v[j][k] for k in range(3)];p=minors();assert all(p),(step,'zero minor')
 if (p[0]>0)!=old:flip.append(step)
 old=p[0]>0
assert len(moves)==40 and flip==[13,15,17,19,22,24,27,29,33,35,38,40]
print('PASS 40 exact rational shears; all 35 minors strict at all 41 vertices')
print('PASS no preparation flips; exactly 12 witness-tail flips at',flip)
