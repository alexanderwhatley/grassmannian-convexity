// Numerical tight-rank-guided corner-cutting search. Every saved candidate
// must be replayed with exact rational positive shears before use.
#define main gc37_old_main
#include "../grassmann_37_continuation/rebuild_full_graph.cpp"
#undef main
#include <cmath>
using A2=array<long double,2>;
struct Move{int j,num,den;};
long double det2(const A2&a,const A2&b,const A2&c){return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]);}
int main(){
 init();auto dirs=direction_types(true);auto masks=sign_masks();Hash H(1ull<<25);uint32_t n=0;
 for(auto&w:dirs)for(auto&z:add_axes(w)){uint64_t b=word_key(z);for(auto m:masks)H.insert(b^m,n++);}assert(n==16051200);
 vector<uint8_t>h(uint64_t(n)*4);ifstream in("../grassmann_37_continuation/new_work/augmented_optimal_rank.bin",ios::binary);in.read((char*)h.data(),h.size());assert(in.gcount()==int64_t(h.size()));
 auto state=[&](const array<A2,7>&v){
  long double M[8][8][8]{};long double sc=1;for(auto q:v)for(auto x:q)sc=max(sc,fabsl(x));
  uint64_t k=0;for(int i=0;i<35;i++){auto z=ps[i];long double x=det2(v[z[0]-1],v[z[1]-1],v[z[2]-1]);
   if(fabsl(x)<1e-17L*sc*sc)return pair<int,uint64_t>{-1,0};M[z[0]][z[1]][z[2]]=x;if(x>0)k|=1ull<<i;}
  for(int i=0;i<15;i++){auto z=flab[i];long double a=M[z[0]][z[1]][6]*M[z[2]][z[3]][7],b=M[z[0]][z[1]][7]*M[z[2]][z[3]][6],x=a-b;
   if(fabsl(x)<1e-16L*(fabsl(a)+fabsl(b)+1))return pair<int,uint64_t>{-1,0};if(x>0)k|=1ull<<(35+i);}
  int g=0;for(int z=0;z<2;z++){int j=z?7:6;long double a=M[1][2][5]*M[3][4][j],b=M[1][2][j]*M[3][4][5],x=a-b;
   if(fabsl(x)<1e-16L*(fabsl(a)+fabsl(b)+1))return pair<int,uint64_t>{-1,0};if(x>0)g|=1<<z;}
  uint32_t u=H.find(k);if(u==UINT32_MAX)return pair<int,uint64_t>{-1,0};int r=h[4*u+g];if(r==255)return pair<int,uint64_t>{-1,0};return pair<int,uint64_t>{r,k|(uint64_t(g)<<50)};
 };

 auto features=[&](const array<A2,7>&v){
  long double M[8][8][8]{};array<long double,52>z{};int k=0;
  for(int a=1;a<=7;a++)for(int b=a+1;b<=7;b++)for(int c=b+1;c<=7;c++)z[k++]=M[a][b][c]=det2(v[a-1],v[b-1],v[c-1]);
  for(auto q:flab)z[k++]=M[q[0]][q[1]][6]*M[q[2]][q[3]][7]-M[q[0]][q[1]][7]*M[q[2]][q[3]][6];
  for(int j=6;j<=7;j++)z[k++]=M[1][2][5]*M[3][4][j]-M[1][2][j]*M[3][4][5];assert(k==52);return z;
 };
 array<A2,7>start={A2{-79,-53},A2{-18,-70},A2{22,36},A2{-8,62},A2{51,-99},A2{86,-24},A2{89,38}};
 auto initstate=state(start);assert(initstate.first==4&&initstate.second==10135984468027ull);
 struct Action {int j,mode,num,den,feature;};struct Choice {int j,mode,feature,newrank;long double left,right;};
 mt19937_64 rng(91929474);const int nums[]={1,3,10,25,50,75,90,97,99};int best=0;
 for(int trial=0;trial<300000;trial++){
  auto v=start;int rank=4,quiet=0;uint64_t key=initstate.second;vector<Action>word;
  for(int it=0;it<120;it++){
   auto z=features(v);vector<Choice>choices;
   for(int j=0;j<6;j++){
    auto last=v;last[j]=v[j+1];auto y=features(last);
    vector<pair<long double,int>>roots;
    for(int k=0;k<52;k++){long double den=z[k]-y[k];if(den==0)continue;long double r=z[k]/den;if(r>1e-14L&&r<1-1e-14L)roots.push_back({r,k});}
    if(roots.empty())continue;sort(roots.begin(),roots.end());long double left=roots[0].first,right=1;int f=roots[0].second;
    if(roots.size()>1)right=roots[1].first;if(right-left<1e-13L)continue;
    uint64_t dst=key^(1ull<<f),old50=dst&((1ull<<50)-1);uint32_t u=H.find(old50);int nr=255;if(u!=UINT32_MAX)nr=h[4ull*u+(dst>>50)];int flip=f==0;
    if(nr!=255&&nr==rank-flip)choices.push_back({j,1,f,nr,left,right});
    // Any move short of the first event preserves the strict sign state.
    if(left>1e-12L)choices.push_back({j,0,-1,rank,0,left});
   }
   if(choices.empty())break;auto c=choices[rng()%choices.size()];int num=nums[rng()%9],den=100;
   long double frac=(long double)num/den,l=c.left+(c.right-c.left)*frac;
   auto vv=v;for(int k=0;k<2;k++)vv[c.j][k]=(1-l)*v[c.j][k]+l*v[c.j+1][k];auto [nr,newkey]=state(vv);
   if(nr!=c.newrank||newkey!=(c.mode?key^(1ull<<c.feature):key))continue;
   v=vv;rank=nr;key=newkey;word.push_back({c.j+1,c.mode,num,den,c.feature});
   if(c.feature==0){
    ofstream out("sample289_event_guided_firstflip.txt");for(auto a:word)out<<a.j<<' '<<a.mode<<' '<<a.num<<' '<<a.den<<' '<<a.feature<<'\n';
    cout<<"FOUND NUMERIC firstflip trial="<<trial<<" moves="<<word.size()<<" key="<<key<<"\n";return 0;
   }
   if((int)word.size()>best){best=word.size();if(best%25==0){cout<<"trial="<<trial<<" moves="<<best<<" no target flip\n";cout.flush();}}
  }
  if(trial&&trial%10000==0){cout<<"trials="<<trial<<" no first flip\n";cout.flush();}
 }
 cout<<"NO NUMERIC first flip after 300000 trials\n";
}
