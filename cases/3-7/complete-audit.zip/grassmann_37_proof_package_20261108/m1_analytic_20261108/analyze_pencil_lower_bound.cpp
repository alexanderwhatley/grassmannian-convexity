// Exact pencil-variation tally on the accepted 50+2 G lift.
// Shares only the original 50-state generator and rank certificate.  It does
// NOT include g_features.hpp or call GFeatures, eligible(), or SCC code.
// G static validity is implemented via five rank-two Pluecker sign relations
// plus explicit cyclic G decompositions; events come from the independently
// symbolically checked event_table.txt and six explicit G derivatives.
#define main old_graph_main_unused
#include "../grassmann_37_continuation/rebuild_full_graph.cpp"
#undef main

struct Test {int move,target,a,b,sign;};
int main(){
 init();auto dirs=direction_types(true);auto masks=sign_masks();
 Hash H(1ull<<25);vector<uint64_t>keys;keys.reserve(16051200);
 for(auto&w:dirs)for(auto&z:add_axes(w)){uint64_t base=word_key(z);for(auto m:masks){uint64_t k=base^m;H.insert(k,keys.size());keys.push_back(k);}}
 uint32_t n=keys.size();assert(n==16051200);
 auto sg=[](uint64_t k,int bit){return k&(1ull<<bit)?1:-1;};
 auto p=[&](uint64_t k,int a,int b,int c){return sg(k,pid[a][b][c]);};
 auto valid=[&](uint64_t k,int g){
  int A[2][3][2]={
   {{p(k,1,2,5)*p(k,3,4,6),p(k,1,2,6)*p(k,3,4,5)},
    {p(k,1,3,4)*p(k,2,5,6),p(k,2,3,4)*p(k,1,5,6)},
    {p(k,1,2,4)*p(k,3,5,6),p(k,1,2,3)*p(k,4,5,6)}},
   {{p(k,1,2,5)*p(k,3,4,7),p(k,1,2,7)*p(k,3,4,5)},
    {p(k,1,3,4)*p(k,2,5,7),p(k,2,3,4)*p(k,1,5,7)},
    {p(k,1,2,4)*p(k,3,5,7),p(k,1,2,3)*p(k,4,5,7)}}};
  for(int i=0;i<2;i++){int desired=(g>>i&1)?1:-1;
   for(int r=0;r<3;r++)if(A[i][r][0]!=A[i][r][1]&&A[i][r][0]!=desired)return false;}
  int q[6]={p(k,1,2,5),p(k,3,4,5),p(k,1,2,6),p(k,3,4,6),p(k,1,2,7),p(k,3,4,7)};
  int B[6][6]{};B[1][2]=1;B[1][3]=q[1];B[2][3]=-q[0];B[1][4]=q[3];B[2][4]=-q[2];
  B[1][5]=q[5];B[2][5]=-q[4];B[3][4]=(g&1)?1:-1;B[3][5]=(g&2)?1:-1;B[4][5]=sg(k,35);
  for(int a=1;a<=2;a++)for(int b=a+1;b<=3;b++)for(int c=b+1;c<=4;c++)for(int d=c+1;d<=5;d++){
   int z=B[a][b]*B[c][d]-B[a][c]*B[b][d]+B[a][d]*B[b][c];if(abs(z)==3)return false;}
  return true;
 };
 vector<uint8_t>opt(uint64_t(n)*4);
 ifstream oi("../grassmann_37_continuation/new_work/augmented_optimal_rank.bin",ios::binary);
 oi.read((char*)opt.data(),opt.size());assert(oi.gcount()==int64_t(opt.size()));char extra;assert(!oi.read(&extra,1));

 vector<array<int,5>> pencils;
 for(int a=1;a<=7;a++)for(int b=a+1;b<=7;b++){
  array<int,5> pencil;int z=0;
  for(int i=1;i<=7;i++)if(i!=a&&i!=b){array<int,3>x={a,b,i};sort(x.begin(),x.end());pencil[z++]=pid[x[0]][x[1]][x[2]];}
  assert(z==5);pencils.push_back(pencil);
 }
 uint64_t cnt[13][8]{}; for(uint32_t u=0;u<n;u++){
  int sign=(keys[u]&(1ull<<pid[1][2][3]))?1:-1, lb=0;
  for(auto pencil:pencils){int v=0,prev=sign;for(int idx:pencil){int x=(keys[u]&(1ull<<idx))?1:-1;v+=x!=prev;prev=x;}v+=prev!=1;lb=max(lb,v);}
  for(int g=0;g<4;g++){int h=opt[4*u+g];if(h==255)continue;assert(h<=12&&lb<=7);cnt[h][lb]++;}
 }
 cout<<"pencils="<<pencils.size()<<"\n";
 for(int h=0;h<=12;h++)for(int lb=0;lb<=7;lb++)if(cnt[h][lb])cout<<"H="<<h<<" pencil_lb="<<lb<<" count="<<cnt[h][lb]<<"\n";
}
