# Exact reversal symmetry of the 52-sign model

This note concerns the finite sign **over-approximation**, not a claim that
each of its accepted sign states is realizable by a real matrix. Its counts
have been checked exhaustively and independently of the original G-feature
implementation. The reversal is an exact involutive anti-automorphism of the
accepted move-labeled graph.

## The involution and its action on features

For \(D=\operatorname{diag}((-1)^1,\ldots,(-1)^7)\), define
\(T(M)=MD\). If \(M'=M U_j(t)\) is a positive elementary move, then
\[
 T(M)=T(M')U_j(t),
\]
since \(D U_j(t)D=U_j(-t)\). Thus alternating column reorientation and
reversal of time turn each positive move into a positive move with the same
label. The target \(p_{123}\) and the normalization minor \(p_{567}\) are
both fixed by \(T\).

The signs of the 35 minors transform by
\(p_{abc}\mapsto(-1)^{a+b+c}p_{abc}\). For the 15 old quadratic features,
\(F_{ab,cd}^{67}\mapsto(-1)^{a+b+c+d+6+7}F_{ab,cd}^{67}\). For the two new
features,
\[
G_{56}\mapsto-G_{56},\qquad G_{57}\mapsto G_{57}.
\]
Equivalently, the old 50-sign key is XORed with the fixed mask
`1000807464609098`, and the two-bit G value is XORed with 1.

`verify_reversal_model.cpp` checks that this map preserves all 16,051,200
old keys and that the independent necessary G filter is preserved on every
one of the 23,246,848 accepted augmented states. It also checks the sign
transformation of all 114 move-labeled derivative formulas. Each derivative
changes by the opposite sign to its own target feature, and none depends on
that target's sign. Therefore a one-feature eligible crossing is sent to an
eligible crossing in the opposite direction with the same move label; the
static filter supplies the reversed endpoint. The two G signs and their
transformation are included in this check.

## Extremal regions

Let \(R(s)\) be the old 50-state rank, let \(R^T(s)=R(Ts)\), and let \(K\)
be the saved tight-reachability set used by the 12-prerank. Define
\(T(K)=\{T(s):s\in K\}\). The independent exact tally is:

| \(R+R^T\) | In \(K\) | In \(T(K)\) | Accepted states |
|---:|:---:|:---:|---:|
| 10 | No | No | 6,496 |
| 12 | No | No | 1,785,738 |
| 14 | No | No | 84,292 |
| 14 | No | Yes | 10,685,161 |
| 14 | Yes | No | 10,685,161 |

No other combination occurs. In particular, \(K\) and \(T(K)\) are
disjoint, and each contains 10,685,161 states. Reversal exchanges the
forward tight region with an equal-sized backward tight region. The total
outside their union is 1,876,526 states. The 84,292 residual states with
\(R+R^T=14\) are a smaller subset of that outside region.

These numbers show that the simple condition \(R+R^T=14\) is necessary for
membership in \(K\), but is far from sufficient: it admits all 10,685,161
states in \(T(K)\) and the 84,292 residual states as false positives. Nor is
membership simply the complement of membership after reversal; the residual
states supply counterexamples. The tally is an exact statement about the
formal graph and does not assert that any particular residual state is
realizable.

The two G signs carry information that cannot be discarded in this formal
model. Of the 16,051,200 old 50-sign keys, exactly 100,379 admit at least
two accepted G-sign choices, with at least one choice in \(K\) and another
outside it. Consequently \(K\) cannot be exactly the preimage of any
predicate depending only on the old 50 signs, even one allowed to use the
old rank \(R\) and any statistic computed from those signs. This statement
uses the over-approximate accepted states; it does not by itself rule out a
simpler characterization on the subset of genuinely realizable matrices.

The exhaustive counts do **not** provide an elementary characterization of
which side of this split a state occupies. In particular, the invariants
\(R\), \(R^T\), the individual G signs, and minimum/maximum row-space
variation, considered in the simple combinations tested so far, do not
replace the stored membership certificate. Nor does \(T(K)\) automatically
replace \(K\) in a forward prerank: reversal exchanges forward closure with
backward closure. The independently checked direct prerank remains the proof
of the 12-bound and the sharper \(8+m\) statement.

## Reproduction

From this directory, with assertions enabled:

```sh
c++ -O3 -std=c++17 -pthread verify_reversal_model.cpp -o verify_reversal_model
./verify_reversal_model
c++ -O3 -std=c++17 -pthread analyze_K_masks.cpp -o analyze_K_masks
./analyze_K_masks
```

`verify_reversal_model.log` and `analyze_K_masks.log` contain the recorded
outputs. Both programs share the original 50-state key generator and the
input bytes `filtered_rank.bin` and `g_reachable_50_nohalf.bin` with the
main certificate, but construct the G filter and event eligibility
independently from the G-search implementation.
