// Try to realize one particular formal 52-sign path. Numerical exploration
// only; a candidate must be replayed with exact rational arithmetic.
#include <algorithm>
#include <array>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <random>
#include <vector>
using namespace std;
using V=array<long double,2>;using Plan=array<V,7>;
struct Edge{uint64_t from,to;int feature,move,rank;};
const array<array<int,4>,15>F={array<int,4>{1,2,3,4},{1,3,2,4},{1,4,2,3},{1,2,3,5},{1,3,2,5},{1,5,2,3},{1,2,4,5},{1,4,2,5},{1,5,2,4},{1,3,4,5},{1,4,3,5},{1,5,3,4},{2,3,4,5},{2,4,3,5},{2,5,3,4}};
long double det(const V&a,const V&b,const V&c){return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]);}
array<long double,52> feat(const Plan&v){
 long double p[8][8][8]{};array<long double,52>z{};int k=0;
 for(int a=1;a<=7;a++)for(int b=a+1;b<=7;b++)for(int c=b+1;c<=7;c++)z[k++]=p[a][b][c]=det(v[a-1],v[b-1],v[c-1]);
 for(auto x:F)z[k++]=p[x[0]][x[1]][6]*p[x[2]][x[3]][7]-p[x[0]][x[1]][7]*p[x[2]][x[3]][6];
 for(int j=6;j<=7;j++)z[k++]=p[1][2][5]*p[3][4][j]-p[1][2][j]*p[3][4][5];assert(k==52);return z;
}
int main(){
 vector<Edge>path;ifstream in("sample289_abstract_firstflip_path.txt");Edge e;while(in>>e.from>>e.to>>e.feature>>e.move>>e.rank)path.push_back(e);assert(path.size()==12);
 Plan start={V{-79,-53},V{-18,-70},V{22,36},V{-8,62},V{51,-99},V{86,-24},V{89,38}};
 mt19937_64 rng(527719);uniform_real_distribution<long double>U(0,1);int best=0;array<long long,13>stop{};
 for(int trial=0;trial<2000000;trial++){
  Plan v=start;vector<array<long long,3>>word;int step=0;
  for(;step<(int)path.size();step++){
   auto z=feat(v);auto end=v;int j=path[step].move-1;end[j]=v[j+1];auto y=feat(end);int f=path[step].feature;
   bool valid=true;for(int k=0;k<52;k++){int expected=(path[step].from>>k)&1;if(z[k]==0||int(z[k]>0)!=expected){valid=false;break;}}
   if(!valid)break;
   auto root=[&](int k){long double den=z[k]-y[k];if(den==0)return 2.L;long double r=z[k]/den;return r>0&&r<1?r:2.L;};
   long double r=root(f);if(!(r<1))break;long double next=1;
   for(int k=0;k<52;k++)if(k!=f){long double a=root(k);if(a<r-1e-16L){valid=false;break;}if(fabsl(a-r)<1e-16L){valid=false;break;}next=min(next,a);}
   if(!valid||next-r<1e-17L)break;
   long double q;switch(rng()%3){case 0:q=U(rng);break;case 1:q=powl(10.L,-1-10*U(rng));break;default:q=1-powl(10.L,-1-10*U(rng));}
   long double l=r+(next-r)*q;for(int a=0;a<2;a++)v[j][a]=(1-l)*v[j][a]+l*v[j+1][a];
   auto zz=feat(v);for(int k=0;k<52;k++){int expected=(path[step].to>>k)&1;if(zz[k]==0||int(zz[k]>0)!=expected){valid=false;break;}}
   if(!valid)break;
  }
  stop[step]++;if(step>best){best=step;cout<<"trial="<<trial<<" reached="<<best<<"/"<<path.size()<<"\n";cout.flush();}
  if(step==(int)path.size()){cout<<"FOUND NUMERIC TEMPLATE (requires exact replay)\n";return 0;}
 }
 cout<<"NO TEMPLATE best="<<best<<" stops=";for(int i=0;i<=12;i++)cout<<i<<":"<<stop[i]<<",";cout<<"\n";
}
