#!/usr/bin/env python3
"""Compute every 52-bit sign key of the rational lower example directly."""
from fractions import Fraction
from itertools import combinations
from math import gcd
from pathlib import Path
import json

z=json.loads((Path(__file__).resolve().parent.parent/'grassmann_37_continuation/new_work/neville_lower12.json').read_text())
v=[list(map(int,x)) for x in z['initial_columns']];scale=[Fraction(1)]*7
P=list(combinations(range(7),3))
F=[(1,2,3,4),(1,3,2,4),(1,4,2,3),(1,2,3,5),(1,3,2,5),(1,5,2,3),(1,2,4,5),(1,4,2,5),(1,5,2,4),(1,3,4,5),(1,4,3,5),(1,5,3,4),(2,3,4,5),(2,4,3,5),(2,5,3,4)]
def det(a,b,c):return a[0]*(b[1]*c[2]-b[2]*c[1])-a[1]*(b[0]*c[2]-b[2]*c[0])+a[2]*(b[0]*c[1]-b[1]*c[0])
def key():
 p={I:det(*(v[i] for i in I)) for I in P};assert all(p.values()) and p[4,5,6]>0
 def D(a,b,c):return p[tuple(sorted((a-1,b-1,c-1)))]
 val=[p[I] for I in P]+[D(a,b,6)*D(c,d,7)-D(a,b,7)*D(c,d,6) for a,b,c,d in F]
 val+=[D(1,2,5)*D(3,4,j)-D(1,2,j)*D(3,4,5) for j in (6,7)]
 assert len(val)==52 and all(val)
 return sum(1<<i for i,x in enumerate(val) if x>0)
old=key();flips=0;out=[(0,old,flips)]
for step,(j,t) in enumerate(z['moves'],1):
 j-=1;assert 0<=j<6; t=Fraction(t);assert t>0
 t=t*scale[j+1]/scale[j];assert t>0;a,b=t.numerator,t.denominator
 w=[b*v[j][i]+a*v[j+1][i] for i in range(3)];d=gcd(gcd(abs(w[0]),abs(w[1])),abs(w[2]));assert d
 v[j]=[x//d for x in w];scale[j]*=Fraction(d,b);k=key();flips+=bool((k^old)&1);old=k;out.append((step,k,flips))
assert flips==12
Path('lower12_vertex_keys.txt').write_text(''.join(f'{step} {k} {flips}\n' for step,k,flips in out))
print('PASS 208 exact fully strict 52-sign keys; 12 target changes')
