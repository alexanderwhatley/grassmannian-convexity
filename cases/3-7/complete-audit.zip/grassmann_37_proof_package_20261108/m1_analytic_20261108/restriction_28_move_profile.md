# Restricting the generator counts of a 28-move witness

Every generic `(3,7)` trajectory with 12 changes of `p123` in
exactly 28 positive elementary moves must have **exactly**
\[
 \boxed{2\ U_1,\quad 11\ (U_2\text{ or }U_4),\quad
        12\ U_3,\quad 2\ U_5,\quad 1\ U_6.}\tag{1}
\]
A real 28-move witness is now known: `../trajectory_search_20261108/witness_28_simplified.json` is independently replayed by `verify_28_witness_direct.py` and `verify_28_witness_simplified.log``, with all 35 minors and 17 auxiliary features strict at every recorded vertex. Combined with the separate audited lower bound 28, it proves that the minimum number of moves is **exactly 28**. The profile proof below is computer assisted: the finite 23,808-state sign-graph certificate is checked directly.

## A first-six-column obstruction

Consider a generic 3-by-7 trajectory starting in the alternating chamber.
If it has at most one `U1` move, at most three `U5` moves and at most one
`U6` move, then it has at most **11** target sign changes, even if it has
arbitrarily many moves at indices 2, 3 and 4.

The finite model uses the signs of the 20 maximal minors of the first six
columns. Both signs of `p456` are allowed. For each of the 30 three-term
Grassmann–Plücker relations on these minors, the three signed terms cannot
all have the same sign. Exactly 23,808 of the `2^20` sign assignments pass
these necessary tests. No claim is made that every accepted assignment is
realizable.

For `j=1,...,5`, a strict single-minor crossing of a positive `Uj` shear
has the directed sign transition
\[
 p_I\longrightarrow-p_I\quad\text{only if }j\in I,\ j+1\notin I,
 \quad\operatorname{sgn}p_I=-\operatorname{sgn}p_{I-j+j+1}.
\]
All accepted destination states are included. There are 115,200 such
move-labeled edges. During one physical shear, every crossing it causes is
traversed consecutively with the same label. The verifier therefore allows
at most one contiguous `U1` event run and at most three contiguous `U5`
runs; any number of `U2`, `U3` and `U4` events are permitted between them.
Runs may end after any event, a relaxation of actual root ordering.

A `U6` shear does not change any of the ten minors on the first five columns.
It is relaxed to an arbitrary jump between accepted 3-by-6 sign states with
those ten signs equal. At most one such jump is allowed, and it cannot be
placed inside a physical `U1` or `U5` move. This includes every real `U6`
move and generally permits many unrealizable jumps. A target edge has
weight 1 exactly when it changes `p123`; all other events and jumps have
weight 0. The initial 20 signs are the alternating signs, after normalizing
`p567>0`. No terminal sign condition is imposed.

The byte array `three_by_six_1u1_3u5_rank.bin` is a potential on the
augmented finite states. Independently implemented
`verify_3x6_one_three_rank.cpp` reconstructs all states and edges from the
oriented Plücker signs, checks that the initial potential is 0, that the potential is
nondecreasing along every allowed transition, and that it rises by at
least 1 across each target edge. It checks 5,128,879 inequalities,
including 3,774,374 relaxed `U6` jumps, on 463,733 reachable certificate
states. All potentials are at most 11. Thus every path in this
**overapproximation**, and hence every covered real path, has at most 11
changes.

For real trajectories, simultaneous intermediate walls can be separated
without changing the finite generator word, positive move parameters, strict
recorded target signs or initial alternating chamber. Each same-generator
root tie is the zero set of a polynomial in the first six columns. The
standard-library script `verify_3x6_event_separation.py` supplies one integer
matrix where all 20 minors and all 75 such resultants are nonzero, proving
none of those polynomials is identically zero. Pulling back by any fixed
prefix word is still a nonzero polynomial, since the full column operation
is invertible. A generic arbitrarily small perturbation therefore avoids all
finitely many bad sets.

An independently implemented check with *stricter* budgets on the actual
`U2`/`U4` and `U3` runs is in
`../grassmann_37_continuation/history_20261108/probe_minimum_29_six.cpp`
and `probe_minimum_29_six_1_3.log`; it also obtains at most 11. The strict
run-budget check and the all-edge potential audit are separate validations.

## Deducing the 28-move profile

The audited `r<=8+m` bound implies that any 12-change start has `m=4` and
hence is alternating. The move lower bounds in
`../grassmann_37_continuation/history_20261108/minimum_moves_27.md` give at
least 12 `U3` moves, 11 moves at `U2` or `U4`, two `U5` moves, one `U1`
and one `U6`. The independently checked five-column automaton in
`probe_two_j5_five_sign_graph.py` strengthens the last two requirements:
a 12-change trajectory cannot have both at most one `U1` move and at most
two `U5` moves. Consequently the sum of the last two counts is at least 4.

If the entire path has only 28 moves, all the other lower bounds must be
attained. The two possibilities are `(U1,U5)=(1,3)` and `(2,2)`. The
first-six-column obstruction above rules out `(1,3)`, leaving (1).

A refined 3-by-6 model with three concurrency-feature signs and the exact
required alternation of target and separator runs has an abstract 12-change
path for `(U1,U5)=(2,2)`; see `probe_3x6_three_g_path28.cpp` and
`abstract_28_three_g_path.txt`. That abstract path is separate from the
independently verified real 28-move witness above.

## Reproduction

From this directory:

```sh
c++ -O3 -std=c++17 probe_3x6_runs_29.cpp -o probe_3x6_runs_29
./probe_3x6_runs_29 1 3
c++ -O3 -std=c++17 verify_3x6_one_three_rank.cpp -o verify_3x6_one_three_rank
./verify_3x6_one_three_rank
python3 verify_3x6_event_separation.py
```

The first command regenerates `three_by_six_1u1_3u5_rank.bin`; its SHA-256 is
`0c36d1c699a96a49e87fe6197fc32a1e4ee8c8ba83384185b09b2949a0c2cd41`.
The corresponding logs are `probe_3x6_runs_13.log`,
`verify_3x6_one_three_rank.log`, and `verify_3x6_event_separation.log`.
The `(3,7)` `8+m` bound and graph coverage are independently checked in
`verify_optimal_rank_bound_independent.cpp/.log` and
`audit_50_and_g_coverage.md`.
