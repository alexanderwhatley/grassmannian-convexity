# Sample 289: an unresolved rank-2 versus rank-4 case

For the seven columns
\[
 (-79,-53,1),\ (-18,-70,1),\ (22,36,1),\ (-8,62,1),\
 (51,-99,1),\ (86,-24,1),\ (89,38,1),
\]
all 35 maximal minors and all 17 additional tracked features are nonzero.
The 52-sign key is `10135984468027`, the target `p123=7146` is positive,
and the functional `omega=z` is positive on every column. Consequently its
minimum row-space variation is `m=0`.

**Current rigorous status: the true future rank is either 2 or 4. Neither
value is established.** In particular, failure of a numerical search or of
a sufficient lower-bound test is not a proof of rank 2.

## Exact lower bound 2

Perform the five positive integer shears
\[
 U_4(14),\quad U_3(2000),\quad U_5(1),\quad U_4(1),\quad U_3(100).
\]
The target values at the six vertices are
\[
 7146,\quad7146,\quad-236854,\quad-236854,\quad-236854,\quad148746.
\]
All 35 maximal minors are nonzero at every vertex, and all are positive at
the last vertex. Thus the two sign changes are a rigorous lower witness.

## Verified upper bound 4

The independent 52-sign graph certificate assigns `H=4` to the key, so
`r<=4` subject to its independently checked trajectory coverage. The same
upper bound also follows without that graph from the published rank-two
cyclic-word theorem. Under the fixed positive functional `omega=z`, the six
initial projected differences are
\[
 (61,-17),\ (40,106),\ (-30,26),\ (59,-161),\ (35,75),\ (3,62).
\]
Their exact cyclic word, starting at label 1, is
\[
 (1,5,2,6,-4,3,-1,-5,-2,-6,4,-3).
\]
The successive positive-label angular increments are `(2,3,5,3,2)`, a
single positive run totaling 15, and the cyclic prerank is
`2 floor(15/6)=4`. The fixed functional remains strictly positive under
all allowed shears, so this prerank never increases and drops at every
target change; see `../analytic_agent/halfspace_theorem.md`.

The target and the invariant last minor are initially positive. By the
terminal dominance lemma in `rank_one_ideal_theorem.md`, any finite path
ending with negative target can be extended to a positive target. Since the
upper bound is finite, the maximum number of changes has even parity. This
excludes 3 and proves `r in {2,4}`.

## Negative probes and their limits

* This actual matrix lies in the residual after the pencil, diagonal
  dominance, and one-shear sign-only lower-bound criteria. The exact
  97,172-sample filter is `find_rank4_remaining_samples.cpp/.log`; the
  matrix is index 289. Failure of those sufficient criteria says nothing
  conclusive about its true rank.
* The exact fixed-functional arrangement optimizer finds minimum 4 for
  its established projected-rank-plus-pole upper bound over 37 cells.
  This does not rule out a different upper-bound method.
* A random rank-guided corner-cutting search of 500,000 trials and a
  separate 300,000-trial event-guided search found no first target flip
  while maintaining formal rank 4. These are floating-point searches,
  not a proof of impossibility. `search_rank4_twoshear_sample.cpp/.log`
  and `search_sample289_event_guided.cpp/.log` retain the procedures.
* In the full 52-sign graph, the shortest **abstract** tight path to a
  first target flip has 12 single-feature edges. Exact enumeration gives
  three possible labeled first-two-edge prefixes; all require feature 48
  as the first or second event. At the original matrix, or immediately
  after an arbitrary single `U1(s)` with `s>=0`, any `U2(t)` hits the
  `p126` wall before the feature-48 wall:
  \[
   p_{126}(t)=4574-(11756+9184s)t,\qquad
   F_{48}(t)=-30775004+13671808t,
  \]
  and `2287/5878 < 7693751/3417952`. Thus these shortest abstract
  prefixes cannot be executed directly from that matrix with only those
  event-generating moves. Additional sign-silent moves can change the
  underlying matrix without changing the source key, and longer abstract
  paths may exist. Therefore this calculation does **not** exclude a real
  4-change continuation.
* All 66 relaxed pairs of the 12 rank-4 positive-functional projection
  words still admit an abstract synchronized four-change route. This
  particular product overapproximation does not sharpen the upper bound;
  the surviving routes are not a realizability claim.

## Reproduction

From this directory:

```sh
python3 verify_sample289_case.py
python3 check_sample289_abstract_path_obstruction.py
```

The first standard-library verifier checks the 52 initial signs, the exact
projected cyclic word, and the five-shear lower witness. Its output is
`verify_sample289_case.log`. The second checks the exact root obstruction;
its output is `check_sample289_abstract_path_obstruction.log`.
`search_sample289_allshort_prefixes.cpp/.log` records the shortest abstract
path and all first-two-edge possibilities. All these artifacts should be
retained for continuation; they do not settle the rank.
