// Try to realize one particular formal 52-sign path. Numerical exploration
// only; a candidate must be replayed with exact rational arithmetic.
#include <algorithm>
#include <array>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <random>
#include <vector>
using namespace std;
using V=array<long double,2>;using Plan=array<V,7>;
struct Edge{uint64_t from,to;int feature,move,rank;};
const array<array<int,4>,15>F={array<int,4>{1,2,3,4},{1,3,2,4},{1,4,2,3},{1,2,3,5},{1,3,2,5},{1,5,2,3},{1,2,4,5},{1,4,2,5},{1,5,2,4},{1,3,4,5},{1,4,3,5},{1,5,3,4},{2,3,4,5},{2,4,3,5},{2,5,3,4}};
long double det(const V&a,const V&b,const V&c){return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]);}
array<long double,52> feat(const Plan&v){
 long double p[8][8][8]{};array<long double,52>z{};int k=0;
 for(int a=1;a<=7;a++)for(int b=a+1;b<=7;b++)for(int c=b+1;c<=7;c++)z[k++]=p[a][b][c]=det(v[a-1],v[b-1],v[c-1]);
 for(auto x:F)z[k++]=p[x[0]][x[1]][6]*p[x[2]][x[3]][7]-p[x[0]][x[1]][7]*p[x[2]][x[3]][6];
 for(int j=6;j<=7;j++)z[k++]=p[1][2][5]*p[3][4][j]-p[1][2][j]*p[3][4][5];assert(k==52);return z;
}

int main(){
 Plan start={V{-79,-53},V{-18,-70},V{22,36},V{-8,62},V{51,-99},V{86,-24},V{89,38}};auto z0=feat(start);uint64_t key=0;for(int k=0;k<52;k++)if(z0[k]>0)key|=1ull<<k;assert(key==10135984468027ull);
 mt19937_64 rng(7852439);uniform_real_distribution<long double>U(0,1);long double best=1e100L;
 for(int trial=0;trial<100000;trial++){
  Plan v=start;vector<pair<int,int>>word;
  for(int it=0;it<80;it++){
   auto z=feat(v);auto end=v;end[1]=v[2];auto y=feat(end);
   long double rf=z[48]/(z[48]-y[48]),rp=z[3]/(z[3]-y[3]);
   if(rf>0&&rf<1&&rp>0&&rp<1){long double ratio=rf/rp;if(ratio<best){best=ratio;if(best<1.1L){cout<<"trial="<<trial<<" silent_steps="<<word.size()<<" ratio="<<(double)ratio<<"\n";cout.flush();}}
    if(ratio<1-1e-12){ofstream out("sample289_silent_reversal.txt");for(auto [j,q]:word)out<<j<<' '<<q<<" 1000000\n";cout<<"FOUND silent root-order reversal\n";return 0;}
   }
   int j=rng()%6;end=v;end[j]=v[j+1];y=feat(end);long double limit=1;
   for(int k=0;k<52;k++){long double d=z[k]-y[k];if(d==0)continue;long double r=z[k]/d;if(r>1e-12L&&r<limit)limit=r;}
   int num=1+int(rng()%999999);long double lambda=limit*num/1000000.L;
   for(int a=0;a<2;a++)end[j][a]=(1-lambda)*v[j][a]+lambda*v[j+1][a];auto zz=feat(end);uint64_t kk=0;bool ok=true;
   for(int k=0;k<52;k++){if(zz[k]==0){ok=false;break;}if(zz[k]>0)kk|=1ull<<k;}if(!ok||kk!=key)continue;
   v=end;word.push_back({j+1,num});
  }
 }
 cout<<"NO SILENT REVERSAL best ratio="<<(double)best<<" (numeric exploration only)\n";
}
