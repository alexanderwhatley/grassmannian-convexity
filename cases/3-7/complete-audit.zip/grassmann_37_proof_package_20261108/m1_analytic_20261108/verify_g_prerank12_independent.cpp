// Independent direct 12-prerank verifier for the 50+2 G lift.
// Shares only the original 50-state generator and rank certificate.  It does
// NOT include g_features.hpp or call GFeatures, eligible(), or SCC code.
// G static validity is implemented via five rank-two Pluecker sign relations
// plus explicit cyclic G decompositions; events come from the independently
// symbolically checked event_table.txt and six explicit G derivatives.
#define main old_graph_main_unused
#include "../grassmann_37_continuation/rebuild_full_graph.cpp"
#undef main

struct Test {int move,target,a,b,sign;};
int main(){
 init();auto dirs=direction_types(true);auto masks=sign_masks();
 Hash H(1ull<<25);vector<uint64_t>keys;keys.reserve(16051200);
 for(auto&w:dirs)for(auto&z:add_axes(w)){uint64_t base=word_key(z);for(auto m:masks){uint64_t k=base^m;H.insert(k,keys.size());keys.push_back(k);}}
 uint32_t n=keys.size();assert(n==16051200);
 vector<uint8_t>rank(n);ifstream in("../grassmann_37_continuation/filtered_rank.bin",ios::binary);
 in.read((char*)rank.data(),n);assert(in.gcount()==n);
 vector<uint8_t>seen((uint64_t(n)*4+7)/8);
 ifstream in2("../grassmann_37_continuation/history_20261108/g_reachable_50_nohalf.bin",ios::binary);
 in2.read((char*)seen.data(),seen.size());assert(in2.gcount()==int64_t(seen.size()));char extra;assert(!in2.read(&extra,1));
 auto reached=[&](uint32_t i,int g){uint64_t c=4ull*i+g;return bool(seen[c/8]&(1<<(c%8)));};
 auto sg=[](uint64_t k,int bit){return k&(1ull<<bit)?1:-1;};
 auto p=[&](uint64_t k,int a,int b,int c){return sg(k,pid[a][b][c]);};
 auto valid=[&](uint64_t k,int g){
  int A[2][3][2]={
   {{p(k,1,2,5)*p(k,3,4,6),p(k,1,2,6)*p(k,3,4,5)},
    {p(k,1,3,4)*p(k,2,5,6),p(k,2,3,4)*p(k,1,5,6)},
    {p(k,1,2,4)*p(k,3,5,6),p(k,1,2,3)*p(k,4,5,6)}},
   {{p(k,1,2,5)*p(k,3,4,7),p(k,1,2,7)*p(k,3,4,5)},
    {p(k,1,3,4)*p(k,2,5,7),p(k,2,3,4)*p(k,1,5,7)},
    {p(k,1,2,4)*p(k,3,5,7),p(k,1,2,3)*p(k,4,5,7)}}};
  for(int i=0;i<2;i++){int desired=(g>>i&1)?1:-1;
   for(int r=0;r<3;r++)if(A[i][r][0]!=A[i][r][1]&&A[i][r][0]!=desired)return false;}
  int q[6]={p(k,1,2,5),p(k,3,4,5),p(k,1,2,6),p(k,3,4,6),p(k,1,2,7),p(k,3,4,7)};
  int B[6][6]{};B[1][2]=1;B[1][3]=q[1];B[2][3]=-q[0];B[1][4]=q[3];B[2][4]=-q[2];
  B[1][5]=q[5];B[2][5]=-q[4];B[3][4]=(g&1)?1:-1;B[3][5]=(g&2)?1:-1;B[4][5]=sg(k,35);
  for(int a=1;a<=2;a++)for(int b=a+1;b<=3;b++)for(int c=b+1;c<=4;c++)for(int d=c+1;d<=5;d++){
   int z=B[a][b]*B[c][d]-B[a][c]*B[b][d]+B[a][d]*B[b][c];if(abs(z)==3)return false;}
  return true;
 };
 vector<Test>E;ifstream ef("../grassmann_37_continuation/event_table.txt");Test t;
 while(ef>>t.move>>t.target>>t.a>>t.b>>t.sign)if(t.target<50)E.push_back(t);
 assert(E.size()==108);
 E.push_back({2,50,pid[1][3][4],pid[3][5][6],1});
 E.push_back({4,50,pid[1][2][5],pid[3][5][6],1});
 E.push_back({6,50,51,-1,1});
 E.push_back({2,51,pid[1][3][4],pid[3][5][7],1});
 E.push_back({4,51,pid[1][2][5],pid[3][5][7],1});
 E.push_back({5,51,35,-1,1});assert(E.size()==114);
 // The complete candidate set is frozen before edge checks; every valid
 // source and target is checked using this separately built GP filter.
 vector<uint8_t>allowed(n);
 vector<thread>threads;
 for(int th=0;th<8;th++)threads.emplace_back([&,th](){
  uint32_t lo=uint64_t(n)*th/8,hi=uint64_t(n)*(th+1)/8;
  for(uint32_t i=lo;i<hi;i++)for(int g=0;g<4;g++)
   if(valid(keys[i],g))allowed[i]|=1u<<g;
 });
 for(auto&th:threads)th.join();threads.clear();
 struct Stats {uint64_t valid=0,inK=0,seeds=0,edges=0,base=0,gEdges=0;
  uint64_t target=0,exits=0,entries=0,rejected=0,missing=0;int maxP=-1,minP=100;};
 array<Stats,8>stats{};
 for(int th=0;th<8;th++)threads.emplace_back([&,th](){
  Stats S;uint32_t lo=uint64_t(n)*th/8,hi=uint64_t(n)*(th+1)/8;
  for(uint32_t i=lo;i<hi;i++){
   assert(rank[i]<=14);uint64_t k=keys[i];
   for(int g=0;g<4;g++){
    bool present=reached(i,g),ok=allowed[i]&(1u<<g);
    if(!ok){assert(!present);continue;}
    int P=int(rank[i])-2*int(present);
    if(P<0||P>12){cerr<<"rank range failure state "<<i<<" g "<<g<<" old "<<int(rank[i])<<" K "<<present<<" P "<<P<<"\n";abort();}
    S.valid++;S.inK+=present;S.maxP=max(S.maxP,P);S.minP=min(S.minP,P);
    if(rank[i]==14){assert(present);S.seeds++;}
    uint64_t whole=k|(uint64_t(g)<<50),candidates=0;
    // Candidate membership is existential across move labels. Multiple move
    // labels with the same target produce the same successor and weight.
    for(auto e:E){int derivative=e.sign*sg(whole,e.a)*(e.b>=0?sg(whole,e.b):1);
     if(sg(whole,e.target)!=derivative)candidates|=1ull<<e.target;}
    while(candidates){
     int target=__builtin_ctzll(candidates);candidates&=candidates-1;
     uint32_t j=i;int h=g,wt=(target==pid[1][2][3]);
     if(target<50){j=H.find(k^(1ull<<target));if(j==UINT32_MAX){S.missing++;continue;}}
     else h^=1<<(target-50);
     if(!(allowed[j]&(1u<<h))){S.rejected++;continue;}
     bool next=reached(j,h);int Q=int(rank[j])-2*int(next);
     if(P<Q+wt){cerr<<"rank edge failure src="<<i<<"/"<<g<<" dst="<<j<<"/"<<h<<" bit="<<target<<" P="<<P<<" Q="<<Q<<"\n";abort();}
     S.edges++;S.target+=wt;S.base+=(target<50);S.gEdges+=(target>=50);
     S.exits+=present&&!next;S.entries+=!present&&next;
    }
   }
  }
  stats[th]=S;
 });
 for(auto&th:threads)th.join();Stats T;
 for(auto S:stats){T.valid+=S.valid;T.inK+=S.inK;T.seeds+=S.seeds;T.edges+=S.edges;T.base+=S.base;T.gEdges+=S.gEdges;
  T.target+=S.target;T.exits+=S.exits;T.entries+=S.entries;T.rejected+=S.rejected;T.missing+=S.missing;
  T.maxP=max(T.maxP,S.maxP);T.minP=min(T.minP,S.minP);}
 cout<<"PASS full direct 12-prerank: valid="<<T.valid<<" inK="<<T.inK<<" rank14="<<T.seeds<<" minP="<<T.minP<<" maxP="<<T.maxP<<"\n";
 cout<<"PASS all distinct eligible edges="<<T.edges<<" base="<<T.base<<" G="<<T.gEdges<<" target="<<T.target<<" K exits="<<T.exits<<" entries="<<T.entries<<"\n";
 cout<<"Excluded missing 50 keys="<<T.missing<<" statically impossible G destinations="<<T.rejected<<"\n";
}
