# A real H=4 state beyond the pencil and sign-dominance tests

Consider the generic matrix whose columns are
\[
 (-89,3,1),\ (-78,-49,1),\ (-12,-16,1),\ (-79,74,1),\
 (-89,-80,1),\ (8,-41,1),\ (5,-2,1).
\]
It is in the common-halfspace class `m=0`, using the strictly positive
functional `omega(x,y,z)=z`. Its 52-feature sign key is
`331055874502971` in the saved convention, and the graph certificate gives
`H=4`. Every maximal minor and every tracked feature is nonzero.

The maximum of the 21 pencil-variation lower bounds is only 2. Moreover,
all 5,040 power-of-two weight orderings fail the sufficient `r>=4`
sign-dominance criterion in `rank4_dominance_criterion.md`. Thus this matrix
lies in the actual, not merely formal, residual class of those tests.

Nevertheless its **true rank is exactly 4**. Apply the following 13 original
positive shears `(j,t)`, meaning `v_j <- v_j+t v_{j+1}`:
\[
\begin{split}
 &(1,7),\ (4,1),\ (3,5/2),\ (4,18),\ (3,3/10),\ (2,1/6),\\
 &(3,3/5),\ (1,8/3),\ (5,1),\ (4,10),\ (3,12/5),\
 (2,1/40),\ (3,18).
\end{split}
\]
Direct rational replay checks all 35 minors are nonzero at all 14 vertices;
the target changes sign at moves 5, 7, 11 and 13, and all final minors are
positive. This supplies `r>=4` without relying on the graph.

An independent `r<=4` follows from the known rank-two cyclic-word theorem,
not from the 52-sign computation. Since `omega(v_i)=1` initially, the six
projected differences are
\[
 (11,-52),\ (66,33),\ (-67,90),\ (-10,-154),\ (97,39),\ (-3,39).
\]
Their exact oriented cyclic word is
\[
 (1,-3,5,2,-4,6,-1,3,-5,-2,4,-6).
\]
The successive increments for positive labels 1 through 6 are
`(3,4,3,4,3)`, a single positive run of length 17 in a 12-letter word. Its
rank-two cyclic rank is `2 floor(17/6)=4`. The fixed functional stays
positive throughout every trajectory, so the projected rank never increases
and drops at each target change. The mathematical reduction is detailed in
`../analytic_agent/halfspace_theorem.md`. The graph rank independently
agrees but is unnecessary for this example's upper bound.

Run from this directory:

```sh
python3 verify_rank4_residual_independent.py
```

The standard-library verifier reconstructs all 52 initial signs, checks all
21 pencil bounds and all 5,040 weight orderings, sorts all projected rays by
exact integer cross products, evaluates the cyclic-rank formula, and replays
the 13 shears using independent rational 3-vector operations. Its output is
`verify_rank4_residual_independent.log`. The equivalent corner-cutting
parameters and a separate rational replay are in
`rank4_residual_tiny_lambdas.txt` and
`verify_rank4_residual_four_flips.py`.
