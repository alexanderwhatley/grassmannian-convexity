// Independent direct 12-prerank verifier for the 50+2 G lift.
// Shares only the original 50-state generator and rank certificate.  It does
// NOT include g_features.hpp or call GFeatures, eligible(), or SCC code.
// G static validity is implemented via five rank-two Pluecker sign relations
// plus explicit cyclic G decompositions; events come from the independently
// symbolically checked event_table.txt and six explicit G derivatives.
#define main old_graph_main_unused
#include "../grassmann_37_continuation/rebuild_full_graph.cpp"
#undef main

struct Test {int move,target,a,b,sign;};
int main(){
 init();auto dirs=direction_types(true);auto masks=sign_masks();
 Hash H(1ull<<25);vector<uint64_t>keys;keys.reserve(16051200);
 for(auto&w:dirs)for(auto&z:add_axes(w)){uint64_t base=word_key(z);for(auto m:masks){uint64_t k=base^m;H.insert(k,keys.size());keys.push_back(k);}}
 uint32_t n=keys.size();assert(n==16051200);
 auto sg=[](uint64_t k,int bit){return k&(1ull<<bit)?1:-1;};
 auto p=[&](uint64_t k,int a,int b,int c){return sg(k,pid[a][b][c]);};
 auto valid=[&](uint64_t k,int g){
  int A[2][3][2]={
   {{p(k,1,2,5)*p(k,3,4,6),p(k,1,2,6)*p(k,3,4,5)},
    {p(k,1,3,4)*p(k,2,5,6),p(k,2,3,4)*p(k,1,5,6)},
    {p(k,1,2,4)*p(k,3,5,6),p(k,1,2,3)*p(k,4,5,6)}},
   {{p(k,1,2,5)*p(k,3,4,7),p(k,1,2,7)*p(k,3,4,5)},
    {p(k,1,3,4)*p(k,2,5,7),p(k,2,3,4)*p(k,1,5,7)},
    {p(k,1,2,4)*p(k,3,5,7),p(k,1,2,3)*p(k,4,5,7)}}};
  for(int i=0;i<2;i++){int desired=(g>>i&1)?1:-1;
   for(int r=0;r<3;r++)if(A[i][r][0]!=A[i][r][1]&&A[i][r][0]!=desired)return false;}
  int q[6]={p(k,1,2,5),p(k,3,4,5),p(k,1,2,6),p(k,3,4,6),p(k,1,2,7),p(k,3,4,7)};
  int B[6][6]{};B[1][2]=1;B[1][3]=q[1];B[2][3]=-q[0];B[1][4]=q[3];B[2][4]=-q[2];
  B[1][5]=q[5];B[2][5]=-q[4];B[3][4]=(g&1)?1:-1;B[3][5]=(g&2)?1:-1;B[4][5]=sg(k,35);
  for(int a=1;a<=2;a++)for(int b=a+1;b<=3;b++)for(int c=b+1;c<=4;c++)for(int d=c+1;d<=5;d++){
   int z=B[a][b]*B[c][d]-B[a][c]*B[b][d]+B[a][d]*B[b][c];if(abs(z)==3)return false;}
  return true;
 };
 vector<uint8_t>opt(uint64_t(n)*4);
 ifstream oi("../grassmann_37_continuation/new_work/augmented_optimal_rank.bin",ios::binary);
 oi.read((char*)opt.data(),opt.size());assert(oi.gcount()==int64_t(opt.size()));char extra;assert(!oi.read(&extra,1));
 vector<pair<int,int>>covers;for(int z=0;z<35;z++){auto I=ps[z];for(int q=0;q<3;q++){
  int j=I[q];if(j==7||find(I.begin(),I.end(),j+1)!=I.end())continue;auto J=I;J[q]++;sort(J.begin(),J.end());covers.emplace_back(z,pid[J[0]][J[1]][J[2]]);
 }}
 uint64_t counts[13][2]{}, parity_counts[13][2]{};for(uint32_t u=0;u<n;u++){
  bool inversion=false;for(auto [a,b]:covers)if((keys[u]&(1ull<<a))&&!(keys[u]&(1ull<<b))){inversion=true;break;}
  for(int g=0;g<4;g++){int h=opt[4*u+g];if(h==255)continue;assert(h<=12);counts[h][inversion]++;parity_counts[h][(keys[u] & (1ull<<pid[1][2][3])) != 0]++;}
 }
 assert(covers.size()==60);
 assert(counts[0][0]==36 && counts[0][1]==51072);
 assert(counts[1][0]==7770 && counts[1][1]==0 && parity_counts[1][0]==7770 && parity_counts[1][1]==0);
 assert(counts[2][0]==0 && counts[2][1]==83845 && parity_counts[2][0]==0 && parity_counts[2][1]==83845);
 assert(counts[3][0]==0 && counts[3][1]==631987 && parity_counts[3][0]==631987 && parity_counts[3][1]==0);
 cout<<"PASS exact sign-ideal and target-sign claims for all H<=3 states\n";
 for(int h=0;h<=12;h++) cout<<"H="<<h<<" target_negative="<<parity_counts[h][0]<<" target_positive="<<parity_counts[h][1]<<"\n";
 cout<<"covers="<<covers.size()<<"\n";for(int h=0;h<=12;h++)if(counts[h][0]||counts[h][1])cout<<"H="<<h<<" no_inversion="<<counts[h][0]<<" inversion="<<counts[h][1]<<"\n";
}
