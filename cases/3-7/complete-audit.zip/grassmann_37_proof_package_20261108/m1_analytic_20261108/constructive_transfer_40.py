#!/usr/bin/env python3
"""Construct an explicit rational epsilon bound for the 40-shear transfer.

This exact demonstration uses the generic alternating start E*T(1)*D.
For a general rational alternating input, substitute that matrix for M in
`main`: all other steps (exact Jacobian, generic integer perturbation,
polynomial coefficient bounds) are algorithmic and have a termination proof.
No numerical root solving is used.
"""
from fractions import Fraction as Q
from itertools import combinations, count
from pathlib import Path
import json,sys
if hasattr(sys,"set_int_max_str_digits"):sys.set_int_max_str_digits(0)
import sympy as s

word=[4,3,2,1,5,4,3,2,6,5,4,3];P=list(combinations(range(1,8),3));idx={I:i for i,I in enumerate(P)}
def U(j,t):
 a=s.eye(7);a[j,j-1]=t;return a
def prod(a):
 T=s.eye(7)
 for j,t in zip(word,a):T=T*U(j,t)
 return T
def toq(x):x=s.Rational(x);return Q(int(x.p),int(x.q))
def det(a,b,c):return a[0]*(b[1]*c[2]-b[2]*c[1])-a[1]*(b[0]*c[2]-b[2]*c[0])+a[2]*(b[0]*c[1]-b[1]*c[0])
def pmatrix(M):return [det(*(M[j-1] for j in I)) for I in P]
def act_p(p,j,t):
 p=p[:]
 for I in P:
  if j in I and j+1 not in I:
   J=tuple(sorted((set(I)-{j})|{j+1}));p[idx[I]]+=t*p[idx[J]]
 return p
def trim(a):
 while len(a)>1 and a[-1]==0:a.pop()
 return a
def add(a,b):
 out=[Q(0)]*max(len(a),len(b))
 for i,x in enumerate(a):out[i]+=x
 for i,x in enumerate(b):out[i]+=x
 return trim(out)
def mul(a,b):
 out=[Q(0)]*(len(a)+len(b)-1)
 for i,x in enumerate(a):
  for j,y in enumerate(b):out[i+j]+=x*y
 return trim(out)
def act_poly(p,j,t):
 p=p[:]
 for I in P:
  if j in I and j+1 not in I:
   J=tuple(sorted((set(I)-{j})|{j+1}));p[idx[I]]=add(p[idx[I]],mul(t,p[idx[J]]))
 return p
def lead(p):
 for i,x in enumerate(p):
  if x:return i,x
 return None

def main():
 # Optional JSON input is a 7-column array or object with initial_columns.
 if len(sys.argv)>1:
  obj=json.loads(Path(sys.argv[1]).read_text());columns=obj['initial_columns'] if isinstance(obj,dict) else obj
  assert len(columns)==7 and all(len(col)==3 for col in columns)
  M=s.Matrix(3,7,lambda i,j:s.Rational(str(columns[j][i])))
  if M[:,4:7].det()<0:M[0,:]=-M[0,:]
 else:
  X0=prod([s.Integer(1)]*12)[4:7,:];M=X0*s.diag(*[(-1)**i for i in range(1,8)])
 raw=[[toq(M[i,j]) for i in range(3)] for j in range(7)];initial=pmatrix(raw);assert all(initial) and initial[-1]>0
 D=s.diag(*[(-1)**i for i in range(1,8)]);X=M*D;X=X[:,4:7].inv()*X
 assert all(X[:,[i-1 for i in I]].det()>0 for I in P), 'input is not in the alternating chamber' 
 def p(a,b,c):return X[:,[a-1,b-1,c-1]].det()
 a0=s.Matrix([p(1,6,7)*p(4,5,6)/p(1,5,6),p(1,5,6)*p(3,4,5)/(p(1,4,5)*p(4,5,6)),
  p(1,4,5)*p(2,3,4)/(p(1,3,4)*p(3,4,5)),p(1,3,4)/p(2,3,4),
  p(1,2,7)*p(1,5,6)/(p(1,2,6)*p(1,6,7)),p(1,2,6)*p(1,4,5)/(p(1,2,5)*p(1,5,6)),
  p(1,2,5)*p(1,3,4)/(p(1,2,4)*p(1,4,5)),p(1,2,4)/p(1,3,4),p(1,2,6)/p(1,2,7),
  p(1,2,5)/p(1,2,6),p(1,2,4)/p(1,2,5),p(1,2,3)/p(1,2,4)])
 assert all(v>0 for v in a0)
 Z=json.loads((Path(__file__).resolve().parent.parent/'trajectory_search_20261108/witness_28_simplified.json').read_text())
 W=s.Matrix(3,7,lambda i,j:(-1)**(j+1)*s.Rational(str(Z['initial_columns'][j][i])));AW=W[:,4:7].inv()*W[:,:4]
 E=s.zeros(3,7);E[:,4:7]=s.eye(3);B=s.zeros(3,7);B[:,:4]=AW
 blocks=[U(j,a0[k]) for k,j in enumerate(word)];prefix=[s.eye(7)]
 for b in blocks:prefix.append(prefix[-1]*b)
 suffix=[None]*13;suffix[12]=s.eye(7)
 for i in range(11,-1,-1):suffix[i]=blocks[i]*suffix[i+1]
 T0=prefix[-1];C=E*T0;Ctail=C[:,4:7];Cinv=Ctail.inv();F0=Cinv*C[:,:4];assert F0==X[:,:4]
 cols=[]
 for i,j in enumerate(word):
  e=s.zeros(7,7);e[j,j-1]=1;dC=E*prefix[i]*e*suffix[i+1]
  dF=Cinv*(dC[:,:4]-dC[:,4:7]*F0);cols.append(s.Matrix([dF[r,c] for r in range(3) for c in range(4)]))
 dC=B*T0;dF=Cinv*(dC[:,:4]-dC[:,4:7]*F0);b=s.Matrix([dF[r,c] for r in range(3) for c in range(4)])
 J=s.Matrix.hstack(*cols);assert J.det()!=0;a1=-J.inv()*b
 a0=[toq(v) for v in a0];a1=[toq(v) for v in a1];print('PASS exact chart Jacobian and first-order inverse',flush=True)
 # Find a generic integer vector c. The test at epsilon=1 certifies each
 # preparation-vertex minor is a nonzero polynomial in epsilon.
 chosen=None
 for z in count():
  cc=[Q(0)]*12 if z==0 else [Q(z**(1<<i)) for i in range(12)]
  pp=initial[:];good=True
  for i in range(11,-1,-1):
   pp=act_p(pp,word[i],a0[i]+a1[i]+cc[i]);good &= all(pp)
  if good:chosen=cc;print('PASS exact generic perturbation vector indexed by z=',z,flush=True);break
 assert chosen is not None

 # Test dyadic epsilons by exact rational replay. The first-order inverse and
 # strict witness signs guarantee success for sufficiently small epsilon.
 reference=pmatrix([[Q(x) for x in col] for col in Z['initial_columns']]);expected=[reference[0]>0]
 for j,t in Z['moves']:
  reference=act_p(reference,j,Q(t));assert all(reference);expected.append(reference[0]>0)
 assert len(Z['moves'])==28 and sum(a!=b for a,b in zip(expected,expected[1:]))==12
 for exp in (1<<k for k in range(16)):
  eps=Q(1,1<<exp);params=[a0[i]+eps*a1[i]+eps*eps*chosen[i] for i in range(12)]
  if min(params)<=0:continue
  pp=initial[:];last=pp[0]>0;flips=[];strict=True;tail=[]
  moves=[(word[i],params[i]) for i in range(11,-1,-1)]+[(j,Q(t)*(eps if j==4 else 1)) for j,t in Z['moves']]
  for step,(j,t) in enumerate(moves,1):
   pp=act_p(pp,j,t)
   if not all(pp):strict=False;break
   now=pp[0]>0
   if now!=last:flips.append(step)
   last=now
   if step==12:tail=[now]
   elif step>12:tail.append(now)
  if strict and (tail==expected or tail==[not x for x in expected]):
   assert len(moves)==40 and len([f for f in flips if f>12])==12
   print('PASS 40 exact rational moves from the chart-ones alternating start; epsilon=2^(-%d), flips='%exp,flips)
   Path('constructive_transfer_40.json').write_text(json.dumps({'initial_columns':[[str(x) for x in v] for v in raw],
    'moves':[[j,str(t)] for j,t in moves],'epsilon_power':exp,'flips':flips},indent=2)+'\n')
   return
  print('tested epsilon power',exp,'strict',strict,'tail signs matched',tail==expected,flush=True)
 raise RuntimeError('dyadic search exceeded bound; increase exponent range')
if __name__=='__main__':main()
