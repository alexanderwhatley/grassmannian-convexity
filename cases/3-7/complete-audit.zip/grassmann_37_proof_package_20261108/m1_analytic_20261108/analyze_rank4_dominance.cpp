// Exact sign-only dominant-minor criterion for 4 flips.
// Shares only the original 50-state generator and rank certificate.  It does
// NOT include g_features.hpp or call GFeatures, eligible(), or SCC code.
// G static validity is implemented via five rank-two Pluecker sign relations
// plus explicit cyclic G decompositions; events come from the independently
// symbolically checked event_table.txt and six explicit G derivatives.
#define main old_graph_main_unused
#include "../grassmann_37_continuation/rebuild_full_graph.cpp"
#undef main

struct Test {int move,target,a,b,sign;};
int main(){
 init();auto dirs=direction_types(true);auto masks=sign_masks();
 Hash H(1ull<<25);vector<uint64_t>keys;keys.reserve(16051200);
 for(auto&w:dirs)for(auto&z:add_axes(w)){uint64_t base=word_key(z);for(auto m:masks){uint64_t k=base^m;H.insert(k,keys.size());keys.push_back(k);}}
 uint32_t n=keys.size();assert(n==16051200);
 auto sg=[](uint64_t k,int bit){return k&(1ull<<bit)?1:-1;};
 auto p=[&](uint64_t k,int a,int b,int c){return sg(k,pid[a][b][c]);};
 auto valid=[&](uint64_t k,int g){
  int A[2][3][2]={
   {{p(k,1,2,5)*p(k,3,4,6),p(k,1,2,6)*p(k,3,4,5)},
    {p(k,1,3,4)*p(k,2,5,6),p(k,2,3,4)*p(k,1,5,6)},
    {p(k,1,2,4)*p(k,3,5,6),p(k,1,2,3)*p(k,4,5,6)}},
   {{p(k,1,2,5)*p(k,3,4,7),p(k,1,2,7)*p(k,3,4,5)},
    {p(k,1,3,4)*p(k,2,5,7),p(k,2,3,4)*p(k,1,5,7)},
    {p(k,1,2,4)*p(k,3,5,7),p(k,1,2,3)*p(k,4,5,7)}}};
  for(int i=0;i<2;i++){int desired=(g>>i&1)?1:-1;
   for(int r=0;r<3;r++)if(A[i][r][0]!=A[i][r][1]&&A[i][r][0]!=desired)return false;}
  int q[6]={p(k,1,2,5),p(k,3,4,5),p(k,1,2,6),p(k,3,4,6),p(k,1,2,7),p(k,3,4,7)};
  int B[6][6]{};B[1][2]=1;B[1][3]=q[1];B[2][3]=-q[0];B[1][4]=q[3];B[2][4]=-q[2];
  B[1][5]=q[5];B[2][5]=-q[4];B[3][4]=(g&1)?1:-1;B[3][5]=(g&2)?1:-1;B[4][5]=sg(k,35);
  for(int a=1;a<=2;a++)for(int b=a+1;b<=3;b++)for(int c=b+1;c<=4;c++)for(int d=c+1;d<=5;d++){
   int z=B[a][b]*B[c][d]-B[a][c]*B[b][d]+B[a][d]*B[b][c];if(abs(z)==3)return false;}
  return true;
 };
 vector<uint8_t>opt(uint64_t(n)*4);
 ifstream oi("../grassmann_37_continuation/new_work/augmented_optimal_rank.bin",ios::binary);
 oi.read((char*)opt.data(),opt.size());assert(oi.gcount()==int64_t(opt.size()));char extra;assert(!oi.read(&extra,1));

 vector<pair<int,int>>covers;
 for(int a=0;a<35;a++){auto I=ps[a];for(int q=0;q<3;q++){
  int j=I[q];if(j==7||find(I.begin(),I.end(),j+1)!=I.end())continue;auto J=I;J[q]++;
  covers.emplace_back(a,pid[J[0]][J[1]][J[2]]);
 }}
 vector<array<int,5>> pencils;
 for(int a=1;a<=7;a++)for(int b=a+1;b<=7;b++){
  array<int,5> pencil;int z=0;for(int i=1;i<=7;i++)if(i!=a&&i!=b){array<int,3>x={a,b,i};sort(x.begin(),x.end());pencil[z++]=pid[x[0]][x[1]][x[2]];}pencils.push_back(pencil);
 }
 uint64_t candidates[35][35]{};
 array<int,7> permutation={1,2,3,4,5,6,7};int permutations=0;
 do {
  int weight[8]{};for(int p=0;p<7;p++)weight[permutation[p]]=1<<p;
  int score[35]{};for(int a=0;a<35;a++)for(int i:ps[a])score[a]+=weight[i];
  int dominant[35];for(int t=0;t<35;t++){
   int best=-1;for(int a=0;a<35;a++)if(ps[a][0]>=ps[t][0]&&ps[a][1]>=ps[t][1]&&ps[a][2]>=ps[t][2]&&(best<0||score[a]>score[best]))best=a;
   assert(best>=0);dominant[t]=best;
  }
  int top=dominant[pid[1][2][3]];
  for(auto [a,b]:covers){int x=dominant[a],y=dominant[b];if(x!=y&&x!=top)candidates[x][y]|=1ull<<top;}
  permutations++;
 }while(next_permutation(permutation.begin(),permutation.end()));
 vector<tuple<int,int,uint64_t>> tests;for(int a=0;a<35;a++)for(int b=0;b<35;b++)if(candidates[a][b])tests.emplace_back(a,b,candidates[a][b]);
 uint64_t pencil4=0,pencil_over=0,promoted=0,remaining=0;uint64_t firstword=0;int firsta=-1,firstb=-1,firsttop=-1,firstg=-1;const uint64_t minor_mask=(1ull<<35)-1;
 for(uint32_t u=0;u<n;u++){
  int mult=0,gfirst=-1;for(int g=0;g<4;g++)if(opt[4*u+g]==4){mult++;gfirst=g;}if(!mult)continue;
  uint64_t pos=keys[u]&minor_mask,neg=(~pos)&minor_mask;
  int sign=(pos&(1ull<<pid[1][2][3]))?1:-1;assert(sign==1);int lb=0;
  for(auto pencil:pencils){int v=0,prev=sign;for(int idx:pencil){int x=(pos&(1ull<<idx))?1:-1;v+=x!=prev;prev=x;}v+=prev!=1;lb=max(lb,v);}
  if(lb==4){pencil4+=mult;continue;}if(lb>4){pencil_over+=mult;continue;}assert(lb==2);
  bool yes=false;
  for(auto [a,b,topset]:tests)if((pos>>a&1)&&(neg>>b&1)&&(neg&topset)){
    if(!promoted){firstword=keys[u];firsta=a;firstb=b;firsttop=__builtin_ctzll(neg&topset);firstg=gfirst;}
    yes=true;break;
  }
  if(yes)promoted+=mult;else remaining+=mult;
 }
 cout<<"permutations="<<permutations<<" distinct_pairs="<<tests.size()<<"\n";
 cout<<"H4 pencil_lb4="<<pencil4<<" pencil_lb6="<<pencil_over<<"\n";
 cout<<"H4 pencil_lb2 dominance_promoted="<<promoted<<" residual="<<remaining<<"\n";
 cout<<"first promoted key="<<firstword<<" Gbits="<<firstg<<" pos_minor_index="<<firsta<<" neg_minor_index="<<firstb<<" neg_target_dominant_index="<<firsttop<<"\n";
}
