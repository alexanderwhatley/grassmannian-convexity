#!/usr/bin/env python3
"""Find a 1-shear transition to an elementary four-flip certificate.

Every candidate is selected strictly between exact rational minor roots. A
positive target is accepted if the dense-weight sign criterion proves rank 4;
a negative target is accepted if the negative minors fail to be an order
ideal, since the preceding target crossing plus rank-one theorem gives 4.
"""
from fractions import Fraction as Q
from itertools import combinations,permutations

V=[[-79,-53,1],[-18,-70,1],[22,36,1],[-8,62,1],[51,-99,1],[86,-24,1],[89,38,1]]
I=list(combinations(range(7),3));idx={a:i for i,a in enumerate(I)}
def det(a,b,c):return a[0]*(b[1]*c[2]-b[2]*c[1])-b[0]*(a[1]*c[2]-a[2]*c[1])+c[0]*(a[1]*b[2]-a[2]*b[1])
def minors(v):return [det(*(v[j] for j in T)) for T in I]
p=minors(V);assert all(p) and p[0]>0 and p[-1]>0
active=[];covers=[]
for j in range(6):
 act=[]
 for a,T in enumerate(I):
  if j in T and j+1 not in T:
   B=tuple(sorted(set(T)-{j}|{j+1}));act.append((a,idx[B]));covers.append((a,idx[B]))
 active.append(act)
assert len(covers)==60
feasible=[[u for u,K in enumerate(I) if all(a<=b for a,b in zip(T,K))] for T in I]
N={}
for order in permutations(range(7)):
 w=[0]*7
 for h,j in enumerate(order):w[j]=1<<h
 scores=[sum(w[j] for j in T) for T in I]
 dom=[max(choices,key=scores.__getitem__) for choices in feasible];top=dom[0]
 for a,b in covers:
  x,y=dom[a],dom[b]
  if x!=y and x!=top:N[x,y]=N.get((x,y),0)|(1<<top)

def reason(p):
 if p[0]<0:
  for a,b in covers:
   if p[a]>0>p[b]:return ('negative_target_inversion',I[a],I[b])
 else:
  pos=sum((x>0)<<i for i,x in enumerate(p));neg=((1<<35)-1)^pos
  for (a,b),tops in N.items():
   if (pos>>a&1) and (neg>>b&1) and (tops&neg):return ('positive_target_dominance',I[a],I[b],I[(tops&neg).bit_length()-1])
 return None
assert reason(p) is None
for j,act in enumerate(active):
 roots=sorted(set(-Q(p[a],p[b]) for a,b in act if p[a]*p[b]<0))
 boundaries=[Q(0)]+roots
 samples=[(x+y)/2 for x,y in zip(boundaries,boundaries[1:])]+[(boundaries[-1]+1)]
 for t in samples:
  q=p[:]
  for a,b in act:q[a]+=t*p[b]
  assert all(q)
  how=reason(q)
  if how:
   print('PASS one positive shear',j+1,'t=',t,'reason=',how,'sampled intervals=',len(samples))
   raise SystemExit
print('No one-shear transition to either criterion was found.')
