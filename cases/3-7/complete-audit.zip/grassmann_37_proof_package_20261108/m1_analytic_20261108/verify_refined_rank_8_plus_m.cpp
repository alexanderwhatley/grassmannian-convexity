// Independent direct 12-prerank verifier for the 50+2 G lift.
// Shares only the original 50-state generator and rank certificate.  It does
// NOT include g_features.hpp or call GFeatures, eligible(), or SCC code.
// G static validity is implemented via five rank-two Pluecker sign relations
// plus explicit cyclic G decompositions; events come from the independently
// symbolically checked event_table.txt and six explicit G derivatives.
#define main old_graph_main_unused
#include "../grassmann_37_continuation/rebuild_full_graph.cpp"
#undef main

struct Test {int move,target,a,b,sign;};
int main(){
 init();auto dirs=direction_types(true);auto masks=sign_masks();
 Hash H(1ull<<25);vector<uint64_t>keys;keys.reserve(16051200);
 for(auto&w:dirs)for(auto&z:add_axes(w)){uint64_t base=word_key(z);for(auto m:masks){uint64_t k=base^m;H.insert(k,keys.size());keys.push_back(k);}}
 uint32_t n=keys.size();assert(n==16051200);
 vector<uint8_t>rank(n);ifstream in("../grassmann_37_continuation/filtered_rank.bin",ios::binary);
 in.read((char*)rank.data(),n);assert(in.gcount()==n);
 vector<uint8_t>seen((uint64_t(n)*4+7)/8);
 ifstream in2("../grassmann_37_continuation/history_20261108/g_reachable_50_nohalf.bin",ios::binary);
 in2.read((char*)seen.data(),seen.size());assert(in2.gcount()==int64_t(seen.size()));char extra;assert(!in2.read(&extra,1));
 auto reached=[&](uint32_t i,int g){uint64_t c=4ull*i+g;return bool(seen[c/8]&(1<<(c%8)));};
 auto sg=[](uint64_t k,int bit){return k&(1ull<<bit)?1:-1;};
 auto p=[&](uint64_t k,int a,int b,int c){return sg(k,pid[a][b][c]);};
 auto valid=[&](uint64_t k,int g){
  int A[2][3][2]={
   {{p(k,1,2,5)*p(k,3,4,6),p(k,1,2,6)*p(k,3,4,5)},
    {p(k,1,3,4)*p(k,2,5,6),p(k,2,3,4)*p(k,1,5,6)},
    {p(k,1,2,4)*p(k,3,5,6),p(k,1,2,3)*p(k,4,5,6)}},
   {{p(k,1,2,5)*p(k,3,4,7),p(k,1,2,7)*p(k,3,4,5)},
    {p(k,1,3,4)*p(k,2,5,7),p(k,2,3,4)*p(k,1,5,7)},
    {p(k,1,2,4)*p(k,3,5,7),p(k,1,2,3)*p(k,4,5,7)}}};
  for(int i=0;i<2;i++){int desired=(g>>i&1)?1:-1;
   for(int r=0;r<3;r++)if(A[i][r][0]!=A[i][r][1]&&A[i][r][0]!=desired)return false;}
  int q[6]={p(k,1,2,5),p(k,3,4,5),p(k,1,2,6),p(k,3,4,6),p(k,1,2,7),p(k,3,4,7)};
  int B[6][6]{};B[1][2]=1;B[1][3]=q[1];B[2][3]=-q[0];B[1][4]=q[3];B[2][4]=-q[2];
  B[1][5]=q[5];B[2][5]=-q[4];B[3][4]=(g&1)?1:-1;B[3][5]=(g&2)?1:-1;B[4][5]=sg(k,35);
  for(int a=1;a<=2;a++)for(int b=a+1;b<=3;b++)for(int c=b+1;c<=4;c++)for(int d=c+1;d<=5;d++){
   int z=B[a][b]*B[c][d]-B[a][c]*B[b][d]+B[a][d]*B[b][c];if(abs(z)==3)return false;}
  return true;
 };
 vector<Test>E;ifstream ef("../grassmann_37_continuation/event_table.txt");Test t;
 while(ef>>t.move>>t.target>>t.a>>t.b>>t.sign)if(t.target<50)E.push_back(t);
 assert(E.size()==108);
 E.push_back({2,50,pid[1][3][4],pid[3][5][6],1});
 E.push_back({4,50,pid[1][2][5],pid[3][5][6],1});
 E.push_back({6,50,51,-1,1});
 E.push_back({2,51,pid[1][3][4],pid[3][5][7],1});
 E.push_back({4,51,pid[1][2][5],pid[3][5][7],1});
 E.push_back({5,51,35,-1,1});assert(E.size()==114);
 // Compute the actual minimum variation by Gordan's alternative, rather
 // than the Pluecker-variation formula used by the independent S0/S1/S2
 // closure checker. A generic rank-three sign pattern is feasible iff no
 // signed 4-circuit is all-positive (or all-negative). Fix the seventh sign
 // positive using the harmless simultaneous reversal of all seven signs.
 struct Circuit{int idx[4],labs[4];uint64_t bad[16];};vector<Circuit>Cs;
 for(int a=1;a<=7;a++)for(int b=a+1;b<=7;b++)for(int c=b+1;c<=7;c++)for(int d=c+1;d<=7;d++){
  Circuit q{};q.idx[0]=pid[b][c][d];q.idx[1]=pid[a][c][d];q.idx[2]=pid[a][b][d];q.idx[3]=pid[a][b][c];
  q.labs[0]=a;q.labs[1]=b;q.labs[2]=c;q.labs[3]=d;
  for(int mask=0;mask<16;mask++)for(int pat=0;pat<64;pat++){
   int x=mask;for(int h=0;h<4;h++)if(q.labs[h]<=6&&(pat>>(q.labs[h]-1)&1))x^=1<<h;
   if(x==0||x==15)q.bad[mask]|=1ull<<pat;
  }Cs.push_back(q);
 }
 uint64_t atmost[7]{};
 for(int pat=0;pat<64;pat++){int v=__builtin_popcount(unsigned((pat^(pat>>1))&63));
  for(int z=v;z<=6;z++)atmost[z]|=1ull<<pat;}
 vector<uint8_t>allowed(n),mcache(n);vector<thread>threads;
 for(int th=0;th<8;th++)threads.emplace_back([&,th](){
  uint32_t lo=uint64_t(n)*th/8,hi=uint64_t(n)*(th+1)/8;
  for(uint32_t i=lo;i<hi;i++){
   uint64_t k=keys[i],feas=~0ull;for(const auto&c:Cs){int q=10;
    for(int h=0;h<4;h++)if(k&(1ull<<c.idx[h]))q^=1<<h;feas&=~c.bad[q];}
   assert(feas);int m=0;while(m<=6&&!(feas&atmost[m]))m++;assert(m<=4);mcache[i]=m;
   for(int g=0;g<4;g++)if(valid(k,g))allowed[i]|=1u<<g;
  }
 });
 for(auto&th:threads)th.join();threads.clear();
 auto oldP=[&](uint32_t i,int g){return int(rank[i])-2*int(reached(i,g));};
 auto newQ=[&](uint32_t i,int g){int P=oldP(i,g),m=mcache[i];bool plus=keys[i]&1;
  bool S0=(m==0&&!plus&&P==9);
  bool S1=(m<=1&&plus&&P==10);
  bool S2=(m<=2&&((plus&&P==12)||(!plus&&P==11)));
  return P-2*int(S0||S1||S2);
 };
 struct Stats {uint64_t states=0,edges=0,target=0,base=0,ge=0,invalid=0,missing=0,changed=0;
  uint64_t mc[5]{};int maxQ[5]={-1,-1,-1,-1,-1};};
 array<Stats,8>stats{};
 for(int th=0;th<8;th++)threads.emplace_back([&,th](){
  Stats S;uint32_t lo=uint64_t(n)*th/8,hi=uint64_t(n)*(th+1)/8;
  for(uint32_t i=lo;i<hi;i++){
   uint64_t k=keys[i];for(int g=0;g<4;g++){
    bool stored=reached(i,g),ok=allowed[i]&(1u<<g);if(!ok){assert(!stored);continue;}
    int m=mcache[i],Q=newQ(i,g),P=oldP(i,g);
    if(Q<0||Q>8+m){cerr<<"rank bound failure i="<<i<<" g="<<g<<" m="<<m<<" Q="<<Q<<" P="<<P<<"\n";abort();}
    S.states++;S.mc[m]++;S.maxQ[m]=max(S.maxQ[m],Q);S.changed+=(P!=Q);
    uint64_t whole=k|(uint64_t(g)<<50),cand=0;
    for(auto e:E){int der=e.sign*sg(whole,e.a)*(e.b>=0?sg(whole,e.b):1);if(sg(whole,e.target)!=der)cand|=1ull<<e.target;}
    while(cand){int t=__builtin_ctzll(cand);cand&=cand-1;uint32_t j=i;int h=g;
     if(t<50){j=H.find(k^(1ull<<t));if(j==UINT32_MAX){S.missing++;continue;}}
     else h^=1<<(t-50);
     if(!(allowed[j]&(1u<<h))){S.invalid++;continue;}
     int z=newQ(j,h),wt=t==pid[1][2][3];
     if(Q<z+wt){cerr<<"edge failure "<<i<<"/"<<g<<" -> "<<j<<"/"<<h<<" bit="<<t<<" Q="<<Q<<" next="<<z<<"\n";abort();}
     S.edges++;S.target+=wt;S.base+=(t<50);S.ge+=(t>=50);
    }
   }
  }
  stats[th]=S;
 });
 for(auto&th:threads)th.join();Stats T;
 for(auto S:stats){T.states+=S.states;T.edges+=S.edges;T.target+=S.target;T.base+=S.base;T.ge+=S.ge;T.invalid+=S.invalid;T.missing+=S.missing;T.changed+=S.changed;
  for(int m=0;m<=4;m++){T.mc[m]+=S.mc[m];T.maxQ[m]=max(T.maxQ[m],S.maxQ[m]);}}
 assert(T.states==23246848&&T.edges==144788896&&T.changed==3641);
 cout<<"PASS direct prerank Q on "<<T.states<<" augmented states; changed="<<T.changed<<"\n";
 for(int m=0;m<=4;m++)cout<<"m="<<m<<" states="<<T.mc[m]<<" maxQ="<<T.maxQ[m]<<" bound="<<8+m<<"\n";
 cout<<"PASS distinct eligible edges="<<T.edges<<" base="<<T.base<<" G="<<T.ge<<" target="<<T.target<<"\n";
 cout<<"excluded missing50="<<T.missing<<" invalidG="<<T.invalid<<"\n";
}
