#!/usr/bin/env python3
"""Independent integer-column, signed-circuit audit of the 207-move witness.

This intentionally recomputes 35 determinants from columns at every vertex,
not the exterior-power update used by the first checker. Positive individual
column scalings keep integers manageable and preserve all signs. Exact scale
factors adjust the subsequent prescribed move coefficients. Gordan's
four-circuit test computes the minimum variation independently.
"""
from fractions import Fraction
from itertools import combinations
from math import gcd
from pathlib import Path
import json

z=json.loads((Path(__file__).resolve().parent.parent/
    'grassmann_37_continuation/new_work/neville_lower12.json').read_text())
v=[list(map(int,a)) for a in z['initial_columns']]
scale=[Fraction(1)]*7
triples=list(combinations(range(7),3));quads=list(combinations(range(7),4))
def det(a,b,c):
 return a[0]*(b[1]*c[2]-b[2]*c[1])-a[1]*(b[0]*c[2]-b[2]*c[0])+a[2]*(b[0]*c[1]-b[1]*c[0])
def evaluate():
 minors={I:det(*(v[j] for j in I)) for I in triples}
 assert all(minors.values()),'a Pluecker minor vanished at a sampled vertex'
 p={I:1 if a>0 else -1 for I,a in minors.items()}
 feasible=[]
 for bits in range(64):
  # bits mark minus signs for positions 0..5; the seventh sign is plus.
  good=True
  for a,b,c,d in quads:
   co=[p[b,c,d],-p[a,c,d],p[a,b,d],-p[a,b,c]]
   s=[co[k]*(-1 if (bits>>i)&1 else 1) for k,i in enumerate((a,b,c,d))]
   if s[0]==s[1]==s[2]==s[3]:good=False;break
  if good:feasible.append((bits^bits>>1).bit_count())
 assert feasible
 return p[0,1,2],min(feasible)
oldsign,oldm=evaluate();initial_m=oldm;flips=[];drops=[];largest_bits=0
for step,(j,t) in enumerate(z['moves'],1):
 j=int(j)-1;t=Fraction(t);assert 0<=j<6 and t>0
 ratio=t*scale[j+1]/scale[j];a,b=ratio.numerator,ratio.denominator
 w=[b*v[j][i]+a*v[j+1][i] for i in range(3)]
 common=gcd(gcd(abs(w[0]),abs(w[1])),abs(w[2]));assert common>0
 v[j]=[x//common for x in w];scale[j]*=Fraction(common,b)
 largest_bits=max(largest_bits,max(abs(x).bit_length() for x in v[j]))
 newsign,newm=evaluate()
 assert newm<=oldm,(step,oldm,newm)
 if newsign!=oldsign:flips.append((step,oldm,newm))
 if newm!=oldm:drops.append((step,oldm,newm,len(flips)))
 oldsign,oldm=newsign,newm
assert len(z['moves'])==207 and len(flips)==12 and initial_m==4
assert drops==[(15,4,3,1),(36,3,2,2),(57,2,1,3),(89,1,0,4)]
assert [x[0] for x in flips]==[15,36,57,78,92,111,132,153,174,195,204,207]
print('PASS 207 positive rational moves; all 35 minors nonzero at all 208 vertices')
print('PASS 12 target changes; initial minimum variation 4; max integer-column bit length',largest_bits)
print('flips (move,m before,m after)',flips)
print('minimum-variation drops (move,before,after,total flips)',drops)
