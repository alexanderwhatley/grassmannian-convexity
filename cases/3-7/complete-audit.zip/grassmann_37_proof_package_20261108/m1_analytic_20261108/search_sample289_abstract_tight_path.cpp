// Find an abstract H-tight path from sample 289 to its first target flip.
// An edge model path is not a real positive trajectory.
#define main gc37_old_main
#include "../grassmann_37_continuation/rebuild_full_graph.cpp"
#undef main
#include "../grassmann_37_continuation/history_20261108/g_features.hpp"
int main(){
 init();GFeatures G;auto dirs=direction_types(true);auto masks=sign_masks();Hash lookup(1ull<<25);vector<uint64_t>keys;keys.reserve(16051200);
 for(auto&w:dirs)for(auto&z:add_axes(w)){uint64_t base=word_key(z);for(auto m:masks){lookup.insert(base^m,keys.size());keys.push_back(base^m);}}
 const uint32_t n=keys.size();assert(n==16051200);vector<uint8_t>rank(uint64_t(n)*4);ifstream in("../grassmann_37_continuation/new_work/augmented_optimal_rank.bin",ios::binary);in.read((char*)rank.data(),rank.size());assert(in.gcount()==int64_t(rank.size()));
 uint64_t sample=10135984468027ull;int g=sample>>50;uint32_t u=lookup.find(sample&((1ull<<50)-1));assert(u!=UINT32_MAX&&rank[4ull*u+g]==4);uint32_t start=4*u+g;
 vector<uint32_t>parent(uint64_t(n)*4,UINT32_MAX),queue;vector<uint8_t>feature(uint64_t(n)*4,255),move(uint64_t(n)*4);queue.push_back(start);parent[start]=start;uint32_t finish=UINT32_MAX;
 auto enqueue=[&](uint32_t cur,uint32_t next,int f,int j){
  if(parent[next]!=UINT32_MAX)return;parent[next]=cur;feature[next]=f;move[next]=j;queue.push_back(next);
  if(f==0)finish=next;
 };
 for(size_t h=0;h<queue.size()&&finish==UINT32_MAX;h++){
  uint32_t curr=queue[h],b=curr/4;int gg=curr%4,rv=rank[curr];uint64_t key=keys[b],full=key|(uint64_t(gg)<<50);
  for(auto&e:events)if(eligible(key,e)){
   uint32_t v=lookup.find(key^(1ull<<e.target));if(v==UINT32_MAX)continue;uint32_t next=4*v+gg;int r2=rank[next];if(r2==255||rv!=r2+(e.target==0))continue;
   enqueue(curr,next,e.target,e.move);if(finish!=UINT32_MAX)break;
  }
  if(finish!=UINT32_MAX)break;
  for(auto&e:G.new_events)if(eligible(full,e)){
   int gg2=gg^(1<<(e.target-50));uint32_t next=4*b+gg2;int r2=rank[next];if(r2==255||rv!=r2)continue;enqueue(curr,next,e.target,e.move);
  }
  if(h>0&&h%1000000==0){cerr<<"processed="<<h<<" queue="<<queue.size()<<"\n";cerr.flush();}
 }
 assert(finish!=UINT32_MAX);vector<uint32_t>path;for(uint32_t x=finish;x!=start;x=parent[x])path.push_back(x);reverse(path.begin(),path.end());
 ofstream out("sample289_abstract_firstflip_path.txt");uint32_t prev=start;int targets=0;
 for(auto x:path){uint64_t from=keys[prev/4]|(uint64_t(prev%4)<<50),to=keys[x/4]|(uint64_t(x%4)<<50);int f=feature[x],j=move[x];assert((from^to)==1ull<<f);out<<from<<' '<<to<<' '<<f<<' '<<j<<' '<<int(rank[x])<<'\n';targets+=f==0;prev=x;}
 assert(targets==1&&rank[finish]==3);cout<<"ABSTRACT path first flip: states visited="<<queue.size()<<" edges="<<path.size()<<" destination key="<<(keys[finish/4]|(uint64_t(finish%4)<<50))<<"\n";
}
