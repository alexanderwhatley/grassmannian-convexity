#include <unordered_set>
// Exact sign-only dominant-minor criterion for 4 flips.
// Shares only the original 50-state generator and rank certificate.  It does
// NOT include g_features.hpp or call GFeatures, eligible(), or SCC code.
// G static validity is implemented via five rank-two Pluecker sign relations
// plus explicit cyclic G decompositions; events come from the independently
// symbolically checked event_table.txt and six explicit G derivatives.
#define main old_graph_main_unused
#include "../grassmann_37_continuation/rebuild_full_graph.cpp"
#undef main

struct Test {int move,target,a,b,sign;};
int main(){
 init();auto dirs=direction_types(true);auto masks=sign_masks();
 Hash H(1ull<<25);vector<uint64_t>keys;keys.reserve(16051200);
 for(auto&w:dirs)for(auto&z:add_axes(w)){uint64_t base=word_key(z);for(auto m:masks){uint64_t k=base^m;H.insert(k,keys.size());keys.push_back(k);}}
 uint32_t n=keys.size();assert(n==16051200);
 auto sg=[](uint64_t k,int bit){return k&(1ull<<bit)?1:-1;};
 auto p=[&](uint64_t k,int a,int b,int c){return sg(k,pid[a][b][c]);};
 auto valid=[&](uint64_t k,int g){
  int A[2][3][2]={
   {{p(k,1,2,5)*p(k,3,4,6),p(k,1,2,6)*p(k,3,4,5)},
    {p(k,1,3,4)*p(k,2,5,6),p(k,2,3,4)*p(k,1,5,6)},
    {p(k,1,2,4)*p(k,3,5,6),p(k,1,2,3)*p(k,4,5,6)}},
   {{p(k,1,2,5)*p(k,3,4,7),p(k,1,2,7)*p(k,3,4,5)},
    {p(k,1,3,4)*p(k,2,5,7),p(k,2,3,4)*p(k,1,5,7)},
    {p(k,1,2,4)*p(k,3,5,7),p(k,1,2,3)*p(k,4,5,7)}}};
  for(int i=0;i<2;i++){int desired=(g>>i&1)?1:-1;
   for(int r=0;r<3;r++)if(A[i][r][0]!=A[i][r][1]&&A[i][r][0]!=desired)return false;}
  int q[6]={p(k,1,2,5),p(k,3,4,5),p(k,1,2,6),p(k,3,4,6),p(k,1,2,7),p(k,3,4,7)};
  int B[6][6]{};B[1][2]=1;B[1][3]=q[1];B[2][3]=-q[0];B[1][4]=q[3];B[2][4]=-q[2];
  B[1][5]=q[5];B[2][5]=-q[4];B[3][4]=(g&1)?1:-1;B[3][5]=(g&2)?1:-1;B[4][5]=sg(k,35);
  for(int a=1;a<=2;a++)for(int b=a+1;b<=3;b++)for(int c=b+1;c<=4;c++)for(int d=c+1;d<=5;d++){
   int z=B[a][b]*B[c][d]-B[a][c]*B[b][d]+B[a][d]*B[b][c];if(abs(z)==3)return false;}
  return true;
 };
 vector<uint8_t>opt(uint64_t(n)*4);
 ifstream oi("../grassmann_37_continuation/new_work/augmented_optimal_rank.bin",ios::binary);
 oi.read((char*)opt.data(),opt.size());assert(oi.gcount()==int64_t(opt.size()));char extra;assert(!oi.read(&extra,1));

 vector<pair<int,int>>covers;
 for(int a=0;a<35;a++){auto I=ps[a];for(int q=0;q<3;q++){
  int j=I[q];if(j==7||find(I.begin(),I.end(),j+1)!=I.end())continue;auto J=I;J[q]++;
  covers.emplace_back(a,pid[J[0]][J[1]][J[2]]);
 }}
 vector<array<int,5>> pencils;
 for(int a=1;a<=7;a++)for(int b=a+1;b<=7;b++){
  array<int,5> pencil;int z=0;for(int i=1;i<=7;i++)if(i!=a&&i!=b){array<int,3>x={a,b,i};sort(x.begin(),x.end());pencil[z++]=pid[x[0]][x[1]][x[2]];}pencils.push_back(pencil);
 }
 uint64_t candidates[35][35]{};
 vector<string> generators;unordered_set<string> distinct;
 array<int,7> permutation={1,2,3,4,5,6,7};int permutations=0;
 do {
  int weight[8]{};for(int p=0;p<7;p++)weight[permutation[p]]=1<<p;
  int score[35]{};for(int a=0;a<35;a++)for(int i:ps[a])score[a]+=weight[i];
  int dominant[35];for(int t=0;t<35;t++){
   int best=-1;for(int a=0;a<35;a++)if(ps[a][0]>=ps[t][0]&&ps[a][1]>=ps[t][1]&&ps[a][2]>=ps[t][2]&&(best<0||score[a]>score[best]))best=a;
   assert(best>=0);dominant[t]=best;
  }
  string map(35,0);for(int t=0;t<35;t++)map[t]=char(dominant[t]);if(distinct.insert(map).second)generators.push_back(map);
  int top=dominant[pid[1][2][3]];
  for(auto [a,b]:covers){int x=dominant[a],y=dominant[b];if(x!=y&&x!=top)candidates[x][y]|=1ull<<top;}
  permutations++;
 }while(next_permutation(permutation.begin(),permutation.end()));

 for(int j=1;j<=6;j++){
  string map(35,0);for(int t=0;t<35;t++){
   auto T=ps[t];auto it=find(T.begin(),T.end(),j);int result=t;
   if(it!=T.end()&&find(T.begin(),T.end(),j+1)==T.end()){
    *it=j+1;sort(T.begin(),T.end());result=pid[T[0]][T[1]][T[2]];
   }map[t]=char(result);
  }if(distinct.insert(map).second)generators.push_back(map);
 }
 vector<uint8_t>visited(35*35*35);vector<int>queue;
 auto enqueue=[&](int t,int a,int b){
  if(t==a||a==b)return;
  int id=(t*35+a)*35+b;if(!visited[id]){visited[id]=1;queue.push_back(id);}
 };
 int target=pid[1][2][3];for(auto [a,b]:covers)enqueue(target,a,b);
 for(size_t qi=0;qi<queue.size();qi++){
  int id=queue[qi],t=id/(35*35),a=(id/35)%35,b=id%35;
  candidates[a][b]|=1ull<<t;
  for(auto &map:generators)enqueue((unsigned char)map[t],(unsigned char)map[a],(unsigned char)map[b]);
 }
 cout<<"generators="<<generators.size()<<" reachable_triples="<<queue.size()<<"\n";
 vector<tuple<int,int,uint64_t>> tests;for(int a=0;a<35;a++)for(int b=0;b<35;b++)if(candidates[a][b])tests.emplace_back(a,b,candidates[a][b]);

 vector<array<int,3>>triples;for(int a=0;a<35;a++)for(int b=0;b<35;b++)for(int t=0;t<35;t++)if(candidates[a][b]>>t&1)triples.push_back({t,a,b});
 int slope[6][35];for(int j=0;j<6;j++)for(int a=0;a<35;a++){
  auto T=ps[a];auto it=find(T.begin(),T.end(),j+1);slope[j][a]=-1;
  if(it!=T.end()&&find(T.begin(),T.end(),j+2)==T.end()){
   *it=j+2;sort(T.begin(),T.end());slope[j][a]=pid[T[0]][T[1]][T[2]];
  }
 }
 struct Factor{int u=-1,v=-1,sgn=0;};Factor factors[6][35][35];
 auto vd=[&](int k){auto x=ps[k];return (x[1]-x[0])*(x[2]-x[0])*(x[2]-x[1]);};
 for(int j=0;j<6;j++)for(int a=0;a<35;a++)if(slope[j][a]>=0)for(int b=0;b<35;b++)if(a!=b&&slope[j][b]>=0){
  vector<int>common,da,db;for(int x:ps[a]){if(find(ps[b].begin(),ps[b].end(),x)!=ps[b].end())common.push_back(x);else da.push_back(x);}
  for(int x:ps[b])if(find(ps[a].begin(),ps[a].end(),x)==ps[a].end())db.push_back(x);
  if(common.size()!=2)continue;assert(da.size()==1&&db.size()==1);
  int c=common[0]==j+1?common[1]:common[0];assert(c!=j+1);
  array<int,3>u={c,j+1,j+2},v={c,da[0],db[0]};sort(u.begin(),u.end());sort(v.begin(),v.end());
  int ui=pid[u[0]][u[1]][u[2]],vi=pid[v[0]][v[1]][v[2]];
  int f=vd(a)*vd(slope[j][b])-vd(b)*vd(slope[j][a]);assert(abs(f)==vd(ui)*vd(vi));
  factors[j][a][b]={ui,vi,f>0?1:-1};
 }
 auto one_shear=[&](uint64_t pos,int &wj, int &wt,int &wa,int &wb)->bool{
  auto sign=[&](int a){return (pos>>a&1)?1:-1;};
  auto feasible=[&](int j,uint64_t wantplus,uint64_t wantminus)->bool{
   if(wantplus&wantminus)return false;
   int lower[4],upper[4],nl=0,nu=0;
   auto add=[&](int a,int desired)->bool{
    int cur=sign(a),b=slope[j][a];
    if(b<0)return cur==desired;
    int der=sign(b);
    if(cur==desired){if(der!=desired)upper[nu++]=a;}
    else {if(der!=desired)return false;lower[nl++]=a;}
    return true;
   };
   while(wantplus){int a=__builtin_ctzll(wantplus);wantplus&=wantplus-1;if(!add(a,1))return false;}
   while(wantminus){int a=__builtin_ctzll(wantminus);wantminus&=wantminus-1;if(!add(a,-1))return false;}
   for(int x=0;x<nl;x++)for(int y=0;y<nu;y++){
    int a=lower[x],b=upper[y];if(a==b)return false;
    int sa=sign(a),sb=sign(b),da=sign(slope[j][a]),db=sign(slope[j][b]);
    int term1=sa*db,term2=sb*da,fsign;
    if(term1!=term2)fsign=term1;
    else {auto f=factors[j][a][b];if(f.u<0)return false;fsign=f.sgn*sign(f.u)*sign(f.v);}
    if(fsign*da*db<=0)return false;
   }return true;
  };
  for(int j=0;j<6;j++){
   for(auto z:triples){int t=z[0],a=z[1],b=z[2];
    if(feasible(j,(1ull<<0)|(1ull<<a),(1ull<<t)|(1ull<<b))){wj=j+1;wt=t;wa=a;wb=b;return true;}
   }
   if(j==2)for(auto [a,b]:covers)if(feasible(j,1ull<<a,(1ull<<0)|(1ull<<b))){wj=j+1;wt=0;wa=a;wb=b;return true;}
  }return false;
 };
 uint64_t oneshear=0;int firstj=-1,firstt=-1,firsta2=-1,firstb2=-1;uint64_t firstkey2=0;
 cout<<"composed_positive_target_triples="<<triples.size()<<"\n";

 ifstream inp("../grassmann_37_continuation/new_work/graph_rank_gap_keys.txt");assert(inp);
 uint64_t key;int projected;uint64_t index=0,residual=0;
 while(inp>>key>>projected){
  uint64_t base=key&((1ull<<50)-1);int g=key>>50;uint32_t u=H.find(base);assert(u!=UINT32_MAX);if(opt[4*u+g]!=4){index++;continue;}
  uint64_t pos=base&((1ull<<35)-1),neg=(~pos)&((1ull<<35)-1);int lb=0;assert(pos&1);
  for(auto pencil:pencils){int v=0,prev=1;for(int q:pencil){int x=(pos>>q&1)?1:-1;v+=x!=prev;prev=x;}v+=prev!=1;lb=max(lb,v);}if(lb!=2){index++;continue;}
  bool yes=false;for(auto [a,b,topset]:tests)if((pos>>a&1)&&(neg>>b&1)&&(neg&topset)){yes=true;break;}if(yes){index++;continue;}
  int j,t,a,b;if(one_shear(pos,j,t,a,b)){index++;continue;}
  if(residual<50)cout<<"RESIDUAL index="<<index<<" key="<<key<<" projected="<<projected<<"\n";
  residual++;index++;
 }
 cout<<"samples="<<index<<" residual="<<residual<<"\n";
}
