#!/usr/bin/env python3
"""Verify two forbidden first-move chambers for strict optimal moment paths.

The neighbor 3x6 profile certificate separately excludes the (U1,U5)=(1,3)
allocation; the more permissive case is nevertheless checked where useful.
"""
from collections import deque
from contextlib import redirect_stdout
from pathlib import Path
import io, runpy
p = Path(__file__).resolve().parent.parent/'trajectory_search_20261108'/'probe_exact_28_move_patterns.py'
with redirect_stdout(io.StringIO()):
    N = runpy.run_path(str(p))
start, at, closure = N['start'], N['at'], N['closures']
groups, group, states = N['groups'], N['group'], set(N['states'])
def setbit(s, I, value):
    mask = 1 << at[I]
    return (s | mask) if value else (s & ~mask)
def search(p135, p235, max1, max5):
    state = setbit(setbit(setbit(start,(1,2,3),False),(1,3,5),p135),(2,3,5),p235)
    assert state in states
    root = (state,1,True,0,0)
    seen = {root}
    todo = deque([root])
    while todo:
        s, k, need, a, b = todo.popleft()
        assert k < 12, 'formal 12-crossing continuation survived'
        nxt = []
        if not need:
            nxt.extend((t,k+1,True,a,b) for t in closure[s,3] if ((s^t)>>at[1,2,3])&1)
        if need:
            for j in (2,4):
                nxt.extend((t,k,False,a,b) for t in closure[s,j] if ((s^t)>>at[1,2,4])&1)
        if a < max1:
            nxt.extend((t,k,need,a+1,b) for t in closure[s,1])
        if b < max5:
            nxt.extend((t,k,need,a,b+1) for t in groups[group(s)])
        for q in nxt:
            if q not in seen:
                seen.add(q)
                todo.append(q)
    return len(seen)
assert search(False,False,2,2) == 5261
assert search(True,False,2,2) == 4335
assert search(True,False,1,3) == 4970
print('PASS first U3 time in (1,4/3) excluded for optimal (2 U1,2 U5) profile: 5261 states')
print('PASS first U3 time above 4/3 excluded for both possible coarse profiles: 4335 and 4970 states')
print('Together with the independent 3x6 profile exclusion and endpoint minors, this gives 1/3 < t < 1.')
