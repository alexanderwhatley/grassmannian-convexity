# A cubic Plücker sign rule and its coverage

All brackets below are **oriented** determinants:
\(p_{abc}=\det(v_a,v_b,v_c)\), with indices in the displayed order. Assume
all minors used in denominators are nonzero. For six distinct ordered labels
\((a,b,c,d,i,j)\), put
\[
G_{ab,cd}^{ij}=p_{abi}p_{cdj}-p_{abj}p_{cdi}.
\]

## A one-hypothesis sign rule

The universal identity
\[
p_{adi}G_{ab,cd}^{ij}
 =p_{abi}p_{acd}p_{dij}+p_{abd}p_{aij}p_{cdi}\tag{1}
\]
gives a direct test: **if the two products on the right have the same
nonzero sign, then the sign of \(G\) equals the sign of either product
multiplied by \(p_{adi}\)**. This is a necessary sign condition for every
real matrix. It uses only signs and does not compare numerical magnitudes.

For example, with labels \((1,2,3,4,5,6)\), (1) reads
\[
p_{145}G_{56}
=p_{125}p_{134}p_{456}+p_{124}p_{156}p_{345}.
\]
`verify_plucker_sign_identities.py` checks this identity as a formal integer
polynomial in the 18 independent entries of a generic \(3\times6\) matrix;
there is no numerical substitution or symbolic-algebra dependency. Arbitrary
six-label relabeling follows by renaming variables.

For a fixed unordered pairing of six labels, there are \(3!2^3=48\)
orientations: permute the three pairs and reverse any subset of the pairs.
The bracket \(G\) changes sign by the parity of the pair permutation plus
that of the pair reversals. Applying (1) under all these orientations gives
48 necessary tests for \(G_{56}\) and 48 for \(G_{57}\). The independently
coded `verify_three_product_sign_rule.py` generates the 96 tests from these
permutations; it does not hardcode an orientation table.

## The two-hypothesis rule

The earlier form proposed for \(G_{56}\) is
\[
\begin{aligned}
\operatorname{sgn}(p_{123}p_{145})
 &=\operatorname{sgn}(p_{125}p_{134}),\\
\operatorname{sgn}(p_{135}p_{456})
 &=\operatorname{sgn}(p_{156}p_{345})
\end{aligned}
\quad\Longrightarrow\quad
\operatorname{sgn}(G_{56})=\operatorname{sgn}(p_{124}p_{356}).\tag{2}
\]
It follows from two ordinary Plücker relations:
\[
p_{124}p_{135}=p_{123}p_{145}+p_{125}p_{134},\qquad
p_{145}p_{356}=p_{135}p_{456}+p_{156}p_{345},
\]
and the cyclic identity \(G_{56}=p_{124}p_{356}-p_{123}p_{456}\).
Indeed, the two sign equalities make each right-hand sum have the sign of
either summand and strictly greater magnitude. Multiplying the inequalities
and cancelling the nonzero factors \(p_{135}p_{145}\) shows that
\(p_{124}p_{356}\) and \(p_{123}p_{456}\) have the same sign, while the
first has strictly larger magnitude. Their difference therefore has the
sign claimed in (2). All three identities are also proved by exact
polynomial coefficient expansion in `verify_plucker_sign_identities.py`.
The relabeled versions hold for every ordered six-tuple.

The one-hypothesis rule (1) implies (2) for real matrices: the two
hypotheses in (2) make the two right-hand products in (1) have the same
sign by the two displayed Plücker relations. The rule is applied to the
formal sign over-approximation only as a **necessary** condition; states it
rejects are not realizable as real matrices.

## Exhaustive coverage in the current sign graph

The baseline 52-sign model accepts 23,246,848 formal augmented states. Its
exact abstract optimal rank is stored in
`../grassmann_37_continuation/new_work/augmented_optimal_rank.bin`. On the
subsets below, independent extraction and sign-mask evaluation find:

| Formal subset | Number | Rejected by (2), all 96 orientations | Rejected by (1), all 96 orientations |
|---|---:|---:|---:|
| \(H=0\), \(p_{123}<0\) | 25,519 | 25,519 | 25,519 |
| \(m=4\), \(H=10\) | 24 | 24 | 24 |
| \(m=4\), \(H=12\) | 12 | 0 | 0 |

Among the 25,519 target-negative rank-0 states, 14,785 fail a \(G_{56}\)
orientation and 14,835 fail a \(G_{57}\) orientation; the overlap is 4,101.
These are graph-state counts, and removing them does not by itself prove
that all remaining states or paths are realizable. The scripts also check
all 96 sign-mask encodings against 2,000 exact random real matrices; that
experiment is a diagnostic, while identity (1) is the proof.

## Consequence in the alternating chamber

Suppose \(p_{567}>0\) and
\(\operatorname{sgn}p_{abc}=(-1)^{a+b+c}\) for every ordered triple.
After alternating column reorientation, every ordered minor is strictly
positive. For \(4<i<j\), every factor on the right of (1) and the factor
\(p_{14i}\) are positive; thus
\[
\frac{p_{12i}}{p_{34i}}>\frac{p_{12j}}{p_{34j}}>0.
\]
Alternating column reorientation multiplies the numerator and denominator
of each ratio by the same sign, so the ratios are unchanged. In particular
\(r_5>r_6>r_7>0\), and in the original orientation
\(G_{56}<0<G_{57}\) and \(G_{67}<0\). All three inequalities are strict:
no auxiliary equality can occur in this chamber. The ratio condition is
therefore automatic, not a new restriction inside the real alternating
chamber. Twelve exact signed moment-curve matrices realizing the twelve
surviving formal \(m=4\) sign states are in `h12_moment_examples.json`;
this does not alone establish a 12-change continuation for every matrix in
the chamber.

## Reproduction

From this directory, with assertions enabled:

```sh
c++ -O3 -std=c++17 -pthread extract_h0_negative.cpp -o extract_h0_negative
./extract_h0_negative > h0_negative_keys.txt
c++ -O3 -std=c++17 -pthread extract_m4_augmented.cpp -o extract_m4_augmented
./extract_m4_augmented > m4_augmented_keys.txt
python3 verify_plucker_sign_identities.py
python3 verify_three_product_sign_rule.py
```

The `.log` files record the outputs. The extractors use the shared old key
generator and the H rank file; the sign identities and the orientation-mask
construction are independent of the G-search implementation.
