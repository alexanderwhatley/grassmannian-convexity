#!/usr/bin/env python3
"""Exact root count for a rank-3 alternating moment-curve start under e^{tJ}."""
import sympy as s
from math import factorial
from itertools import combinations
x=s.symbols('x')
for nodes in ([1,2,3,4,5,6,7],[-144,-101,-91,-21,100,105,132]):
 M=s.Matrix([[(-1)**i*nodes[i-1]**k for i in range(1,8)] for k in range(3)])
 L=s.Matrix([[s.Rational(0) if i<j else x**(i-j)/factorial(i-j) for j in range(7)] for i in range(7)])
 p=s.factor((M*L)[:,:3].det());print('nodes',nodes,'poly',p)
 print('all real roots',s.polys.polytools.count_roots(p,-s.oo,s.oo),'positive roots',s.polys.polytools.count_roots(p,0,s.oo))
 print('isolating intervals',s.polys.polytools.intervals(p,eps=s.Rational(1,1000)))
