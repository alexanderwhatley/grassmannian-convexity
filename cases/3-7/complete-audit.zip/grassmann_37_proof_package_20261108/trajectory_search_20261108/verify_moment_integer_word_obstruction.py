#!/usr/bin/env python3
"""Exact symbolic checks for the first-ten-move integer obstruction."""
if not __debug__:raise RuntimeError('assertions are required')
def C(x):return {():x} if x else {}
def V(x):return {(x,):1}
def add(a,b,k=1):
 out=a.copy()
 for m,c in b.items():
  out[m]=out.get(m,0)+k*c
  if not out[m]:del out[m]
 return out
def mul(a,b):
 out={}
 for m,c in a.items():
  for n,d in b.items():
   key=tuple(sorted(m+n));out[key]=out.get(key,0)+c*d
   if not out[key]:del out[key]
 return out
def prod(*values):
 out=C(1)
 for v in values:out=mul(out,v)
 return out
def det(a,b,c):
 return add(add(mul(a[0],add(mul(b[1],c[2]),mul(b[2],c[1]),-1)),mul(a[1],add(mul(b[0],c[2]),mul(b[2],c[0]),-1)),-1),mul(a[2],add(mul(b[0],c[1]),mul(b[1],c[0]),-1)))
cols=[[C((-1)**i),C((-1)**i*i),C((-1)**i*i*i)] for i in range(1,8)]
def p(a,b,c):return det(cols[a-1],cols[b-1],cols[c-1])
initial={(1,2,3):2,(1,2,4):-6,(1,3,4):6,(1,2,5):12,(1,3,5):-16,
         (1,4,5):12,(2,3,4):-2,(2,3,5):6,(2,4,5):-6,(3,4,5):2}
assert all(p(*I)==C(x) for I,x in initial.items())
def move(j,t):cols[j-1]=[add(a,mul(t,b)) for a,b in zip(cols[j-1],cols[j])]
a,b,c,d,e,f,g,h=(V(x) for x in 'abcdefgh')
move(3,a);move(2,b)
assert p(1,2,4)==add(mul(C(6),b),C(-6))
move(3,c)
assert p(1,2,5)==add(add(C(12),mul(C(-16),b)),prod(C(12),a,b))
move(4,d)
expected_r=add(add(add(C(6),mul(C(-16),d)),prod(C(12),a,d)),prod(C(12),c,d))
expected_s=add(add(add(add(C(-2),mul(C(6),d)),prod(C(-6),a,d)),prod(C(-6),c,d)),prod(C(2),b,c,d))
assert p(1,3,4)==expected_r and p(2,3,4)==expected_s
move(3,e);move(2,f);move(3,g)
assert p(1,3,4)==expected_r and p(2,3,4)==expected_s
move(1,h)
assert p(1,3,4)==add(expected_r,mul(h,expected_s))
print('PASS ten exact initial moment-curve minors')
print('PASS symbolic formulas after moves 2, 3, 4, 7 and 8')
# Second abstract-word prefix 3,4,3,2,1,3,2,3. Reset the original columns.
cols=[[C((-1)**i),C((-1)**i*i),C((-1)**i*i*i)] for i in range(1,8)]
move(3,a)
assert p(2,3,5)==add(C(6),mul(C(-6),a))
move(4,b)
alt_r=add(add(C(6),mul(C(-16),b)),prod(C(12),a,b))
alt_s=add(add(C(-2),mul(C(6),b)),prod(C(-6),a,b))
assert p(1,3,4)==alt_r and p(2,3,4)==alt_s
move(3,c);move(2,d)
assert p(1,3,4)==alt_r and p(2,3,4)==alt_s
move(1,e)
assert p(1,3,4)==add(alt_r,mul(e,alt_s))
print('PASS symbolic formulas for the second non-equivalent word prefix')
print('PASS both integer sign contradictions follow from the accompanying note')
