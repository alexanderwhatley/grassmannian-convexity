# The optimal number of positive shears for 12 crossings

Assume the data-free certificate for the bound \(r(M)\le8+m(M)\), and
the rank-two cyclic-word bound \(r(2,6)\le8\). A generic \(3\times7\)
matrix and a finite sequence of positive elementary column shears can have
12 target changes only if the sequence contains **at least 28 shears**.
The exact example below attains 28. The lower-bound calculation includes a
small, exhaustive 384-state sign-graph check, reproduced by
`verify_at_most_one_j1_two_j5.py`; it is not an analytical proof by itself.

Here a \(j\)-shear is \(v_j\mapsto v_j+t v_{j+1}\), with \(t>0\),
and the target is \(p_{123}\). Starting \(m=4\) is necessary for 12
crossings by \(r\le8+m\). The elementary positive-cell argument identifies
its minor signs, up to a common sign, as \((-1)^{i+j+k}\).

1. **Twelve \(j=3\) shears.** Only generator 3 changes \(p_{123}\), and
   the target is affine in its positive parameter, so each such shear can
   change its sign at most once.
2. **Eleven \(j=2\) or \(j=4\) shears.** The derivative of \(p_{123}\)
   during a 3-shear is \(p_{124}\). Between successive target changes its
   sign must reverse. The only generators that change \(p_{124}\) are 2
   and 4; the eleven intervening intervals are disjoint.
3. **At least one \(j=1\) shear.** Without one, \(v_1\) is fixed. Project
   \(v_2,\dots,v_7\) to \(\mathbb R^3/\mathbb Rv_1\). Positive shears
   induce positive moves of six planar vectors, and the target becomes their
   first determinant. The rank-two bound gives at most eight changes.
4. **At least one \(j=6\) shear.** Otherwise the first six columns are a
   closed system. A functional with at most three sign variations on these
   columns exists: annihilate the first two and perturb them to have the sign
   of the third. Append a generic seventh column sufficiently close to the
   sixth and keep it fixed. The extended seven-column start has \(m\le3\),
   and the prescribed target signs are unchanged; \(r\le11\) contradicts
   the 12 changes. A generic choice avoids the finitely many unwanted walls.
5. **At least two \(j=5\) shears; if there are exactly two, at least two
   \(j=1\) shears.** The independent checker enumerates all 384 first-five
   minor-sign patterns allowed by the rank-three Plücker relations and 1,152
   labeled generator-1–4 sign events. It allows a 5-shear to change the signs
   involving column 5 *arbitrarily*, preserving only the four minors supported
   on columns 1–4; this strictly relaxes actual dynamics. With no restriction
   on generator 1, zero and one such 5-shear allow at most 6 and 9 target
   changes. With at most one generator-1 shear, modeled generously as any
   contiguous run of its feature events, zero, one, and two 5-shears allow at
   most 6, 8, and 10 changes. It also verifies exact nonzero witnesses for all
   12 first-five same-generator event-root resultants. Generic perturbation of
   a finite trajectory therefore separates incidental simultaneous events
   while preserving all finitely many strict target signs.

The last three items imply that generators 1 and 5 contribute at least four
shears in total, and generator 6 contributes at least one. These are distinct
from the twelve 3-shears and eleven 2/4-shears, giving
\(12+11+4+1=28\).

## Exact attaining examples

`witness_28_variant_2507_integer.json` has integer columns and integer
positive parameters, with largest absolute initial entry 121,800 and largest
time 126,843. `moment_curve_28_exact.json` starts from the especially simple
columns \(v_i=(-1)^i(1,i,i^2)\); all its parameters are positive rationals,
with maximum numerator 23,342,437 and maximum denominator 7,940. Both have
target changes at moves
\([1,3,5,7,10,12,15,17,21,23,26,28]\).

In this directory, independently replay either JSON file by both methods:

```sh
python3 verify_generic_12_path.py witness_28_variant_2507_integer.json
python3 ../grassmann_37_continuation/new_work/verify_compact_witness.py witness_28_variant_2507_integer.json
python3 verify_generic_12_path.py moment_curve_28_exact.json
python3 ../grassmann_37_continuation/new_work/verify_compact_witness.py moment_curve_28_exact.json
python3 verify_at_most_one_j1_two_j5.py
```

The first replay evolves all 35 minors in the exterior power; the second
updates integer column representatives, recomputes determinants directly,
and verifies all 52 monitored features are nonzero at every recorded vertex.
Both find exactly 12 changes. Each example independently shows that 28 is
also the minimum for its particular starting matrix; the argument does not
claim every \(m=4\) start can be handled in 28 moves. The exact universal
constructor currently uses at most 40 moves.
