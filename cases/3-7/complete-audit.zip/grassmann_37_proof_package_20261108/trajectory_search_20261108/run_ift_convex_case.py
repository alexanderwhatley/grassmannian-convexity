#!/usr/bin/env python3
"""Try increasingly small epsilon; count only independent exact replay."""
from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parent;key=sys.argv[1]
for k in (10,14,18,24,30,40,50):
 a=subprocess.run([sys.executable,str(root/'construct_ift_12.py'),key,str(k)],capture_output=True,text=True)
 if a.returncode:
  print('epsilon=1e-%s: numerical solve failed'%k,flush=True);continue
 b=subprocess.run([sys.executable,str(root/'verify_one_convex_12.py'),key,str(root/('ift_12_'+key+'.json'))],capture_output=True,text=True)
 if b.returncode:
  print('epsilon=1e-%s: exact replay failed'%k,flush=True);continue
 print(a.stdout.strip(),flush=True);print(b.stdout.strip(),flush=True)
 print('EXACT INDEPENDENT SUCCESS',key,'epsilon=1e-'+str(k),flush=True);break
else:print('NO EXACT CERTIFICATE FOUND',key,flush=True)
