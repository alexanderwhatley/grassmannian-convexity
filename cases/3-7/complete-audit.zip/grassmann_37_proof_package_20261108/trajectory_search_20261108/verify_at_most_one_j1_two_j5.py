#!/usr/bin/env python3
"""Independent reachability audit of the first-five-column overapproximation.

No imported graph code or data: enumerate all 10-sign patterns satisfying
the necessary rank-3 Pluecker relations. A single j1 move is relaxed to an
arbitrary run of j1 feature events; each j5 move is relaxed to an arbitrary
change preserving the four minors supported on columns 1,2,3,4. These are
overapproximations, so a verified upper bound applies to real trajectories.
"""
from collections import defaultdict,deque
from itertools import combinations

if not __debug__:raise RuntimeError('assertions are required')
triples=list(combinations(range(1,6),3));at={x:i for i,x in enumerate(triples)}
def sign(word,a,b,c):
    perm=(a,b,c);inv=sum(perm[i]>perm[j] for i in range(3) for j in range(i+1,3))
    return (1 if word>>at[tuple(sorted(perm))]&1 else -1)*(-1 if inv%2 else 1)
def plausible(word):
    for p in range(1,6):
        a,b,c,d=[q for q in range(1,6) if q!=p]
        terms=(sign(word,p,a,b)*sign(word,p,c,d),-sign(word,p,a,c)*sign(word,p,b,d),sign(word,p,a,d)*sign(word,p,b,c))
        if terms[0]==terms[1]==terms[2]:return False
    return True
states=[w for w in range(1024) if plausible(w)];legal=set(states);assert len(states)==384
fixed=[at[x] for x in combinations(range(1,5),3)]
def group(w):return sum(((w>>b)&1)<<i for i,b in enumerate(fixed))
groups=defaultdict(list)
for w in states:groups[group(w)].append(w)
edges={w:[] for w in states}
for w in states:
    for j in range(1,5):
        for b,I in enumerate(triples):
            if j not in I or j+1 in I:continue
            source=tuple(sorted((set(I)-{j})|{j+1}));d=at[source]
            v=w^(1<<b)
            if ((w>>b)^(w>>d))&1 and v in legal:
                edges[w].append((v,j,int(I==(1,2,3))))
assert len(set(s for s in states if s&1))==192
start=sum(((-1)**sum(I)>0)<<i for i,I in enumerate(triples));assert start in legal
# mode: 0 before j1, 1 in its only run, 2 after that run.
root=(start,0,0,0);todo=deque([root]);seen={root};max_by_j5=[-1]*3;count=0
while todo:
    w,mode,uses,flips=todo.popleft();count+=1;max_by_j5[uses]=max(max_by_j5[uses],flips)
    assert flips<=10,('formal 11-crossing path found',w,mode,uses,flips)
    for v,j,weight in edges[w]:
        if j==1:
            if mode==2:continue
            nextmode=1
        else:nextmode=2 if mode==1 else mode
        node=(v,nextmode,uses,flips+weight)
        if node not in seen:seen.add(node);todo.append(node)
    if uses<2:
        nextmode=2 if mode==1 else mode
        for v in groups[group(w)]:
            node=(v,nextmode,uses+1,flips)
            if node not in seen:seen.add(node);todo.append(node)
print('PASS',len(states),'necessary first-five sign states;',sum(map(len,edges.values())),'labeled event edges')
print('PASS',count,'reachable augmented states; maximum target crossings by j5 uses',max_by_j5)
print('PASS at most 10 target crossings with at most one j1 shear and two j5 shears')
