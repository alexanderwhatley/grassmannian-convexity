#!/usr/bin/env python3
"""Produce exact event transitions along genuine positive-move trajectories.

Inputs are random integer matrices; every move has positive integer time,
followed by a harmless positive projective column normalization. All 52
tracked features are evaluated as exact integers at both endpoints; exact
rational roots partition each move. A second program checks the graph rules.
"""
from fractions import Fraction as Q
from math import gcd
from pathlib import Path
import json,random,sys

source=Path('stress_g_feature_ties.py').read_text().split('rng=random.Random')[0]
ctx={};exec(compile(source,'stress_g_feature_ties.py','exec'),ctx)
P,vals,apply=ctx['P'],ctx['vals'],ctx['apply']
rng=random.Random(int(sys.argv[3]) if len(sys.argv)>3 else 781205)
trajectories=int(sys.argv[1]) if len(sys.argv)>1 else 200
steps=int(sys.argv[2]) if len(sys.argv)>2 else 20
target=Path('g_exact_event_transitions.txt');out=target.open('w')
stats={'matrices':0,'moves':0,'singleton_events':0,'tied_event_groups':0,'G_events':0,'distinct_keys':set()}
def signkey(a,s,t):
 return sum(1<<i for i,(x,y) in enumerate(zip(a,s)) if Q(x)+t*y>0)
for tr in range(trajectories):
 while True:
  v=[tuple(rng.randint(-30,30) for _ in range(3)) for _ in range(7)]
  a=vals(v)
  if all(a):break
 if a[P.index((5,6,7))]<0:v=[(x,y,-z) for x,y,z in v];a=vals(v)
 stats['matrices']+=1
 for step in range(steps):
  j=rng.randrange(6);b=vals(apply(v,j,1));s=[y-x for x,y in zip(a,b)]
  if any(not x for x in a):raise AssertionError('nongeneric source')
  duration=rng.randint(1,8)
  while any(a[i]+duration*s[i]==0 for i in range(52)):duration+=1
  groups={}
  for i,(x,y) in enumerate(zip(a,s)):
   if not y:continue
   t=Q(-x,y)
   if 0<t<duration:groups.setdefault(t,[]).append(i)
  times=[Q(0)]+sorted(groups)+[Q(duration)]
  for q in range(1,len(times)-1):
   ids=groups[times[q]]
   if len(ids)!=1:stats['tied_event_groups']+=1;continue
   before=(times[q-1]+times[q])/2;after=(times[q]+times[q+1])/2
   ka,kb=signkey(a,s,before),signkey(a,s,after);bit=ids[0]
   assert ka^kb==1<<bit
   out.write(f'{ka} {kb} {j+1} {bit}\n')
   stats['singleton_events']+=1;stats['G_events']+=bit>=50
   stats['distinct_keys'].add(ka);stats['distinct_keys'].add(kb)
  w=apply(v,j,duration);g=gcd(*w[j]);assert g;w[j]=tuple(q//g for q in w[j]);v=w;a=vals(v)
  assert all(a) and a[P.index((5,6,7))]>0
  stats['moves']+=1
out.close();stats['distinct_keys']=len(stats['distinct_keys'])
Path('g_exact_trajectory_summary.json').write_text(json.dumps(stats,indent=2)+'\n')
print('PASS exact positive-move event generation:',stats)
