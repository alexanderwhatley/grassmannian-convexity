# An integer-time obstruction for one optimal word

For the exact simple-moment starting columns
\(v_i=(-1)^i(1,i,i^2)\), **no choice of positive integer parameters** can
produce 12 target changes using the particular 28-generator word

\[
(3,2,3,4,3,2,3,1,2,3,4,3,5,4,3,2,3,6,5,4,3,2,3,1,2,3,4,3).
\]

The obstruction concerns this starting matrix and this word only. The same
word does attain 12 changes with positive rational parameters, as shown by
`moment_curve_28_exact.json`. This note does **not** exclude another optimal
word with integer parameters.

Suppose instead that the displayed word has 12 changes using integer times.
It has exactly twelve generator-3 moves, so every one of them must change
the target sign. Denote the first four times by \(a,b,c,d\), respectively.
The needed initial minors are

\[
\begin{array}{c|rrrrrrrrrr}
I&123&124&134&125&135&145&234&235&245&345\\
\hline
p_I&2&-6&6&12&-16&12&-2&6&-6&2.
\end{array}
\]

After the second move, \(p_{124}=6(b-1)\). The second generator-3 move
must change a negative target to a positive one, hence \(b>1\). After the
third move, and before the fourth, \(p_{125}=12+b(-16+12a)\). The fourth
move must turn \(p_{124}\) negative for the third target change, so
\(p_{125}<0\). As \(a,b\) are positive integers, this forces
\(a=1\) and \(b\ge4\).

The fourth move has parameter \(d\). Since it must reverse
\(p_{124}=6(b-1)>0\) using \(p_{125}=12-4b<0\),
\[
d>\frac{3(b-1)}{2(b-3)}>\frac32,
\]
so \(d\ge2\). A direct symbolic expansion at the end of that move gives
\[
p_{134}=6+d(-16+12a+12c)=6+d(-4+12c)>0,
\quad
p_{234}=-2+2dc(b-3)>0.
\]
The subsequent generators 3, 2 and 3 leave both minors unchanged. The
generator-1 move then replaces \(p_{134}\) by
\(p_{134}+h p_{234}>0\). Immediately after the fourth target crossing,
\(p_{124}>0\); the following generator-2 move increases it by a positive
multiple of this positive \(p_{134}\). Therefore \(p_{124}\) remains
positive, and the next generator-3 move cannot change the positive target
to negative. This contradicts the required fifth target crossing.

`verify_moment_integer_word_obstruction.py` independently checks the stated
initial minors and the exact polynomial formulas after moves 2, 3, 4, 7 and
8 by sparse integer polynomial arithmetic. Run

```sh
python3 verify_moment_integer_word_obstruction.py
```

The sign deductions above then hold for all positive integer values, not
merely a finite search.

## A second, non-equivalent word

The same fixed moment start also has an integer obstruction for any optimal
word beginning
\[
(3,4,3,2,1,3,2,3,\ldots)
\]
with exactly twelve generator-3 moves. This includes the second 28-word
identified by the three-feature abstract search. Let the first two times be
\(a,b\). To make the first generator-2 separator reverse \(p_{124}\),
its derivative after the first generator-4 move must be negative:
\[
p_{134}=6+b(-16+12a)<0.
\]
Positive integer \(a\) forces \(a=1\) and \(b\ge2\). But then, after
the first generator-3 move, \(p_{235}=6-6a=0\), so the generator-4 move
leaves \(p_{234}=-2\). The next generator-3 and generator-2 moves leave
\(p_{234}\) unchanged. Consequently the following generator-1 move adds
a positive multiple of \(-2\) to the already negative \(p_{134}\). The
next generator-2 move cannot reverse the now-negative \(p_{124}\) to
positive, so the fourth target crossing is impossible.

The same symbolic verifier checks these additional identities. This is again
a restriction on one prefix, not on every conceivable 28-generator word.

## All optimal words, under strict vertex genericity

There is also a stronger **computer-assisted** result: no 28-move trajectory
from these exact moment columns can simultaneously have all integer positive
times, 12 target changes, and all 35 maximal minors nonzero at every recorded
vertex. Unlike the preceding two arguments, this statement covers every
28-generator word, and uses the verified optimality lower bound and a small
finite sign search.

First, the first move of an optimal 28-move trajectory must change the target:
otherwise remove it and start at its recorded endpoint, which is generic by
hypothesis, producing 12 changes in only 27 moves. Thus its first generator is
3. Write its positive integer time as \(a\). If \(a=1\), the formula above
gives \(p_{235}=6-6a=0\) at the first vertex, contrary to strictness. If
\(a\ge2\), the first-five sign word after this shear is determined: the
only changing minors are
\[
p_{123}=2-6a<0,\qquad p_{135}=-16+12a>0,\qquad p_{235}=6-6a<0.
\]
All other first-five signs are their original alternating signs.

Optimality gives exactly twelve target-changing 3-shears, eleven 2/4-shears
that each reverse \(p_{124}\), one 6-shear, and either two 1- and two
5-shears, or one 1- and three 5-shears. The exact exhaustive program
`probe_moment_integer_first_move.py` starts from the sign word above and
overapproximates all continuations in both cases. It permits arbitrary valid
same-generator first-five wall order in each shear, and permits a 5-shear to
change the six column-5 minor signs arbitrarily while preserving the four
minors on columns 1–4. The single 6-shear is invisible to the first five
columns. The search visits respectively 4,335 and 4,970 formal states and
reaches no twelfth target change. These relaxations include every generic
real trajectory; therefore \(a\ge2\) is impossible.

Run `python3 probe_moment_integer_first_move.py` from this directory. This
last conclusion still leaves open the possibility of integer times when
incidental non-target zero minors at recorded vertices are allowed.
