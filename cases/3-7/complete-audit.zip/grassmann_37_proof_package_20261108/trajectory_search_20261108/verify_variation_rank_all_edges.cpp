// Independent full certificate for Q=P2-2*[P2>8+m] <= 8+m.
// Classifies m by the positive-four-circuit test via 64-bit pattern masks;
// separately compares with Karp's 21-sequence formula on every base state.
// Uses neither GFeatures nor any closure construction; all 230m candidate
// move-labeled edges are verified directly. Shares the base state enumerator
// and the symbolically audited 108-row derivative table.
#define main gc37_graph_unused_main
#include "../grassmann_37_continuation/rebuild_full_graph.cpp"
#undef main
struct Test {int move,target,a,b,sg;};
struct Circuit {int pa,pb,pc,pd;uint64_t forbidden[16];};
int main(){
 init();auto dirs=direction_types(true);auto masks=sign_masks();Hash H(1ull<<25);vector<uint64_t>keys;keys.reserve(16051200);
 for(auto&w:dirs)for(auto&z:add_axes(w)){uint64_t b=word_key(z);for(auto mask:masks){uint64_t k=b^mask;H.insert(k,keys.size());keys.push_back(k);}}
 uint32_t n=keys.size();assert(n==16051200);vector<uint8_t>rank(n),old(n/2),minvar(n,255),valid(n);
 auto read=[&](string name,vector<uint8_t>&out){ifstream f(name,ios::binary);f.read((char*)out.data(),out.size());assert(f.gcount()==int64_t(out.size()));char ch;assert(!f.read(&ch,1));};
 read("../grassmann_37_continuation/filtered_rank.bin",rank);
 read("../grassmann_37_continuation/history_20261108/g_reachable_50_nohalf.bin",old);
 auto contains=[](const vector<uint8_t>&v,uint32_t c){return bool(v[c/8]&(1u<<(c%8)));};
 auto sgn=[](uint64_t k,int i){return (k>>i&1u)?1:-1;};
 auto orient=[&](uint64_t k,int a,int b,int c){int inv=(a>b)+(a>c)+(b>c);array<int,3>t={a,b,c};sort(t.begin(),t.end());return (inv&1?-1:1)*sgn(k,pid[t[0]][t[1]][t[2]]);};
 auto allow=[&](uint64_t k,int g){
  int q[9]={sgn(k,pid[1][2][5]),sgn(k,pid[3][4][5]),sgn(k,pid[1][2][6]),sgn(k,pid[3][4][6]),sgn(k,pid[1][2][7]),sgn(k,pid[3][4][7]),(g&1)?1:-1,(g&2)?1:-1,sgn(k,35)};
  auto forced=[](int a,int b,int want){return a==b||a==want;};
  if(!forced(q[0]*q[3],q[2]*q[1],q[6])||!forced(q[0]*q[5],q[4]*q[1],q[7])||!forced(q[2]*q[5],q[4]*q[3],q[8]))return false;
  if(abs(q[0]*q[8]-q[2]*q[7]+q[4]*q[6])==3||abs(q[1]*q[8]-q[3]*q[7]+q[5]*q[6])==3)return false;
  for(int t=0;t<2;t++){pair<int,int>pp[3]={{1,2},{3,4},{5,t?7:6}};int want=(g>>t&1)?1:-1;
   for(int r=0;r<3;r++){auto[A,B]=pp[r];auto[C,D]=pp[(r+1)%3];auto[E,F]=pp[(r+2)%3];
    int left=orient(k,A,B,E)*orient(k,C,D,F),right=orient(k,A,B,F)*orient(k,C,D,E);
    if(left!=right&&left!=want)return false;}}
  return true;
 };
 uint64_t variation_masks[7]={};
 for(int mask=0;mask<64;mask++){
  array<int,7>s;for(int i=0;i<6;i++)s[i]=(mask>>i&1)?-1:1;s[6]=1;
  int v=0;for(int i=1;i<7;i++)v+=s[i]!=s[i-1];variation_masks[v]|=1ull<<mask;
 }
 vector<Circuit>circuits;
 for(int a=1;a<=7;a++)for(int b=a+1;b<=7;b++)for(int c=b+1;c<=7;c++)for(int d=c+1;d<=7;d++){
  Circuit x{pid[b][c][d],pid[a][c][d],pid[a][b][d],pid[a][b][c],{}};
  for(int nib=0;nib<16;nib++)for(int mask=0;mask<64;mask++){
   int s[8];for(int i=1;i<=6;i++)s[i]=(mask>>(i-1)&1)?-1:1;s[7]=1;
   int z[4]={s[a]*((nib&1)?1:-1),-s[b]*((nib&2)?1:-1),s[c]*((nib&4)?1:-1),-s[d]*((nib&8)?1:-1)};
   if(z[0]==z[1]&&z[1]==z[2]&&z[2]==z[3])x.forbidden[nib]|=1ull<<mask;
  }
  for(int nib=0;nib<16;nib++)assert(__builtin_popcountll(x.forbidden[nib])==8);
  circuits.push_back(x);
 }
 assert(circuits.size()==35);
 auto circuitm=[&](uint64_t key){
  uint64_t okay=~0ull;for(auto &c:circuits){int nib=((key>>c.pa)&1)|(((key>>c.pb)&1)<<1)|(((key>>c.pc)&1)<<2)|(((key>>c.pd)&1)<<3);okay &=~c.forbidden[nib];}
  for(int i=0;i<=6;i++)if(okay&variation_masks[i])return i;return 100;
 };
 vector<array<pair<int,int>,5>>sequences;
 for(int a=1;a<=7;a++)for(int b=a+1;b<=7;b++){
  array<pair<int,int>,5>v;int k=0;for(int i=1;i<=7;i++)if(i!=a&&i!=b){array<int,3>t={a,b,i};sort(t.begin(),t.end());v[k++]={pid[t[0]][t[1]][t[2]],i&1};}assert(k==5);sequences.push_back(v);
 }
 assert(sequences.size()==21);
 auto karpm=[&](uint64_t key){int largest=0;for(auto a:sequences){int bits=0;for(int i=0;i<5;i++)bits|=(((key>>a[i].first)&1)^a[i].second)<<i;largest=max(largest,__builtin_popcount(unsigned((bits^(bits>>1))&15)));}return 4-largest;};
 vector<thread>threads;atomic<uint64_t>tested{0};uint64_t mc[8][5]{};
 for(int th=0;th<8;th++)threads.emplace_back([&,th](){
  size_t lo=size_t(n)*th/8,hi=size_t(n)*(th+1)/8;uint64_t done=0;
  for(size_t u=lo;u<hi;u++){
   int m=circuitm(keys[u]),k=karpm(keys[u]);if(m!=k||m>4){cerr<<"m discrepancy "<<u<<" circuit="<<m<<" Karp="<<k<<"\n";abort();}
   minvar[u]=m;mc[th][m]++;uint8_t v=0;for(int g=0;g<4;g++)if(allow(keys[u],g))v|=1u<<g;valid[u]=v;done++;
  }tested+=done;
 });
 for(auto&t:threads)t.join();threads.clear();assert(tested==n);
 cout<<"PASS circuit/Karp m equality on all "<<tested<<" base states; m counts";for(int m=0;m<=4;m++){uint64_t v=0;for(int t=0;t<8;t++)v+=mc[t][m];cout<<' '<<m<<':'<<v;}cout<<"\n";
 auto P=[&](uint32_t u,int g){return int(rank[u])-2*int(contains(old,4*u+g));};
 auto Qrank=[&](uint32_t u,int g){int p=P(u,g);return p-2*int(p>8+minvar[u]);};
 vector<Test>tests;ifstream et("../grassmann_37_continuation/event_table.txt");Test t;
 while(et>>t.move>>t.target>>t.a>>t.b>>t.sg)if(t.target<50)tests.push_back(t);assert(tests.size()==108);
 tests.push_back({2,50,pid[1][3][4],pid[3][5][6],1});tests.push_back({4,50,pid[1][2][5],pid[3][5][6],1});tests.push_back({6,50,51,-1,1});
 tests.push_back({2,51,pid[1][3][4],pid[3][5][7],1});tests.push_back({4,51,pid[1][2][5],pid[3][5][7],1});tests.push_back({5,51,35,-1,1});
 uint64_t state_count[8]{},dcount[8][5]{},basecount[8]{},gcount[8]{};int maxq[8][5]{};
 for(int th=0;th<8;th++)threads.emplace_back([&,th](){
  size_t lo=size_t(n)*th/8,hi=size_t(n)*(th+1)/8;
  for(size_t u=lo;u<hi;u++){
   uint64_t base=keys[u];int m=minvar[u];
   for(int g=0;g<4;g++)if(valid[u]&(1u<<g)){
    int p=P(u,g),q=Qrank(u,g);if(p<0||p>12||q<0||q>8+m){cerr<<"state bound fails u="<<u<<" g="<<g<<" m="<<m<<" P="<<p<<" Q="<<q<<"\n";abort();}
    state_count[th]++;dcount[th][m]+=p>8+m;maxq[th][m]=max(maxq[th][m],q);
    uint64_t key=base|(uint64_t(g)<<50);
    for(auto e:tests){int s=sgn(key,e.target),d=e.sg*sgn(key,e.a);if(e.b>=0)d*=sgn(key,e.b);if(s==d)continue;
     if(e.target<50){uint32_t v=H.find(base^(1ull<<e.target));if(v==UINT32_MAX||!(valid[v]&(1u<<g)))continue;
      int w=(e.target==0),z=Qrank(v,g);if(q<z+w){cerr<<"Q base edge fails u="<<u<<" v="<<v<<" bit="<<e.target<<" move="<<e.move<<" m="<<m<<','<<int(minvar[v])<<" Q="<<q<<','<<z<<"\n";abort();}basecount[th]++;
     }else{int h=g^(1<<(e.target-50));if(!(valid[u]&(1u<<h)))continue;int z=Qrank(u,h);
      if(q<z){cerr<<"Q G edge fails u="<<u<<" bit="<<e.target<<"\n";abort();}gcount[th]++;}
    }
   }
  }
 });
 for(auto&t:threads)t.join();
 uint64_t ns=0,nb=0,ng=0,dtotal=0;for(int t=0;t<8;t++){ns+=state_count[t];nb+=basecount[t];ng+=gcount[t];for(int m=0;m<=4;m++)dtotal+=dcount[t][m];}
 assert(ns==23246848&&nb==209042944&&ng==21586944&&dtotal==3641);
 cout<<"PASS Q in [0,8+m] on all "<<ns<<" admissible augmented states; D="<<dtotal<<" with m counts";
 for(int m=0;m<=4;m++){uint64_t d=0;int q=0;for(int t=0;t<8;t++){d+=dcount[t][m];q=max(q,maxq[t][m]);}cout<<' '<<m<<':'<<d<<"(maxQ="<<q<<')';}cout<<"\n";
 cout<<"PASS Q rank inequality on all "<<nb<<" base and "<<ng<<" G move-labeled edges\n";
}
