#!/usr/bin/env python3
"""Clear all denominators using positive row and column scalings."""
from fractions import Fraction as Q
from math import lcm
from pathlib import Path
import json,sys
if hasattr(sys,'set_int_max_str_digits'):sys.set_int_max_str_digits(0)
if len(sys.argv)!=3:raise SystemExit('usage: make_integer_witness_generic.py INPUT OUTPUT')
z=json.loads(Path(sys.argv[1]).read_text());cols=[list(map(Q,c)) for c in z['initial_columns']];moves=[(int(j),Q(t)) for j,t in z['moves']]
ratio=[1]*7
for j,t in moves:ratio[j]=lcm(ratio[j],t.denominator)
lam=[1]*7
for j in range(6,0,-1):lam[j-1]=ratio[j]*lam[j]
cols=[[a*lam[i] for a in col] for i,col in enumerate(cols)]
row=[lcm(*(col[r].denominator for col in cols)) for r in range(3)]
cols=[[a*row[r] for r,a in enumerate(col)] for col in cols]
new=[(j,t*ratio[j]) for j,t in moves]
assert all(x.denominator==1 for col in cols for x in col) and all(t.denominator==1 for j,t in new)
out={'initial_columns':[[int(x) for x in col] for col in cols], 'moves':[[j,int(t)] for j,t in new],
     'method':'Positive diagonal column and positive row scalings of an exact rational witness.'}
Path(sys.argv[2]).write_text(json.dumps(out,indent=2)+'\n')
print('PASS integer columns and positive integer times; column scales',lam,'row scales',row)
