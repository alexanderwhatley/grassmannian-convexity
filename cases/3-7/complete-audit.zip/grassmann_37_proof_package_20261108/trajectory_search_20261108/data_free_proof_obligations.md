# Standalone one-array certificate: mathematical bridge

Normalize \(p_{567}>0\) by an invertible row transformation, which leaves the
number of target sign changes and \(m(M)\) unchanged. Write \(x_i=p_{i67}\).
Generically \(x_1,\ldots,x_5\ne0\). Reorient columns 1–4 to make each
\(x_i\) positive; \(x_5=p_{567}\) already is. In coordinates based on
\(v_6,v_7\), let \(q_i\) be the associated affine point. For four distinct
indices among 1–5,
\[
F_{ij,kl}=p_{ij6}p_{kl7}-p_{ij7}p_{kl6}
=x_ix_jx_kx_l\det(q_j-q_i,q_l-q_k).
\]
Similarly, signs of \(p_{ijk}\) for \(i,j,k\le5\) are signs of the
brackets of two shared-edge vectors, and signs of \(p_{ij6},p_{ij7}\)
are signs of the brackets of the edge \(q_j-q_i\) with the two coordinate
axes. The checker proves the affine formulas exactly as polynomial identities.

The ten affine-edge directions have an antipodal cyclic order. The signs of
the 15 disjoint-edge brackets satisfy the checked 16 exterior identities;
the 10 signs of triples with a shared endpoint supply the other pairwise
edge orientations. Exhaustive enumeration of these necessary conditions
and of angular orders gives 4,560 direction types. Inserting the coordinate
axes into all 220 permitted pairs of gaps and restoring the four independent
column signs yields 16,051,200 distinct 50-sign states. This is an
**over-approximation**: the proof needs every real state to be included,
not every enumerated state to be realizable.

Add the two signs
\(G_{56}=p_{125}p_{346}-p_{126}p_{345}\) and
\(G_{57}=p_{125}p_{347}-p_{127}p_{345}\).
The checker verifies the polynomial identities used for necessary sign
restrictions, with 23,246,848 admissible augmented states. Each of the 52
feature polynomials is affine along each elementary move. Exact polynomial
arithmetic reconstructs all 114 nonzero directional derivatives and the
198 zero derivatives. Hence every generic event is among the checked
move-labeled sign edges. For general finite paths, a single explicit integer
matrix gives a nonzero resultant \(f g'-g f'\) for every one of the 1,070
pairs of active same-move features, proving each coincidence condition is a
proper algebraic subset. Each prefix product of elementary shears is
invertible, so these bad sets and feature-zero endpoint sets pull back to
proper algebraic subsets of the initial-matrix space. An arbitrarily small
initial perturbation avoids them while preserving finitely many specified
strict target sign changes. It also preserves all 35 initial maximal-minor
signs, and hence preserves the four-circuit value \(m(M)\).

For a realizable generic state, a strict row sign pattern is feasible iff
its reoriented columns have no positive dependence. Gordan's alternative
and the rank-three Carathéodory bound reduce this to checking the 35
four-column cofactor circuits. The standalone checker computes \(m\) from
these circuits and cross-checks Karp's minor-sign formula on all 16,051,200
base states.

The data-free checker constructs the full augmented directed graph using these
necessary event conditions. It has 23,246,848 states and 144,788,896 distinct
feature-flip edges. For construction only, it computes strongly connected
components and the longest target-weighted path rank \(H\) of their
condensation DAG; it rejects any positive-weight edge internal to a
component. **The final correctness check does not assume that the SCC
computation or the longest-path calculation is correct.** It directly checks
for every admissible state and every move-labeled edge \(u\to v\), with
\(w=1\) exactly for a change of \(p_{123}\), that
\[
0\le H(u)\le8+m(u),\qquad H(u)\ge H(v)+w.
\]
There are 209,042,944 labeled base-feature edges and 21,586,944 labeled
additional-feature edges. The maximum checked \(H\) by \(m=0,1,2,3,4\)
is respectively 8, 9, 10, 11, 12. Summing the second inequality along a
generically perturbed path gives \(r(M)\le8+m(M)\le12\).

The separate exact rational verifier checks 4,608 positive moves with
12 target sign changes. Thus the lower example and the checked upper
certificate give the desired value 12, conditional on independent review
of the mathematical reduction and implementation. Exact examples also
attain 8, 9, 10, and 11 changes in the classes \(m=0,1,2,3\).
