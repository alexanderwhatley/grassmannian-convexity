#!/usr/bin/env python3
"""Exact verification of all 52 tracked feature signs at path vertices."""
from fractions import Fraction as Q
from itertools import combinations
from pathlib import Path
import json,sys
if hasattr(sys,'set_int_max_str_digits'):sys.set_int_max_str_digits(0)
z=json.loads(Path(sys.argv[1]).read_text());v=[tuple(map(Q,c)) for c in z['initial_columns']];I=list(combinations(range(7),3))
def det(a,b,c):return a[0]*(b[1]*c[2]-b[2]*c[1])-a[1]*(b[0]*c[2]-b[2]*c[0])+a[2]*(b[0]*c[1]-b[1]*c[0])
P={a:det(*(v[i] for i in a)) for a in I};F=[]
for a,b,c,d in combinations(range(1,6),4):F += [(a,b,c,d),(a,c,b,d),(a,d,b,c)]
def vals(P):
 p=lambda a,b,c:P[tuple(sorted((a-1,b-1,c-1)))]
 q=[P[a] for a in I]+[p(a,b,6)*p(c,d,7)-p(a,b,7)*p(c,d,6) for a,b,c,d in F]
 q += [p(1,2,5)*p(3,4,6)-p(1,2,6)*p(3,4,5),p(1,2,5)*p(3,4,7)-p(1,2,7)*p(3,4,5)]
 return q
zeros=[]
for step in range(len(z['moves'])+1):
 vv=vals(P)
 for bit,x in enumerate(vv):
  if not x:zeros.append((step,bit))
 if step==len(z['moves']):break
 m=z['moves'][step]
 if isinstance(m,dict):j=m['move']-1;t=Q(m['time'])
 else:j=m[0]-1;t=Q(m[1])
 assert 0<=j<6 and t>0;new={}
 for a in I:
  if j in a and j+1 not in a:
   b=tuple(sorted((set(a)-{j})|{j+1}));new[a]=P[a]+t*P[b]
 P.update(new)
print('steps',len(z['moves']),'feature-zero vertices',zeros)
assert not zeros
print('PASS all 52 features nonzero at every recorded vertex')
