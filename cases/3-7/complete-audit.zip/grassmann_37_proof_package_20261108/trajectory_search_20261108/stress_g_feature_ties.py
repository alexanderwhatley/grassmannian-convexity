#!/usr/bin/env python3
"""Exact rational audit of G56/G57 event roots along positive shears.

This is an independent integer implementation of all 35 minors, 15 prior F
features, and the two new G features. It records tied positive event roots,
verifies all 52 features are affine along each shear, and checks the six
claimed G derivatives directly. Random testing does not establish coverage.
"""
from collections import Counter
from fractions import Fraction as Q
from itertools import combinations
from pathlib import Path
import json,random,sys

P=list(combinations(range(1,8),3));F=[(1,2,3,4),(1,3,2,4),(1,4,2,3),(1,2,3,5),(1,3,2,5),
 (1,5,2,3),(1,2,4,5),(1,4,2,5),(1,5,2,4),(1,3,4,5),(1,4,3,5),(1,5,3,4),(2,3,4,5),(2,4,3,5),(2,5,3,4)]
def det(a,b,c):return a[0]*(b[1]*c[2]-b[2]*c[1])-a[1]*(b[0]*c[2]-b[2]*c[0])+a[2]*(b[0]*c[1]-b[1]*c[0])
def vals(v):
 def p(i,j,k):return det(v[i-1],v[j-1],v[k-1])
 q=[p(*I) for I in P]
 q += [p(a,b,6)*p(c,d,7)-p(a,b,7)*p(c,d,6) for a,b,c,d in F]
 q += [p(1,2,5)*p(3,4,6)-p(1,2,6)*p(3,4,5),p(1,2,5)*p(3,4,7)-p(1,2,7)*p(3,4,5)]
 return q
def apply(v,j,t):
 w=v[:];w[j]=tuple(a+t*b for a,b in zip(v[j],v[j+1]));return w
rng=random.Random(int(sys.argv[2]) if len(sys.argv)>2 else 701105)
N=int(sys.argv[1]) if len(sys.argv)>1 else 1000
hist=Counter();events=Counter();examples={};any_g_ties=Counter();accepted=0
for trial in range(N):
 v=[tuple(rng.randint(-30,30) for _ in range(3)) for i in range(7)]
 a=vals(v)
 if not all(a):continue
 if a[P.index((5,6,7))]<0:v=[(x,y,-z) for x,y,z in v];a=vals(v)
 accepted+=1
 for j in range(6):
  b=vals(apply(v,j,1));c=vals(apply(v,j,2));assert all(c[i]-a[i]==2*(b[i]-a[i]) for i in range(52))
  p=lambda i,k,l:det(v[i-1],v[k-1],v[l-1])
  expected={1:(p(1,3,4)*p(3,5,6),p(1,3,4)*p(3,5,7)),
            3:(p(1,2,5)*p(3,5,6),p(1,2,5)*p(3,5,7)),
            4:(0,a[35]),5:(a[51],0)}.get(j,(0,0))
  assert (b[50]-a[50],b[51]-a[51])==expected,(j,v)
  slopes=[b[k]-a[k] for k in range(52)]
  for g in (50,51):
   if not slopes[g]:continue
   for k in range(52):
    if k==g or not slopes[k]:continue
    if a[g]*slopes[k]==a[k]*slopes[g]:any_g_ties[(j+1,g,k)]+=1
  groups={}
  for k in range(52):
   slope=b[k]-a[k]
   if not slope:continue
   t=Q(-a[k],slope)
   if t>0:groups.setdefault(t,[]).append(k)
  for t,ids in groups.items():
   if len(ids)>1:
    hist[tuple(ids)]+=1
    if tuple(ids) not in examples:examples[tuple(ids)]={'initial':v,'move':j+1,'time':str(t),'features':ids}
   if 50 in ids or 51 in ids:events['G_crossings']+=1
 if trial%250==0:print('trial',trial,'accepted',accepted,'tie patterns',len(hist),'G crossings',events['G_crossings'],flush=True)
out={'attempted':N,'accepted':accepted,'g_crossings':events['G_crossings'],
     'any_G_root_ties':[{'move_g_other':k,'count':v} for k,v in any_g_ties.most_common()],
     'ties':[{'features':k,'count':v,'example':examples[k]} for k,v in hist.most_common()]}
Path('g_tie_audit_results.json').write_text(json.dumps(out,indent=2)+'\n')
print('PASS exact affine identities and G derivative values for',accepted,'matrices and',accepted*6,'shears')
print('positive-root tie patterns:',[(k,v) for k,v in hist.most_common(30)])
print('ties of a G root with another feature, either sign:',any_g_ties.most_common(30))
