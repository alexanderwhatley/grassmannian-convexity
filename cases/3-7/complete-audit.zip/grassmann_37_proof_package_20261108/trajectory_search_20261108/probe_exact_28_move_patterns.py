#!/usr/bin/env python3
"""Overapproximate both sharp 28-move generator-count patterns.

For a 28-move 12-crossing path, exactly twelve j3 moves flip p123 and
exactly eleven j2/j4 moves separate them, each flipping p124. A j1 move
is modeled by a complete same-label minor-event closure; a j5 move is an
arbitrary jump preserving the first-four minors; and j6 is invisible to the
first five columns. The search may therefore admit unrealizable paths.
"""
from collections import deque
from contextlib import redirect_stdout
from pathlib import Path
import io,runpy
with redirect_stdout(io.StringIO()):n=runpy.run_path(str(Path(__file__).with_name('verify_at_most_one_j1_two_j5.py')))
start,edges,groups,group,states,at=n['start'],n['edges'],n['groups'],n['group'],n['states'],n['at']
p123=at[(1,2,3)];p124=at[(1,2,4)]
def same_shear_closure(root,j):
    # For a fixed generator all derivative minor signs are invariant, hence
    # every eligible tracked minor can flip at most once in the same shear.
    seen={root};todo=[root]
    while todo:
        u=todo.pop()
        for v,label,weight in edges[u]:
            if label==j and v not in seen:seen.add(v);todo.append(v)
    return tuple(seen)
closures={(w,j):same_shear_closure(w,j) for w in states for j in range(1,5)}
def search(max1,max5):
    # state is (word, flips, separator still required, used j1, used j5)
    root=(start,0,False,0,0);todo=deque([root]);prev={root:None};moves={}
    while todo:
        q=todo.popleft();w,k,need,a,b=q
        if k==12:
            path=[];cur=q
            while prev[cur] is not None:path.append(moves[cur]);cur=prev[cur]
            path.reverse();return len(prev),path,q
        def add(node,move):
            if node not in prev:prev[node]=q;moves[node]=move;todo.append(node)
        if not need:
            for v in closures[w,3]:
                if (w^v)>>p123&1:add((v,k+1,True,a,b),3)
        if 1<=k<12 and need:
            for j in (2,4):
                for v in closures[w,j]:
                    if (w^v)>>p124&1:add((v,k,False,a,b),j)
        if a<max1:
            for v in closures[w,1]:add((v,k,need,a+1,b),1)
        if b<max5:
            for v in groups[group(w)]:add((v,k,need,a,b+1),5)
    return len(prev),None,None
for a,b in ((1,3),(2,2)):
    count,path,final=search(a,b)
    print('case j1<=',a,'j5<=',b,'visited',count,'formal 12-flip path?',path is not None)
    if path is not None:print('abstract word ignoring mandatory j6:',path,'final',final)
