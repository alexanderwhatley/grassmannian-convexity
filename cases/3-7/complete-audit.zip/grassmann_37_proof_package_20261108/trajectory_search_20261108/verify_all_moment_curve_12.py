#!/usr/bin/env python3
"""Recheck all twelve compact rational moment-curve certificates."""
from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parent
keys=['18204','18200','20024','19996','3868','3612','20248','20252','3864','3640','19992','3608']
assert len(keys)==len(set(keys))==12
for key in keys:
 path=root/('moment_curve_12_compact_'+key+'.json')
 subprocess.run([sys.executable,str(root/'verify_one_moment_curve_12.py'),key,str(path)],check=True)
print('PASS all 12 distinct H12 Fword chambers have exact 228-move moment-curve witnesses',flush=True)
