#!/usr/bin/env python3
"""Independently audit the 16 affine-filter identities and denominator signs.

Every generic real 3x7 matrix with p567>0 passes this filter: in affine
coordinates, each feature is a 4-fold product of x_i times a bracket of
point-difference vectors. Each forbidden pattern has all signed terms of a
nontrivial zero linear combination with the same sign.
"""
from itertools import combinations
from pathlib import Path
import re

here=Path(__file__).resolve().parent
text=(here/'../grassmann_37_continuation/affine_circuit_filter16.hpp').read_text()
def arr(name):
 m=re.search(r'\b'+re.escape(name)+r'\[\]\s*=\s*\{([^}]*)\}',text);assert m
 return list(map(int,re.findall(r'\d+',m.group(1))))
den=arr('gc37_small_denominator_masks');plus=arr('gc37_small_plus');minus=arr('gc37_small_minus')
assert len(den)==15 and len(plus)==len(minus)==16
labels=[]
for a,b,c,d in combinations(range(1,6),4):labels += [(a,b,c,d),(a,c,b,d),(a,d,b,c)]
assert len(labels)==15
for i,(a,b,c,d) in enumerate(labels):assert den[i]==sum(1<<(k-1) for k in (a,b,c,d))
# Place P5=0, regard P1,...,P4 as formal 2D vectors. The following are
# coordinates of (P_j-P_i) wedge (P_l-P_k) in their exterior square.
def edge(i,j):return [int(j==k)-int(i==k) for k in range(1,5)]
def bracket(i,j,k,l):
 a,b=edge(i,j),edge(k,l)
 return [a[r]*b[s]-a[s]*b[r] for r,s in combinations(range(4),2)]
B=[bracket(*a) for a in labels]
for k,(p,m) in enumerate(zip(plus,minus)):
 assert p and m and not p&m and (p|m)<1<<15
 coef=[int(bool(p>>i&1))-int(bool(m>>i&1)) for i in range(15)]
 assert all(sum(coef[i]*B[i][j] for i in range(15))==0 for j in range(6)),(k,p,m)
# direction_types also calls an earlier hard-coded three-term prefilter.
# Audit those actual C++ triples as well; otherwise the 16-mask proof alone
# would not rule out an overly restrictive independent prefilter.
generator=(here/'../grassmann_37_continuation/rebuild_full_graph.cpp').read_text()
block=re.search(r'const\s+int\s+triples\[10\]\[3\]\s*=\s*\{(.*?)\};',generator,re.S)
assert block
triples=[list(map(int,re.findall(r'-?\d+',line))) for line in re.findall(r'\{([^{}]+)\}',block.group(1))]
assert len(triples)==10 and all(len(a)==3 for a in triples)
for rel in triples:
 assert all(x and abs(x)<=15 for x in rel)
 coef=[sum((1 if x>0 else -1) for x in rel if abs(x)==i+1) for i in range(15)]
 assert all(sum(coef[i]*B[i][j] for i in range(15))==0 for j in range(6)),rel
# Symbolic affine normalization of each 3D feature, mechanically using a
# tiny polynomial dictionary to avoid dependence on sympy or other code.
def add(p,q):
 r=p.copy()
 for k,v in q.items():r[k]=r.get(k,0)+v
 return {k:v for k,v in r.items() if v}
def neg(p):return {k:-v for k,v in p.items()}
def mul(p,q):
 r={}
 for a,v in p.items():
  for b,w in q.items():
   key=tuple(sorted(a+b));r[key]=r.get(key,0)+v*w
 return {k:v for k,v in r.items() if v}
def var(s):return {(s,):1}
for i,j,k,l in labels:
 # v_i=(x_i,x_i*y_i,x_i*z_i), v6=(0,1,0), v7=(0,0,1)
 def minor6(a,b):return mul(mul(var('x'+str(a)),var('x'+str(b))),add(var('z'+str(a)),neg(var('z'+str(b)))))
 def minor7(a,b):return mul(mul(var('x'+str(a)),var('x'+str(b))),add(var('y'+str(b)),neg(var('y'+str(a)))))
 f=add(mul(minor6(i,j),minor7(k,l)),neg(mul(minor7(i,j),minor6(k,l))))
 cross=add(mul(add(var('y'+str(j)),neg(var('y'+str(i)))),add(var('z'+str(l)),neg(var('z'+str(k))))),neg(mul(add(var('z'+str(j)),neg(var('z'+str(i)))),add(var('y'+str(l)),neg(var('y'+str(k)))))))
 product={():1}
 for t in (i,j,k,l):product=mul(product,var('x'+str(t)))
 assert f==mul(product,cross),(i,j,k,l)
print('PASS: all 15 feature denominators and affine-bracket identities')
print('PASS: all 16 actual C++ rejection masks and 10 three-term prefilter rules are necessary strict-sign conditions')
