#!/usr/bin/env python3
"""Construct a 12-prefix using the positive-cell implicit-function theorem.

For an exact rational alternating-chamber seed M, solve Y_epsilon T(t)=MD
in the [A|I3] Grassmannian chart at high precision, rationalize the 12
positive parameters, conjugate the inverse to positive shears, and append
the scaled 207-move exact witness. An independent exact replay is required.
"""
from pathlib import Path
from fractions import Fraction as Q
from itertools import combinations
import json,sys
import mpmath as mp
sys.set_int_max_str_digits(0);root=Path(__file__).resolve().parent
key=sys.argv[1] if len(sys.argv)>1 else 'simple';k=int(sys.argv[2]) if len(sys.argv)>2 else 10
if key=='simple':entry=json.loads((root/'simple_moment_seed.json').read_text())[key]
else:entry=json.loads((root/'convex_nonconic_seeds.json').read_text())[key]
seed=entry['initial_columns'];witness=json.loads((root.parent/'grassmann_37_continuation/new_work/neville_lower12.json').read_text());W=witness['initial_columns']
D=[(-1)**i for i in range(1,8)]
def det(a,b,c):return a[0]*(b[1]*c[2]-b[2]*c[1])-a[1]*(b[0]*c[2]-b[2]*c[0])+a[2]*(b[0]*c[1]-b[1]*c[0])
v=[[Q(x)*D[i] for x in col] for i,col in enumerate(seed)]
P=lambda a,b,c:det(v[a-1],v[b-1],v[c-1]);norm=P(5,6,7);assert norm>0
p=lambda a,b,c:P(a,b,c)/norm
assert all(p(*I)>0 for I in combinations(range(1,8),3))
t0=[p(1,6,7)*p(4,5,6)/p(1,5,6),p(1,5,6)*p(3,4,5)/(p(1,4,5)*p(4,5,6)),
 p(1,4,5)*p(2,3,4)/(p(1,3,4)*p(3,4,5)),p(1,3,4)/p(2,3,4),
 p(1,2,7)*p(1,5,6)/(p(1,2,6)*p(1,6,7)),p(1,2,6)*p(1,4,5)/(p(1,2,5)*p(1,5,6)),
 p(1,2,5)*p(1,3,4)/(p(1,2,4)*p(1,4,5)),p(1,2,4)/p(1,3,4),
 p(1,2,6)/p(1,2,7),p(1,2,5)/p(1,2,6),p(1,2,4)/p(1,2,5),p(1,2,3)/p(1,2,4)]
assert len(t0)==12 and all(q>0 for q in t0)
mp.mp.dps=100
def mpq(q):return mp.mpf(q.numerator)/q.denominator
def matrix(cols):return mp.matrix([[mp.mpf(col[r]) for col in cols] for r in range(3)])
X=matrix([[seed[i][r]*D[i] for r in range(3)] for i in range(7)])
Y=matrix([[W[i][r]*D[i] for r in range(3)] for i in range(7)])
Xchart=(X[:,4:7]**-1)*X[:,0:4];Ychart=(Y[:,4:7]**-1)*Y[:,0:4]
epsilon=mp.power(10,-k);word=[4,3,2,1,5,4,3,2,6,5,4,3]
def chart(z):
 Z=mp.matrix(3,7)
 for r in range(3):
  for c in range(4):Z[r,c]=epsilon*Ychart[r,c]
  Z[r,4+r]=1
 for j,a in zip(word,z):
  t=mp.exp(a)
  for r in range(3):Z[r,j-1]+=t*Z[r,j]
 return (Z[:,4:7]**-1)*Z[:,0:4]
def f(*z):
 A=chart(z);return tuple(A[i,j]-Xchart[i,j] for i in range(3) for j in range(4))
z0=[mp.log(mpq(q)) for q in t0]
print('seed',key,'epsilon 1e-'+str(k),'initial max residual',mp.nstr(max(map(abs,f(*z0))),8),flush=True)
z=mp.findroot(f,tuple(z0),tol=mp.mpf('1e-80'),maxsteps=50,solver='mdnewton')
print('solved max residual',mp.nstr(max(map(abs,f(*z))),8),flush=True)
t=[Q(mp.nstr(mp.exp(a),85)) for a in z];assert all(x>0 for x in t)
prefix=[{'move':j,'time':str(q)} for j,q in reversed(list(zip(word,t)))]
# Under Lambda=(epsilon,...,epsilon,1,1,1), witness parameter changes only
# for generator 4, by multiplication with epsilon.
eps=Q(1,10**k);moves=prefix+[{'move':j,'time':str(Q(ts)*(eps if j==4 else 1))} for j,ts in witness['moves']]
out={'initial_columns':[[str(x) for x in col] for col in seed], 'moves':moves,'target_changes':12,'prefix_moves':12,
     'description':'Twelve positive IFT prefix moves plus scaled 207-move witness','seed_id':key,'epsilon':str(eps)}
if key!='simple':out['expected_Fword']=entry['Fword']
(root/('ift_12_'+key+'.json')).write_text(json.dumps(out,indent=2)+'\n')
print('Rationalized 219-move candidate; independent exact replay required',flush=True)
