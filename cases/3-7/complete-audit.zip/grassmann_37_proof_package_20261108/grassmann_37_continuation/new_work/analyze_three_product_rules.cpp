// Test one universal 3-product sign implication, in all pair orientations,
// on the formally admitted H=0, p123-negative traps.
#define main gc37_original_unused_main
#include "../rebuild_full_graph.cpp"
#undef main
struct Rule {array<int,6> v;int bit,mult;};
int main(){
 init();vector<array<pair<int,int>,3>>features;
 for(auto f:flab)features.push_back({make_pair(f[0],f[1]),make_pair(f[2],f[3]),make_pair(6,7)});
 features.push_back({make_pair(1,2),make_pair(3,4),make_pair(5,6)});
 features.push_back({make_pair(1,2),make_pair(3,4),make_pair(5,7)});
 vector<Rule>rules;
 for(int z=0;z<17;z++){
  array<int,3>perm={0,1,2};
  do{int inv=(perm[0]>perm[1])+(perm[0]>perm[2])+(perm[1]>perm[2]);
   for(int flip=0;flip<8;flip++){
    Rule q{};q.bit=35+z;q.mult=((inv+__builtin_popcount(unsigned(flip)))&1)?-1:1;
    for(int j=0;j<3;j++){auto[a,b]=features[z][perm[j]];if(flip>>j&1)swap(a,b);q.v[2*j]=a;q.v[2*j+1]=b;}
    rules.push_back(q);
   }
  }while(next_permutation(perm.begin(),perm.end()));
 }
 assert(rules.size()==816);
 auto sg=[](uint64_t k,int i){return (k>>i&1)?1:-1;};
 auto p=[&](uint64_t k,int a,int b,int c){int inv=(a>b)+(a>c)+(b>c);array<int,3>x={a,b,c};sort(x.begin(),x.end());return (inv&1?-1:1)*sg(k,pid[x[0]][x[1]][x[2]]);};
 uint64_t total=0,covered=0,by_feature[17]{},best_rules[816]{};int maxviol=0;
 ifstream in("unrealizable_trap_keys.txt");assert(in);uint64_t key;
 while(in>>key){int nviol=0;bool seen[17]{};
  for(size_t i=0;i<rules.size();i++){
   auto q=rules[i];auto[a,b,c,d,e,f]=q.v;
   int x1=p(key,a,b,c)*p(key,a,d,e),x2=p(key,a,b,e)*p(key,a,c,d);
   if(x1!=x2)continue;
   int y1=p(key,a,c,e)*p(key,d,e,f),y2=p(key,a,e,f)*p(key,c,d,e);
   if(y1!=y2)continue;
   int want=p(key,a,b,d)*p(key,c,e,f),actual=q.mult*sg(key,q.bit);
   if(want!=actual){nviol++;seen[q.bit-35]=true;best_rules[i]++;}
  }
  if(nviol)covered++;else if(total<20)cout<<"uncovered key "<<key<<'\n';
  for(int z=0;z<17;z++)by_feature[z]+=seen[z];maxviol=max(maxviol,nviol);total++;
 }
 assert(total==25519);cout<<"PASS three-product rule orbits="<<rules.size()<<"; traps="<<total<<" covered="<<covered<<" uncovered="<<total-covered<<" max violations="<<maxviol<<'\n';
 for(int z=0;z<17;z++)if(by_feature[z])cout<<"feature bit="<<35+z<<" covers "<<by_feature[z]<<'\n';
 vector<pair<uint64_t,int>>order;for(int i=0;i<816;i++)order.push_back({best_rules[i],i});sort(order.rbegin(),order.rend());
 for(int i=0;i<min(8,(int)order.size());i++){auto[count,j]=order[i];if(!count)break;auto q=rules[j];cout<<"rule count="<<count<<" feature="<<q.bit<<" multiplier="<<q.mult<<" labels=";for(int a:q.v)cout<<a;cout<<'\n';}
}
