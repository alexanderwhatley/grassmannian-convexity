#!/usr/bin/env python3
"""Look for m=0 matrices whose fixed-projection upper bound beats graph H.

All sampled columns have last coordinate 1; the known rank-two cyclic
prerank is computed exactly from integer cross products. Output keys can be
looked up in the independently computed 52-sign graph rank array.
"""
from functools import cmp_to_key
from itertools import combinations
from pathlib import Path
from random import Random
import json,sys
if not __debug__:raise RuntimeError('assertions required')
root=Path(__file__).resolve().parent;rng=Random(3794)
trips=list(combinations(range(7),3))
F=[]
for a,b,c,d in combinations(range(1,6),4):F.extend([(a,b,c,d),(a,c,b,d),(a,d,b,c)])
def det(a,b,c):return a[0]*(b[1]*c[2]-b[2]*c[1])-a[1]*(b[0]*c[2]-b[2]*c[0])+a[2]*(b[0]*c[1]-b[1]*c[0])
def cross(a,b):return a[0]*b[1]-a[1]*b[0]
def cyclic_rank(v):
    e=[(v[i+1][0]-v[i][0],v[i+1][1]-v[i][1]) for i in range(6)]
    if any(cross(e[i],e[j])==0 for i,j in combinations(range(6),2)):return None
    assert cross(e[4],e[5])>0
    def vec(x):return e[x-1] if x>0 else (-e[-x-1][0],-e[-x-1][1])
    def half(a):return 0 if a[1]>0 or (a[1]==0 and a[0]>0) else 1
    def cmp(x,y):
        a,b=vec(x),vec(y);h,g=half(a),half(b)
        if h!=g:return -1 if h<g else 1
        c=cross(a,b);return -1 if c>0 else 1 if c<0 else 0
    labels=sorted([x for i in range(1,7) for x in (i,-i)],key=cmp_to_key(cmp))
    positions=[labels.index(i) for i in range(1,7)];d=[(b-a)%12 for a,b in zip(positions,positions[1:])]
    assert all(x not in (0,6) for x in d);d=[x if x<6 else x-12 for x in d]
    runs=[]
    for x in d:
        if not runs or x*runs[-1][0]<0:runs.append([x,abs(x)])
        else:runs[-1][1]+=abs(x)
    return len(runs)-1+2*sum(q//6 for _,q in runs)

out=[];n=int(sys.argv[1]) if len(sys.argv)>1 else 100000
for sample in range(n):
    v=[[rng.randrange(-100,101),rng.randrange(-100,101),1] for _ in range(7)]
    if det(*v[4:7])<0:
        for a in v:a[1]*=-1
    if det(*v[4:7])==0:continue
    rho=cyclic_rank(v)
    if rho not in (2,4,6):continue
    p={I:det(*(v[i] for i in I)) for I in trips}
    if not all(p.values()) or p[0,1,2]<=0 or all(x>0 for x in p.values()):continue
    def m(a,b,c):return p[tuple(sorted((a-1,b-1,c-1)))]
    feat=[m(a,b,6)*m(c,d,7)-m(a,b,7)*m(c,d,6) for a,b,c,d in F]
    feat += [m(1,2,5)*m(3,4,j)-m(1,2,j)*m(3,4,5) for j in (6,7)]
    if not all(feat):continue
    vals=list(p.values())+feat;key=sum(1<<i for i,x in enumerate(vals) if x>0)
    out.append({'key':key,'columns':v,'projected_rank':rho})
print('PASS',n,'samples;',len(out),'generic target-positive rank-two-projection candidates')
(root/'graph_rank_gap_candidates.json').write_text(json.dumps(out,indent=1)+'\n')
(root/'graph_rank_gap_keys.txt').write_text(''.join(str(z['key'])+' '+str(z['projected_rank'])+'\n' for z in out))
