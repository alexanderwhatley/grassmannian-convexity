#!/usr/bin/env python3
"""Prove no two active tracked sign events are identically tied.

For each move and pair of active sign polynomials, a single exact integer
matrix with nonzero affine slopes and nonzero root resultant proves that the
resultant is not the zero polynomial.  Thus its vanishing can be avoided by
generic perturbation.  Affineness is separately proved symbolically.
"""
from itertools import combinations
from pathlib import Path
from random import Random
import json

root=Path(__file__).resolve().parent.parent
P=list(combinations(range(1,8),3))
F4=[(1,2,3,4),(1,3,2,4),(1,4,2,3),(1,2,3,5),(1,3,2,5),
    (1,5,2,3),(1,2,4,5),(1,4,2,5),(1,5,2,4),(1,3,4,5),
    (1,4,3,5),(1,5,3,4),(2,3,4,5),(2,4,3,5),(2,5,3,4)]
def det(a,b,c):
 return (a[0]*b[1]*c[2]+a[1]*b[2]*c[0]+a[2]*b[0]*c[1]
         -a[2]*b[1]*c[0]-a[1]*b[0]*c[2]-a[0]*b[2]*c[1])
def values(V):
 def p(a,b,c):return det(V[a-1],V[b-1],V[c-1])
 vals=[p(*I) for I in P]
 vals += [p(a,b,6)*p(c,d,7)-p(a,b,7)*p(c,d,6) for a,b,c,d in F4]
 vals += [p(1,2,5)*p(3,4,6)-p(1,2,6)*p(3,4,5),
          p(1,2,5)*p(3,4,7)-p(1,2,7)*p(3,4,5)]
 return vals
active={j:set() for j in range(1,7)}
for line in (root/'event_table.txt').read_text().splitlines():
 j,bit,a,b,sg=map(int,line.split())
 if bit<50:active[j].add(bit)
for bit,j in [(50,2),(50,4),(50,6),(51,2),(51,4),(51,5)]:active[j].add(bit)
unresolved={(j,a,b) for j in active for a,b in combinations(sorted(active[j]),2)}
allpairs=len(unresolved);r=Random(371156);witness={}
for trial in range(100):
 V=[tuple(r.randint(-12,12) for _ in range(3)) for _ in range(7)]
 f=values(V);slopes={}
 if trial==0:
  assert all(f), 'the common witness must have all 52 features nonzero'
 for j in range(1,7):
  W=V[:];W[j-1]=tuple(a+b for a,b in zip(V[j-1],V[j]))
  g=values(W);slopes[j]=[b-a for a,b in zip(f,g)]
 found=[]
 for j,a,b in unresolved:
  da,db=slopes[j][a],slopes[j][b]
  if da and db and f[a]*db-f[b]*da:
   found.append((j,a,b));witness[(j,a,b)]=trial
 unresolved.difference_update(found)
 if not unresolved:break
assert not unresolved,sorted(unresolved)
out={'seed':371156,'samples_used':trial+1,'pairs':allpairs,
     'witness_sample_for_pair':[[*k,witness[k]] for k in sorted(witness)]}
(Path(__file__).with_name('g_tie_witnesses.json')).write_text(json.dumps(out,indent=2)+'\n')
print('PASS',allpairs,'active event pairs have an exact nonzero resultant witness; samples',trial+1)
