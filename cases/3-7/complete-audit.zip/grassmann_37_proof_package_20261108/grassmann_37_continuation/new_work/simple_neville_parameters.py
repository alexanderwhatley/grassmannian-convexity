#!/usr/bin/env python3
"""Simplify a rational witness one parameter at a time, exactly.

When one shear parameter varies and all others are fixed, every target
minor at a sampled vertex is affine in that parameter. Its desired sign
therefore cuts out an open interval. We choose a simple rational inside the
intersection and verify all maximal minors after each accepted change.
"""
from fractions import Fraction as Q
from itertools import combinations
from pathlib import Path
from random import Random
import json

root=Path(__file__).resolve().parent
candidate_seed=root/'neville_lower12_simple_rationals.json'
if not candidate_seed.exists():candidate_seed=root/'neville_lower12_decimal.json'
z=json.loads(candidate_seed.read_text())
initial=z['initial_columns']
moves=[(j,Q(t)) for j,t in z['moves']]
triples=list(combinations(range(7),3))

def det(a,b,c):
    return a[0]*(b[1]*c[2]-b[2]*c[1])-a[1]*(b[0]*c[2]-b[2]*c[0])+a[2]*(b[0]*c[1]-b[1]*c[0])

def trajectory(word, strict=False):
    v=[[Q(x) for x in c] for c in initial]
    result=[det(*v[:3])]
    for j,t in word:
        v[j-1]=[a+t*b for a,b in zip(v[j-1],v[j])]
        result.append(det(*v[:3]))
        if strict and any(not det(*(v[k] for k in I)) for I in triples):return None
    return result

target=trajectory(moves,True)
assert target and all(target)
signs=[1 if q>0 else -1 for q in target]
flips=[i for i in range(1,len(signs)) if signs[i]!=signs[i-1]]
assert len(flips)==12
rng=Random(3737)
for iteration in range(16):
    order=list(range(len(moves)));rng.shuffle(order);changed=0
    for i in order:
        j,old=moves[i]
        w=moves[:];w[i]=(j,Q(0));a=trajectory(w)
        w[i]=(j,Q(1));z=trajectory(w)
        low=Q(0);high=None
        for s in range(i+1,len(a)):
            c=signs[s]*a[s];d=signs[s]*(z[s]-a[s])
            if d>0:low=max(low,-c/d)
            elif d<0:high=min(high,-c/d) if high is not None else -c/d
            else:assert c>0
        assert low<old and (high is None or old<high)
        if high is None:
            candidate=Q(low.numerator//low.denominator+1)
        else:
            middle=(low+high)/2;candidate=old
            for q in (1,2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,
                      16384,32768,65536,131072,262144,524288,1048576,
                      2097152,4194304,8388608,16777216,33554432,67108864,
                      134217728,268435456,536870912,1073741824):
                trial=middle.limit_denominator(q)
                if low<trial<high:
                    candidate=trial;break
        if (candidate.numerator.bit_length()+candidate.denominator.bit_length()
                >= old.numerator.bit_length()+old.denominator.bit_length()):continue
        trial=moves[:];trial[i]=(j,candidate)
        v=trajectory(trial,True)
        if v and all((x>0)==(s>0) for x,s in zip(v,signs)):
            moves=trial;changed+=1
    print('pass',iteration+1,'simplified',changed,'max denominator',max(t.denominator for j,t in moves),flush=True)
    if not changed:break

assert trajectory(moves,True) and len(flips)==12
destination=root/'neville_lower12_simple_rationals.json'
destination.write_text(json.dumps({'initial_columns':initial,
    'moves':[[j,str(t)] for j,t in moves], 'crossings':flips,
    'method':'Coordinatewise exact interval rationalization; all maximal minors strict'},indent=2)+'\n')
print('PASS',len(moves),'positive rational moves; exact 12 target changes',flips)
