// Test whether saturated-chain sign variation can exceed graph H on exact samples.
#define main gc37_original_unused_main
#include "../rebuild_full_graph.cpp"
#undef main
#include "../history_20261108/g_features.hpp"
int main(){
 init();GFeatures G;auto dirs=direction_types(true);auto masks=sign_masks();
 Hash lookup(1ull<<25);uint32_t n=0;
 for(auto&w:dirs)for(auto&z:add_axes(w)){uint64_t base=word_key(z);for(auto m:masks)lookup.insert(base^m,n++);}assert(n==16051200);
 vector<uint8_t>rank(4ull*n);ifstream in("augmented_optimal_rank.bin",ios::binary);assert(in);
 in.read((char*)rank.data(),rank.size());assert(in.gcount()==int64_t(rank.size()));
 vector<int>order(35);iota(order.begin(),order.end(),0);
 sort(order.begin(),order.end(),[](int a,int b){auto x=ps[a],y=ps[b];return x[0]+x[1]+x[2]>y[0]+y[1]+y[2];});
 vector<vector<int>>next(35);
 for(int i=0;i<35;i++)for(int t=0;t<3;t++){
  auto a=ps[i];int j=a[t];if(j==7||find(a.begin(),a.end(),j+1)!=a.end())continue;
  a[t]++;sort(a.begin(),a.end());next[i].push_back(pid[a[0]][a[1]][a[2]]);
 }
 ifstream keys("graph_rank_gap_keys.txt");assert(keys);uint64_t key;int projected;size_t i=0,gaps=0;uint64_t table[13][13]{};
 while(keys>>key>>projected){uint64_t base=key&((1ull<<50)-1);int g=(key>>50)&3;uint32_t u=lookup.find(base);
  assert(u!=UINT32_MAX&&G.pass(base,g));int h=rank[4ull*u+g];assert(h<=12);
  int dp[35]={};for(int z:order)for(int v:next[z])dp[z]=max(dp[z],dp[v]+int(((base>>z)^(base>>v))&1));
  int V=dp[pid[1][2][3]];assert(V<=12);table[h][V]++;
  if(V>h){if(gaps<12)cout<<"GAP index="<<i<<" key="<<key<<" H="<<h<<" chain="<<V<<"\n";gaps++;}i++;
 }
 cout<<"PASS samples="<<i<<" chain_exceeds_H="<<gaps<<"\n";
 for(int h=0;h<=12;h++)for(int v=0;v<=12;v++)if(table[h][v])cout<<"H="<<h<<" V="<<v<<" count="<<table[h][v]<<"\n";
}
