# A canonical two-unit reduction of a parity-compatible graph rank

This is a general finite-graph lemma suggested by the (3,7) certificate.
It is independent of whether graph states are realizable by matrices.

Let every directed edge \(u\to v\) have weight \(w\in\{0,1\}\), and
let \(\pi\colon S\to\{0,1\}\) satisfy
\(\pi(u)-\pi(v)\equiv w\pmod2\). Suppose
\(F\colon S\to\mathbb Z_{\ge0}\) has the same parity as \(\pi\) and
\(F(u)\ge F(v)+w\) on every edge. Call an edge *tight* if equality holds.
Set
\[
C_F=\{u:\text{there is no directed tight path from }u
 \text{ to any state of }F\le1\}.
\]
Zero-length paths are allowed in this definition.

Then \(F-2\mathbf1_{C_F}\) is again a nonnegative parity-compatible
prerank. Indeed, \(C_F\) avoids \(F\le1\) and is forward closed under
tight edges. At an edge leaving \(C_F\), the old slack is positive; the
parity condition makes that slack even, so it is at least two. At all
other edges the prerank inequality is immediate. Moreover, \(C_F\) is the
largest forward-tight-closed set disjoint from \(\{F\le1\}\).

There is also an exact interpretation in terms of optimal graph paths.
Let \(H(u)\) be the maximum total weight of a finite directed path
starting at \(u\). It exists because the graph is finite and \(F\) forbids
positive-weight cycles. Let
\[
H_\pi(u)=\min\{h\ge H(u):h\equiv\pi(u)\pmod2\}.
\]
Then \(H_\pi\) is the smallest nonnegative parity-compatible prerank,
and
\[
C_F=\{u:F(u)>H_\pi(u)\},\qquad
F-2\mathbf1_{C_F}=\max\{H_\pi,F-2\}.\tag{*}
\]

To prove the first claim, every prerank bounds the weight of every path,
so any parity-compatible prerank dominates \(H_\pi\). Conversely, rounding
\(H\) upward to the required parity preserves every edge inequality,
because the parity change across an edge is exactly its weight.

If an \(F\)-tight path starting at \(u\) ends with \(F\le1\), its weight
is at least \(F(u)-1\); after rounding to \(\pi(u)\), this forces
\(H_\pi(u)=F(u)\). Conversely, assume \(F(u)=H_\pi(u)\) and choose an
\(H\)-maximizing path. It may end at a state with \(H=0\); along the
path \(H\) decreases by each edge weight, so the parity-rounding
correction is constant and \(H_\pi\) is tight. Since \(F\ge H_\pi\)
and their initial values agree, every edge of this path is \(F\)-tight
and its endpoint has \(F=H_\pi\le1\). This proves (*).

Consequently, repeating the canonical reduction from \(F_0\) gives the
explicit sequence
\[
F_k=\max\{H_\pi,F_0-2k\}.
\]
It terminates at the exact optimal parity-compatible graph rank. For the
Grassmann sign graph, \(\pi\) is the indicator of \(p_{123}<0\), and the
first reduction already gives the sharp bound \(8+m\). The complete
optimal-rank computation and the precise iteration counts require their
separate finite checks; they are not assumed in the proof of the first
reduction.
