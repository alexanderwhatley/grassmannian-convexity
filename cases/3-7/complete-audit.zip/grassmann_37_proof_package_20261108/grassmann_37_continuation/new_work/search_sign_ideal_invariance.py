#!/usr/bin/env python3
"""Search for an exact counterexample to lower-ideal sign preservation."""
from fractions import Fraction
from itertools import combinations
from random import Random

random=Random(37137)
def det(A):
    A=[row[:] for row in A];n=len(A);sg=1;last=1
    for j in range(n-1):
        piv=next((i for i in range(j,n) if A[i][j]),None)
        if piv is None:return 0
        if piv!=j:A[piv],A[j]=A[j],A[piv];sg=-sg
        p=A[j][j]
        for i in range(j+1,n):
            for h in range(j+1,n):A[i][h]=(A[i][h]*p-A[i][j]*A[j][h])//last
        for i in range(j+1,n):A[i][j]=0
        last=p
    return sg*A[-1][-1]

samples=admitted=0
for n in range(3,9):
    for k in range(1,n):
        states=list(combinations(range(n),k))
        edges=[]
        for I in states:
            for pos,j in enumerate(I):
                if j+1<n and j+1 not in I:
                    J=I[:pos]+(j+1,)+I[pos+1:]
                    edges.append((I,J))
        for trial in range(3000):
            M=[[random.randint(-9,9) for j in range(n)] for i in range(k)]
            p={I:det([[M[i][j] for j in I] for i in range(k)]) for I in states}
            if not all(p.values()):continue
            if p[states[-1]]<0:p={I:-q for I,q in p.items()}
            if p[states[0]]>0 or any(p[I]>0>p[J] for I,J in edges):continue
            admitted+=1
            for j in range(n-1):
                slope={I:(p[tuple(sorted((set(I)-{j})|{j+1}))] if j in I and j+1 not in I else 0) for I in states}
                roots=sorted(set(Fraction(-p[I],slope[I]) for I in states if slope[I] and Fraction(-p[I],slope[I])>0))
                tests=[Fraction(1)]+[(a+b)/2 for a,b in zip([Fraction(0)]+roots,roots)]+([roots[-1]+1] if roots else [])
                for t in tests:
                    q={I:p[I]+t*slope[I] for I in states}
                    if all(q.values()) and any(q[I]>0>q[J] for I,J in edges):
                        print('COUNTEREXAMPLE n,k,trial,move,time:',n,k,trial,j+1,t)
                        print('matrix:',M)
                        print('sign inversion:',next((I,J) for I,J in edges if q[I]>0>q[J]))
                        raise SystemExit(1)
            samples+=1
        print('PASS',k,n,'sign-ideal states tested',admitted,flush=True)
print('PASS',samples,'generic negative-target sign-ideal matrices and every move interval')
