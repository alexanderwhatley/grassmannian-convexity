#!/usr/bin/env python3
"""Exploratory smooth control search on a real unresolved rank-four state.

Positive scalar coordinates let every move be represented as convex corner
cutting. The objective and gradient are evaluated in double precision. Any
candidate is accepted only after a separate exact Fraction replay of all 35
maximal minors; failure to find one proves nothing.
"""
from fractions import Fraction as Q
from itertools import combinations
from pathlib import Path
from random import Random
import json,math,os
import numpy as np
from scipy.optimize import minimize
from scipy.special import expit

root=Path(__file__).resolve().parent
columns=[[-79,-53,1],[-18,-70,1],[22,36,1],[-8,62,1],[51,-99,1],[86,-24,1],[89,38,1]]
P0=np.array([p[:2] for p in columns],dtype=float);scale=40000.
margin=float(os.environ.get('GC37_MARGIN','0.001'))
def cross(a,b):return a[0]*b[1]-a[1]*b[0]
def value_and_grad(x,word):
    P=P0.copy();D=np.zeros((7,2,len(word)));samples=[];derivs=[]
    for t,(j,s) in enumerate(zip(word,expit(x))):
        q=j-1;old=P[q].copy();oldgrad=D[q].copy()
        P[q]=(1-s)*old+s*P[q+1]
        D[q]=(1-s)*oldgrad+s*D[q+1]
        D[q,:,t]+=(P[q+1]-old)*s*(1-s)
        if j==3:
            a=P[1]-P[0];b=P[2]-P[0]
            da=D[1]-D[0];db=D[2]-D[0]
            value=cross(a,b)/scale
            grad=(da[0]*b[1]-da[1]*b[0]+a[0]*db[1]-a[1]*db[0])/scale
            samples.append(value);derivs.append(grad)
    assert len(samples)==4
    signs=np.array([-1.,1.,-1.,1.]);gaps=np.maximum(margin-signs*np.array(samples),0)
    loss=10000*np.dot(gaps,gaps)
    grad=-20000*np.sum((gaps*signs)[:,None]*np.array(derivs),axis=0)
    return loss,grad
def det(a,b,c):return a[0]*(b[1]*c[2]-b[2]*c[1])-a[1]*(b[0]*c[2]-b[2]*c[0])+a[2]*(b[0]*c[1]-b[1]*c[0])
def exact_replay(word,ss):
    v=[[Q(x) for x in c] for c in columns];scale=[Q(1)]*7
    triples=list(combinations(range(7),3));old=det(*v[:3]);flips=[];moves=[]
    for step,(j,s) in enumerate(zip(word,ss),1):
        if not 0<s<1:return None
        q=j-1;t=s/(1-s)*scale[q]/scale[q+1]
        v[q]=[a+t*b for a,b in zip(v[q],v[q+1])];scale[q]/=(1-s)
        vals=[det(*(v[i] for i in I)) for I in triples]
        if not all(vals):return None
        if (old>0)!=(vals[0]>0):flips.append(step)
        old=vals[0];moves.append([j,str(t)])
    return (moves,flips) if len(flips)==4 else None

rng=Random(37444);best=1e99
for trial in range(2500):
    separators=[rng.choice([2,4]) for _ in range(3)]
    word=[4,3]
    for j in separators:word.extend([j,3])
    for _ in range(rng.randint(5,12)):
        word.insert(rng.randrange(len(word)+1),rng.choice([1,2,4,5,6]))
    initial=np.array([rng.uniform(-7,7) for _ in word]);
    q=minimize(value_and_grad,initial,args=(word,),jac=True,method='L-BFGS-B',
               bounds=[(-16,16)]*len(word),options={'maxiter':500,'ftol':1e-15,'gtol':1e-10})
    if q.fun<best:
        best=q.fun;print('trial',trial,'best',best,'word',word,flush=True)
    if q.fun<1e-15:
        for d in (10**6,10**9,10**12):
            ss=[Q(round(float(a)*d),d) for a in expit(q.x)]
            result=exact_replay(word,ss)
            if result:
                moves,flips=result
                out={'initial_columns':columns,'moves':moves,'flips':flips,'method':'numerical search, exact rational replay'}
                (root/'residual_four_flip_search.json').write_text(json.dumps(out,indent=2)+'\n')
                print('PASS exact 4-flip trajectory',len(moves),'moves',flips,flush=True)
                raise SystemExit(0)
print('No solution found in finite numerical search; no impossibility conclusion')
