// Find real sampled H=4 states unresolved by pencil and dominance bounds.
#define main gc37_original_unused_main
#include "../rebuild_full_graph.cpp"
#undef main
#include "../history_20261108/g_features.hpp"
int main(){
 init();GFeatures G;auto dirs=direction_types(true);auto masks=sign_masks();
 Hash lookup(1ull<<25);uint32_t n=0;
 for(auto&w:dirs)for(auto&z:add_axes(w)){uint64_t base=word_key(z);for(auto m:masks)lookup.insert(base^m,n++);}assert(n==16051200);
 vector<uint8_t>rank(4ull*n);ifstream in("augmented_optimal_rank.bin",ios::binary);assert(in);
 in.read((char*)rank.data(),rank.size());assert(in.gcount()==int64_t(rank.size()));
 vector<pair<int,int>>covers;for(int i=0;i<35;i++)for(int q=0;q<3;q++){
  auto x=ps[i];int j=x[q];if(j==7||find(x.begin(),x.end(),j+1)!=x.end())continue;
  x[q]++;sort(x.begin(),x.end());covers.emplace_back(i,pid[x[0]][x[1]][x[2]]);
 }
 vector<array<int,5>>pencils;for(int a=1;a<=7;a++)for(int b=a+1;b<=7;b++){
  array<int,5>p;int z=0;for(int i=1;i<=7;i++)if(i!=a&&i!=b){array<int,3>x={a,b,i};sort(x.begin(),x.end());p[z++]=pid[x[0]][x[1]][x[2]];}pencils.push_back(p);
 }
 uint64_t candidates[35][35]{};array<int,7>permutation={1,2,3,4,5,6,7};
 do{
  int weight[8]{};for(int p=0;p<7;p++)weight[permutation[p]]=1<<p;
  int score[35]{};for(int a=0;a<35;a++)for(int i:ps[a])score[a]+=weight[i];
  int dom[35];for(int t=0;t<35;t++){
   int best=-1;for(int a=0;a<35;a++)if(ps[a][0]>=ps[t][0]&&ps[a][1]>=ps[t][1]&&ps[a][2]>=ps[t][2]&&(best<0||score[a]>score[best]))best=a;
   assert(best>=0);dom[t]=best;
  }
  int top=dom[pid[1][2][3]];for(auto[a,b]:covers){int x=dom[a],y=dom[b];if(x!=y&&x!=top)candidates[x][y]|=1ull<<top;}
 }while(next_permutation(permutation.begin(),permutation.end()));
 vector<tuple<int,int,uint64_t>>tests;for(int a=0;a<35;a++)for(int b=0;b<35;b++)if(candidates[a][b])tests.emplace_back(a,b,candidates[a][b]);
 ifstream keys("graph_rank_gap_keys.txt");assert(keys);uint64_t key;int projected;size_t index=0,residual=0,pencil2=0;uint64_t mask=(1ull<<35)-1;
 while(keys>>key>>projected){uint64_t base=key&((1ull<<50)-1);int g=(key>>50)&3;uint32_t u=lookup.find(base);assert(u!=UINT32_MAX&&G.pass(base,g));
  int h=rank[4ull*u+g];if(h==4){uint64_t pos=base&mask,neg=(~pos)&mask;int lb=0;
   for(auto p:pencils){int prev=1,v=0;for(int x:p){int z=(pos>>x&1)?1:-1;v+=z!=prev;prev=z;}v+=prev!=1;lb=max(lb,v);}
   if(lb==2){pencil2++;bool yes=false;for(auto[a,b,top]:tests)if((pos>>a&1)&&(neg>>b&1)&&(neg&top)){yes=true;break;}
    if(!yes){if(residual<25)cout<<"RESIDUAL index="<<index<<" key="<<key<<" H="<<h<<" P="<<lb<<" projected="<<projected<<"\n";residual++;}
   }
  }index++;
 }
 cout<<"PASS "<<index<<" samples; H4/P2="<<pencil2<<" unresolved="<<residual<<"\n";
}
