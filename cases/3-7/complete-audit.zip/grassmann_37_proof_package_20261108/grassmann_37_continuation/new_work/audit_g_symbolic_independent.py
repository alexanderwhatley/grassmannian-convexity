#!/usr/bin/env python3
"""Independent symbolic audit of the two new G polynomials.

Uses full determinant substitutions and exact polynomial identities, rather
than differentiating the implementation's event table.
"""
import sympy as s
X=s.symbols('x0:21');t=s.Symbol('t')
V=[None]+[s.Matrix(X[3*i:3*i+3]) for i in range(7)]
def p(V,a,b,c):return s.det(s.Matrix.hstack(V[a],V[b],V[c]))
def F(V,a,b,c,d,e,f):
 return p(V,a,b,e)*p(V,c,d,f)-p(V,a,b,f)*p(V,c,d,e)
G56=F(V,1,2,3,4,5,6);G57=F(V,1,2,3,4,5,7);F67=F(V,1,2,3,4,6,7)
checks=0
for name,(a,b,c,d,e,f),G in [('G56',(1,2,3,4,5,6),G56),('G57',(1,2,3,4,5,7),G57)]:
 rot1=F(V,c,d,e,f,a,b);rot2=F(V,e,f,a,b,c,d)
 assert s.expand(rot1-G)==0,(name,'rotation1')
 assert s.expand(rot2-G)==0,(name,'rotation2')
 checks+=2
 expected={2:p(V,1,3,4)*p(V,3,5,f),4:p(V,1,2,5)*p(V,3,5,f)}
 if name=='G56':expected[6]=G57
 else:expected[5]=F67
 for j in range(1,7):
  W=V[:];W[j]=V[j]+t*V[j+1]
  actual=s.Poly(s.expand(F(W,a,b,c,d,e,f)-G),t)
  assert actual.degree()<=1,(name,j,actual.degree())
  assert s.expand(actual.as_expr()-t*expected.get(j,0))==0,(name,j)
  checks+=1
print('PASS',checks,'full-substitution identities: 4 cyclic expressions and 12 affine move laws')
