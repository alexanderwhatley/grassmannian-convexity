// Analyze the canonical two-unit rank reduction against the graph-optimal
// rank. This is a finite sign-graph diagnostic, not a realization claim.
#define main gc37_original_unused_main
#include "../rebuild_full_graph.cpp"
#undef main
#include "../history_20261108/g_features.hpp"
int main(){
 init();GFeatures G;auto dirs=direction_types(true);auto masks=sign_masks();const int n=16051200;
 vector<uint8_t>rank(n),K(n/2),bad(n/2),H(4ull*n);
 auto read=[](string name,vector<uint8_t>&v){ifstream f(name,ios::binary);assert(f);f.read((char*)v.data(),v.size());assert(f.gcount()==int64_t(v.size()));};
 read("../filtered_rank.bin",rank);read("../history_20261108/g_reachable_50_nohalf.bin",K);
 read("../../m1_analytic_20261108/tight_to_rank01.bin",bad);read("augmented_optimal_rank.bin",H);
 auto in=[](const vector<uint8_t>&v,uint32_t c){return bool(v[c/8]&(1u<<(c%8)));};
 auto mv=[&](uint64_t key){int best=0;
  for(int a=1;a<=7;a++)for(int b=a+1;b<=7;b++){int prev=0,var=0;
   for(int i=1;i<=7;i++)if(i!=a&&i!=b){array<int,3>I={a,b,i};sort(I.begin(),I.end());
    int s=(key>>pid[I[0]][I[1]][I[2]]&1)?1:-1;if(i&1)s=-s;if(prev&&s!=prev)var++;prev=s;}
   best=max(best,var);
  }return 4-best;
 };
 uint64_t states=0,inC=0,improved=0,parity_mismatch=0,zero_negative=0;
 uint64_t Cdist[5][2]{},distance[8]{},Hdist[13][2]{},slack[14]{};uint32_t idx=0;
 for(auto&w:dirs)for(auto&z:add_axes(w)){uint64_t base=word_key(z);for(auto mask:masks){
  uint64_t key=base^mask;int m=mv(key),eps=!(key&1);assert(m>=0&&m<=4);
  for(int g=0;g<4;g++)if(G.pass(key,g)){
   uint32_t code=4*idx+g;int r=rank[idx],h=H[code];assert(h<=12&&r>=h);
   int hp=h+((eps-h)&1),d=(r-hp)/2;assert(r>=hp&&!(r-hp&1)&&d>=0&&d<8);
   bool c=!in(bad,code);assert(c==(r>hp));int canonical=r-2*int(c);
   int p=r-2*int(in(K,code)),q=p-2*int(p>8+m);
   assert(canonical<=q&&canonical<=8+m&&canonical>=h);
   states++;inC+=c;improved+=canonical<q;Cdist[m][eps]+=c;distance[d]++;Hdist[h][eps]++;
   parity_mismatch+=((h-eps)&1)!=0;zero_negative+=(h==0&&eps==1);slack[canonical-h]++;
  }
  idx++;
 }}
 assert(idx==uint32_t(n)&&states==23246848&&inC==10855286);
 cout<<"PASS C={R>H_parity} on all "<<states<<" augmented states; C="<<inC<<" canonical improves Q="<<improved<<"\n";
 cout<<"distance (R-H_parity)/2:";for(int i=0;i<8;i++)if(distance[i])cout<<' '<<i<<':'<<distance[i];cout<<'\n';
 cout<<"H parity mismatches="<<parity_mismatch<<"; H=0 and target-negative="<<zero_negative<<"\n";
 for(int m=0;m<=4;m++)cout<<"C m="<<m<<" target plus="<<Cdist[m][0]<<" minus="<<Cdist[m][1]<<'\n';
 cout<<"canonical minus H:";for(int i=0;i<14;i++)if(slack[i])cout<<' '<<i<<':'<<slack[i];cout<<'\n';
 for(int i=0;i<=12;i++)if(Hdist[i][0]||Hdist[i][1])cout<<"H="<<i<<" target plus="<<Hdist[i][0]<<" minus="<<Hdist[i][1]<<'\n';
}
