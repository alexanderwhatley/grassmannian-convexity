#!/usr/bin/env python3
"""Overapproximate two U5 moves using only signs of the first five columns.

The four minors on columns 1..4 are preserved by U5. Between U5 moves,
3x5 Pluecker-sign transitions overapproximate real trajectories; a U5 move
is relaxed to any state change preserving those four signs.
"""
import contextlib,io,runpy
from itertools import combinations
from pathlib import Path

with contextlib.redirect_stdout(io.StringIO()):
    z=runpy.run_path(str(Path(__file__).with_name('small_3_5_sign_graph.py')))
P=z['P'];idx=z['idx'];norm=z['states'];mask=(1<<10)-1
states=norm+[s^mask for s in norm];S=set(states);assert len(states)==384
arcs={a:[] for a in states}
for a in states:
    for j in range(1,5):
        for i,I in enumerate(P):
            if j in I and j+1 not in I:
                J=tuple(sorted((set(I)-{j})|{j+1}));d=(a>>idx[J])&1;s=(a>>i)&1
                b=a^(1<<i)
                if s!=d and b in S:arcs[a].append((b,int(I==(1,2,3)),j))
fixed=[idx[I] for I in combinations(range(1,5),3)]
groups={}
for a in states:groups.setdefault(tuple(a>>i&1 for i in fixed),[]).append(a)
def closure(scores):
    scores=scores.copy()
    for turn in range(len(states)+1):
        changed=False
        for a in states:
            if scores[a]<0:continue
            for b,w,j in arcs[a]:
                if scores[b]<scores[a]+w:scores[b]=scores[a]+w;changed=True
        if not changed:return scores
    raise AssertionError('unexpected positive cycle')
def jump(scores):
    out={a:-1000 for a in states}
    for group in groups.values():
        best=max(scores[a] for a in group)
        for b in group:out[b]=best
    return out
alternating=sum(((-1)**sum(I)>0)<<i for i,I in enumerate(P))
assert alternating in S
scores={a:-1000 for a in states};scores[alternating]=0
for count in range(3):
    scores=closure(scores)
    print('allowed U5',count,'max all states',max(scores.values()),'ending all-positive',scores[mask])
    if count<2:scores=jump(scores)

def closure_one_j1(scores):
    scores=scores.copy()
    for turn in range(3*len(states)+1):
        changed=False
        for a in states:
            for mode in range(3):
                q=scores[a,mode]
                if q<0:continue
                if mode<2 and scores[a,2]<q:scores[a,2]=q;changed=True
                for b,w,j in arcs[a]:
                    if j==1:
                        if mode==2:continue
                        dest=1
                    else:
                        if mode==1:continue
                        dest=mode
                    if scores[b,dest]<q+w:scores[b,dest]=q+w;changed=True
        if not changed:return scores
    raise AssertionError('unexpected positive cycle')
def jump_one_j1(scores):
    out={(a,mode):-1000 for a in states for mode in range(3)}
    for group in groups.values():
        for mode in (0,2):
            best=max(scores[a,mode] for a in group)
            for b in group:out[b,mode]=best
    return out
scores={(a,mode):-1000 for a in states for mode in range(3)};scores[alternating,0]=0
maxima=[]
for count in range(3):
    scores=closure_one_j1(scores)
    maxima.append(max(scores.values()))
    print('allowed U5',count,'and one U1 run: max all states',max(scores.values()),
          'ending all-positive',max(scores[mask,mode] for mode in range(3)))
    if count<2:scores=jump_one_j1(scores)
assert maxima==[6,8,10],maxima
print('PASS overapproximating five-sign automaton: at most 10 target changes with two U5 moves and one U1 run')
