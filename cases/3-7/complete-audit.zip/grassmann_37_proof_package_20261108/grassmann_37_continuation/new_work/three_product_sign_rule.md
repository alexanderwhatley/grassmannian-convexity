# A three-product sign obstruction

For a generic real \(3\times7\) matrix, put
\(G_{56}=p_{125}p_{346}-p_{126}p_{345}\). The following implication is
an elementary necessary condition on its signs:
\[
\begin{gathered}
\operatorname{sgn}(p_{123}p_{145})
 =\operatorname{sgn}(p_{125}p_{134}),\\
\operatorname{sgn}(p_{135}p_{456})
 =\operatorname{sgn}(p_{156}p_{345})
\end{gathered}
\quad\Longrightarrow\quad
\operatorname{sgn}G_{56}=\operatorname{sgn}(p_{124}p_{356}).\tag{1}
\]

Indeed, the exact Plücker identities are
\[
\begin{aligned}
p_{124}p_{135}&=p_{123}p_{145}+p_{125}p_{134},\\
p_{145}p_{356}&=p_{135}p_{456}+p_{156}p_{345},\\
G_{56}&=p_{124}p_{356}-p_{123}p_{456}.
\end{aligned}\tag{2}
\]
The hypotheses imply that the magnitudes of the left sides of the first
two identities are strictly larger than the magnitudes of their first
summands. Multiplying and cancelling the nonzero factors
\(|p_{135}p_{145}|\) gives
\[
|p_{124}p_{356}|>|p_{123}p_{456}|.
\]
The final identity then gives (1). All three identities are independently
checked symbolically. Relabeling the six indices, cyclically exchanging
the three pairs, and reversing pair orientations give analogous rules
for any tracked six-index concurrency feature.

## What this explains in the finite graph

The exact optimal graph rank \(H\) has 25,519 accepted formal states with
\(H=0\), \(p_{123}<0\), and \(p_{567}>0\). None is realizable by a real
matrix: a sufficiently long positive exponential flow, approximated by
positive elementary moves, changes the target to positive; a generic
perturbation then yields at least one target edge, contradicting \(H=0\).
This argument uses the already verified graph coverage and graph rank.

Each of these 25,519 states passes all rank-three three-term sign axioms,
all simple cyclic forcing tests for the 15 old concurrency signs, and the
separate six-column product-order cycle tests. Nevertheless, an exhaustive
check finds that **every one violates an oriented form of (1)** applied to
\(G_{56}\) or \(G_{57}\). The G56 forms cover 14,785 states and the G57
forms cover 14,835, with overlap. `analyze_three_product_rules.cpp`
checks the 48 pair orientations for each tracked feature; its 816 tested
rules are all instances of (2), with their signs transformed under pair
permutations and reversals. The four numbers are properties of this
particular necessary-condition graph, not a count of real matrices.

As a separate exploratory check, linear programs using all strict
three-term Plücker magnitude comparisons and all cyclic feature-product
comparisons found the first 250 sampled traps infeasible. A rational dual
certificate was independently checked for the first sample. Numerical LP
output by itself is not a proof; the exhaustive rule-(1) check and the
identities in (2) are exact and do not depend on it.

The main 12-bound certificate does not use (1). It is a possible way to
strengthen a smaller sign model, not an assertion that the remaining
filtered states are all realizable or that a shorter proof already follows.
