#!/usr/bin/env python3
"""Exact replay of a 4-flip cascade whose graph upper rank falls to six."""
from fractions import Fraction as Q
from itertools import combinations
from pathlib import Path
import json

data=json.loads(Path('scalar_four_sample0.json').read_text())
v=[[Q(x) for x in a] for a in data['initial_columns']]
triples=list(combinations(range(1,8),3));pid={p:i for i,p in enumerate(triples)}
F=[(1,2,3,4),(1,3,2,4),(1,4,2,3),(1,2,3,5),(1,3,2,5),
 (1,5,2,3),(1,2,4,5),(1,4,2,5),(1,5,2,4),(1,3,4,5),
 (1,4,3,5),(1,5,3,4),(2,3,4,5),(2,4,3,5),(2,5,3,4)]
def det(a,b,c):return a[0]*(b[1]*c[2]-b[2]*c[1])-a[1]*(b[0]*c[2]-b[2]*c[0])+a[2]*(b[0]*c[1]-b[1]*c[0])
def evaluate():
 p={I:det(*(v[i-1] for i in I)) for I in triples};assert all(p.values())
 s={I:(1 if x>0 else -1) for I,x in p.items()}
 best=0
 for a,b in combinations(range(1,8),2):
  z=[s[tuple(sorted((a,b,i)))]*(-1 if i&1 else 1) for i in range(1,8) if i not in(a,b)]
  best=max(best,sum(x!=y for x,y in zip(z,z[1:])))
 vals=list(p.values())+[p[a,b,6]*p[c,d,7]-p[a,b,7]*p[c,d,6] for a,b,c,d in F]
 vals += [p[1,2,5]*p[3,4,6]-p[1,2,6]*p[3,4,5],p[1,2,5]*p[3,4,7]-p[1,2,7]*p[3,4,5]]
 assert all(vals)
 return s[1,2,3],4-best,sum((x>0)<<i for i,x in enumerate(vals))
old,m0,_=evaluate();assert m0==4;flips=0
assert [j for j,t in data['moves']]==[3,4,3,5,4,3,6,5,4,3]
for j,t in data['moves']:
 j-=1;t=Q(t);assert t>0;v[j]=[x+t*y for x,y in zip(v[j],v[j+1])]
 now,m,key=evaluate();flips+=now!=old;old=now
assert flips==4 and m==0 and key==data['endpoint_key']==3505885989027871
Path('scalar_four_keys.txt').write_text(f'{key} 6\n')
print('PASS exact 10-move cascade: initial m=4, final m=0, 4 target flips, all 52 vertex features strict')
print('PASS endpoint 52-sign key',key,'ready for independent H lookup')
