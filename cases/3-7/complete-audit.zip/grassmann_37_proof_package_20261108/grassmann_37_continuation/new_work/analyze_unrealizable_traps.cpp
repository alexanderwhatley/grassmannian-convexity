// Inspect formal sign states with p123<0 but optimal future target rank 0.
// Such states cannot be real: a positive long-time flow ends with p123>0.
// This program asks how many fail elementary necessary sign identities.
#define main gc37_original_unused_main
#include "../rebuild_full_graph.cpp"
#undef main
#include "../history_20261108/g_features.hpp"
int main(){
 init();GFeatures G;auto dirs=direction_types(true);auto masks=sign_masks();const int n=16051200;
 vector<uint8_t>H(4ull*n);ifstream f("augmented_optimal_rank.bin",ios::binary);assert(f);
 f.read((char*)H.data(),H.size());assert(f.gcount()==int64_t(H.size()));
 auto s=[](uint64_t k,int bit){return (k>>bit&1)?1:-1;};
 auto p=[&](uint64_t k,int a,int b,int c){int inv=(a>b)+(a>c)+(b>c);array<int,3>x={a,b,c};sort(x.begin(),x.end());return (inv&1?-1:1)*s(k,pid[x[0]][x[1]][x[2]]);};
 uint64_t total=0,gpbad=0,cycbad=0,either=0,neither=0,orderbad=0,ordergood=0;uint32_t idx=0;int shown=0;
 ofstream trapkeys("unrealizable_trap_keys.txt");assert(trapkeys);
 auto order_failure=[&](uint64_t key,int g){
  struct Feature{array<pair<int,int>,3> pairs;int sign;};vector<Feature>fs;
  for(int i=0;i<15;i++){auto x=flab[i];Feature f;f.pairs={make_pair(x[0],x[1]),make_pair(x[2],x[3]),make_pair(6,7)};f.sign=s(key,35+i);fs.push_back(f);}
  Feature f1;f1.pairs={make_pair(1,2),make_pair(3,4),make_pair(5,6)};f1.sign=(g&1)?1:-1;fs.push_back(f1);
  Feature f2;f2.pairs={make_pair(1,2),make_pair(3,4),make_pair(5,7)};f2.sign=(g&2)?1:-1;fs.push_back(f2);
  for(int omitted=1;omitted<=7;omitted++){
   int full=0;for(int i=1;i<=7;i++)if(i!=omitted)full|=1<<i;
   int id[256];fill(id,id+256,-1);int n=0;
   for(int x=0;x<256;x++)if((x&~full)==0&&__builtin_popcount(unsigned(x))==3&&x<(full^x))id[x]=n++;
   assert(n==10);uint16_t order[10]{};
   for(auto F:fs){int used=0;for(auto [a,b]:F.pairs)used|=(1<<a)|(1<<b);if(used!=full)continue;
    for(int r=0;r<3;r++){
     auto[a,b]=F.pairs[r];auto[c,d]=F.pairs[(r+1)%3];auto[e,f]=F.pairs[(r+2)%3];
     int x=p(key,a,b,e)*p(key,c,d,f),y=p(key,a,b,f)*p(key,c,d,e);
     if(x!=y){if(x!=F.sign)return true;continue;}
     int left=(1<<a)|(1<<b)|(1<<e),right=(1<<a)|(1<<b)|(1<<f);
     int A=id[min(left,full^left)],B=id[min(right,full^right)];assert(A>=0&&B>=0&&A!=B);
     if(F.sign==x)order[A]|=1u<<B;else order[B]|=1u<<A;
    }
   }
   for(int k=0;k<10;k++)for(int i=0;i<10;i++)if(order[i]&(1u<<k))order[i]|=order[k];
   for(int i=0;i<10;i++)if(order[i]&(1u<<i))return true;
  }
  return false;
 };
 uint64_t gp_types[105]{},cyc_types[45]{};
 for(auto&w:dirs)for(auto&z:add_axes(w)){uint64_t b=word_key(z);for(auto mask:masks){
  uint64_t k=b^mask;if(k&1){idx++;continue;}
  bool any=false;for(int g=0;g<4;g++)any|=G.pass(k,g)&&H[4ull*idx+g]==0;
  if(!any){idx++;continue;}
  bool gp=false,cyc=false;int gi=0,ci=0;
  for(int q=1;q<=7;q++)for(int a=1;a<=7;a++)for(int b=a+1;b<=7;b++)for(int c=b+1;c<=7;c++)for(int d=c+1;d<=7;d++){
   if(a==q||b==q||c==q||d==q)continue;
   int x=p(k,q,a,b)*p(k,q,c,d),y=-p(k,q,a,c)*p(k,q,b,d),z=p(k,q,a,d)*p(k,q,b,c);
   if(x==y&&y==z){gp=true;gp_types[gi]++;}gi++;
  }
  assert(gi==105);
  for(int i=0;i<15;i++){
   auto F=flab[i];array<pair<int,int>,3>pair={make_pair(F[0],F[1]),make_pair(F[2],F[3]),make_pair(6,7)};
   int want=s(k,35+i);
   for(int r=0;r<3;r++){
    auto[a,b]=pair[r];auto[c,d]=pair[(r+1)%3];auto[e,f]=pair[(r+2)%3];
    int x=p(k,a,b,e)*p(k,c,d,f),y=p(k,a,b,f)*p(k,c,d,e);
    if(x!=y&&x!=want){cyc=true;cyc_types[ci]++;}ci++;
   }
  }
  assert(ci==45);
  for(int g=0;g<4;g++)if(G.pass(k,g)&&H[4ull*idx+g]==0){
   total++;gpbad+=gp;cycbad+=cyc;either+=gp||cyc;neither+=!gp&&!cyc;
   bool ob=order_failure(k,g);orderbad+=ob;ordergood+=!ob;
   trapkeys<<(k|(uint64_t(g)<<50))<<'\n';
   if(!gp&&!cyc&&!ob&&shown++<5)cout<<"trap passes GP/cyclic/order: key="<<(k|(uint64_t(g)<<50))<<" base="<<idx<<" g="<<g<<'\n';
  }
  idx++;
 }}
 assert(idx==n&&total==25519);
 cout<<"PASS "<<total<<" formal p123-negative H=0 traps; rank3 GP failures="<<gpbad
     <<" old-F cyclic failures="<<cycbad<<" either="<<either<<" neither="<<neither<<'\n';
 cout<<"PASS six-column product-order cycles="<<orderbad<<"; pass all seven order tests="<<ordergood<<'\n';
}
