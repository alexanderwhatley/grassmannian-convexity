#!/usr/bin/env python3
"""Turn the 29-move rational witness into an all-integer one by scaling."""
from fractions import Fraction as Q
from pathlib import Path
import json

root=Path(__file__).resolve().parent
source=root.parent.parent/'trajectory_search_20261108/witness_29_simplified.json'
z=json.loads(source.read_text());lam=[8,8,8,4,4,4,4]
columns=[[Q(x)*a for x in col] for col,a in zip(z['initial_columns'],lam)]
assert all(x.denominator==1 for col in columns for x in col)
moves=[]
for j,s in z['moves']:
    t=Q(s)*lam[j-1]/lam[j];assert t.denominator==1 and t>0
    moves.append([j,int(t)])
out={'initial_columns':[[int(x) for x in col] for col in columns],
     'moves':moves,'crossings':12,
     'method':'Positive column scaling of the independently verified 29-move rational witness'}
destination=root/'witness_29_integer.json';destination.write_text(json.dumps(out,indent=2)+'\n')
print('PASS all-integer 3x7 start and',len(moves),'integer positive shear parameters')
print('initial columns:',out['initial_columns'])
print('moves:',moves)
