#!/usr/bin/env python3
"""Exact independent exterior-power replay of the 207-move example."""
from fractions import Fraction as Q
from itertools import combinations
from pathlib import Path
import json

data=json.loads(Path(__file__).with_name('neville_lower12.json').read_text())
columns=data['initial_columns']
def det(a,b,c):
    return (a[0]*b[1]*c[2]+a[1]*b[2]*c[0]+a[2]*b[0]*c[1]
            -a[2]*b[1]*c[0]-a[1]*b[0]*c[2]-a[0]*b[2]*c[1])
triples=list(combinations(range(7),3))
p={I:Q(det(*(columns[i] for i in I))) for I in triples}
assert all(p.values())
prev=(p[(0,1,2)]>0)-(p[(0,1,2)]<0)
flips=[];zero_vertices=[]
for number,(j,t) in enumerate(data['moves'],1):
    j-=1;t=Q(t);assert 0<=j<6 and t>0
    updated={}
    for I in triples:
        if j in I and j+1 not in I:
            J=tuple(sorted((set(I)-{j})|{j+1}))
            updated[I]=p[I]+t*p[J]
    p.update(updated)
    if not all(p.values()):zero_vertices.append(number)
    sign=(p[(0,1,2)]>0)-(p[(0,1,2)]<0)
    assert sign
    if sign!=prev:flips.append(number)
    prev=sign
assert len(flips)==data['crossings']==12
assert not zero_vertices,zero_vertices
print('PASS',len(data['moves']),'positive rational moves, all 35 minors strict at every vertex')
print('PASS 12 target changes at moves',flips)
