// Confirm Q monotonicity on independently generated exact-rational events.
// Run from this directory; this complements but does not replace the
// all-state/edge proof checker.
#define main gc37_graph_unused_main
#include "../rebuild_full_graph.cpp"
#undef main
#include "../history_20261108/g_features.hpp"

int main(){
 init();GFeatures G;auto dirs=direction_types(true);auto masks=sign_masks();
 Hash H(1ull<<25);vector<uint8_t>rank;uint32_t count=0;
 ifstream rf("../filtered_rank.bin",ios::binary);rank.assign(istreambuf_iterator<char>(rf),{});
 for(auto&w:dirs)for(auto&z:add_axes(w)){uint64_t b=word_key(z);for(auto m:masks)H.insert(b^m,count++);}
 assert(count==rank.size());
 ifstream cf("../history_20261108/g_reachable_50_nohalf.bin",ios::binary);
 vector<uint8_t>reach(istreambuf_iterator<char>(cf),{});assert(reach.size()==rank.size()/2);
 auto mv=[&](uint64_t key){int largest=0;
  for(int a=1;a<=7;a++)for(int b=a+1;b<=7;b++){
   int prev=0,n=0;
   for(int i=1;i<=7;i++)if(i!=a&&i!=b){array<int,3>I={a,b,i};sort(I.begin(),I.end());
    int x=(key>>pid[I[0]][I[1]][I[2]]&1)?1:-1;if(i&1)x=-x;
    if(prev&&x!=prev)n++;prev=x;
   }
   largest=max(largest,n);
  }
  return 4-largest;
 };
 auto qr=[&](uint32_t u,int g,int m){uint32_t k=4*u+g;
  int p=int(rank[u])-2*int(bool(reach[k/8]&(1u<<(k%8))));return p-2*int(p>8+m);};
 ifstream in("../../trajectory_search_20261108/g_exact_event_transitions.txt");assert(in);
 uint64_t a,b,total=0,gs=0,ts=0;int move,bit;
 while(in>>a>>b>>move>>bit){
  assert(move>=1&&move<=6&&bit>=0&&bit<52&&(a^b)==(1ull<<bit));
  uint64_t ma=a&((1ull<<50)-1),mb=b&((1ull<<50)-1);int ga=(a>>50)&3,gb=(b>>50)&3;
  assert(G.pass(ma,ga)&&G.pass(mb,gb));uint32_t ia=H.find(ma),ib=H.find(mb);
  assert(ia!=UINT32_MAX&&ib!=UINT32_MAX);
  bool okay=false;auto&ev=bit<50?events:G.new_events;
  for(auto&e:ev)if(e.move==move&&e.target==bit&&eligible(a,e)){okay=true;break;}
  assert(okay);int m1=mv(ma),m2=mv(mb),q1=qr(ia,ga,m1),q2=qr(ib,gb,m2);
  assert(0<=m2&&m2<=m1&&m1<=4);assert(q1>=q2+(bit==0));
  assert(q1>=0&&q1<=8+m1&&q2>=0&&q2<=8+m2);
  total++;gs+=bit>=50;ts+=bit==0;
 }
 assert(total>0&&gs>0&&ts>0);
 cout<<"PASS "<<total<<" actual rational singleton events, including "<<gs<<" G events and "<<ts<<" target crossings\n";
 cout<<"PASS graph coverage, monotonic m, and refined Q inequalities at every event\n";
}
