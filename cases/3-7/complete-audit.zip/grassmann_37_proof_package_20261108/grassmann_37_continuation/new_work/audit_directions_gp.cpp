// Independent audit of the 4,560 old direction types.
// Enumerates 15 edge-pair and 10 triangle signs, verifies the 16 exact
// affine identities, then checks ALL rank-two 3-term Pluecker sign axioms.
// It does not use direction_types(), its sorting/tournament test, or its
// C++ circuit filter.  The saved direction list supplies the comparison.
#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <set>
#include <utility>
#include <vector>
using namespace std;
using Pair=pair<int,int>;using Term=pair<int,int>;
int main(){
 vector<vector<Term>> relations={
  {{0,1},{3,-1},{6,1}},{{0,1},{11,-1},{14,1}},{{1,1},{4,-1},{9,1}},
  {{1,1},{8,-1},{13,-1}},{{2,1},{5,-1},{12,-1}},{{2,1},{7,-1},{10,1}},
  {{3,1},{10,-1},{13,1}},{{4,1},{7,-1},{14,-1}},{{5,1},{8,-1},{11,1}},
  {{6,1},{9,-1},{12,1}},
  {{0,1},{4,1},{8,-1},{10,-1},{12,-1}},
  {{0,1},{5,1},{7,-1},{9,1},{13,1}},
  {{1,1},{3,1},{7,-1},{11,-1},{12,1}},
  {{1,1},{5,-1},{6,1},{10,-1},{14,-1}},
  {{2,1},{3,1},{8,-1},{9,-1},{14,1}},
  {{2,1},{4,-1},{6,1},{11,1},{13,1}}};
 vector<array<int,4>> flab={{1,2,3,4},{1,3,2,4},{1,4,2,3},{1,2,3,5},
  {1,3,2,5},{1,5,2,3},{1,2,4,5},{1,4,2,5},{1,5,2,4},{1,3,4,5},
  {1,4,3,5},{1,5,3,4},{2,3,4,5},{2,4,3,5},{2,5,3,4}};
 map<array<int,4>,int>fid;for(int i=0;i<15;i++)fid[flab[i]]=i;
 vector<Pair>edges;for(int i=1;i<=5;i++)for(int j=i+1;j<=5;j++)edges.push_back({i,j});
 map<array<int,3>,int>tid;int at=0;for(int i=1;i<=5;i++)for(int j=i+1;j<=5;j++)for(int k=j+1;k<=5;k++)tid[{i,j,k}]=at++;
 int kind[10][10],index[10][10];
 for(int a=0;a<10;a++)for(int b=a+1;b<10;b++){
  auto [i,j]=edges[a];auto [k,l]=edges[b];vector<int>u={i,j,k,l};sort(u.begin(),u.end());u.erase(unique(u.begin(),u.end()),u.end());
  if(u.size()==3){kind[a][b]=1;index[a][b]=tid.at({u[0],u[1],u[2]});}
  else{assert(u.size()==4);kind[a][b]=0;index[a][b]=fid.at({i,j,k,l});}
 }
 vector<array<int,4>> quadruples;for(int a=0;a<10;a++)for(int b=a+1;b<10;b++)
  for(int c=b+1;c<10;c++)for(int d=c+1;d<10;d++)quadruples.push_back({a,b,c,d});
 assert(quadruples.size()==210);
 set<uint32_t>actual;int surviving_f=0;
 for(unsigned f=0;f<(1u<<15);f++){
  bool okay=true;for(auto&rel:relations){int sum=0;for(auto [i,s]:rel)sum+=s*((f>>i&1)?1:-1);if(abs(sum)==int(rel.size())){okay=false;break;}}
  if(!okay)continue;surviving_f++;
  for(unsigned tri=0;tri<(1u<<10);tri++){
   int chi[10][10]{};
   for(int a=0;a<10;a++)for(int b=a+1;b<10;b++){
    unsigned z=kind[a][b]?tri:f;chi[a][b]=(z>>index[a][b]&1)?1:-1;chi[b][a]=-chi[a][b];}
   bool pass=true;
   for(auto [a,b,c,d]:quadruples){
    int x=chi[a][b]*chi[c][d],y=-chi[a][c]*chi[b][d],z=chi[a][d]*chi[b][c];
    if(x==y&&y==z){pass=false;break;}
   }
   if(pass)actual.insert(f|(tri<<15));
  }
 }
 set<uint32_t>expected;ifstream in("../directions_filtered.txt");unsigned f,t;
 while(in>>f>>t)expected.insert(f|(t<<15));
 assert(surviving_f==1920);
 if(actual!=expected){
  cerr<<"FAIL GP patterns="<<actual.size()<<" stored="<<expected.size()<<"\n";
  int n=0;for(auto k:actual)if(!expected.count(k)&&n++<10)cerr<<"missing "<<k<<"\n";return 1;
 }
 cout<<"PASS independent 16-circuit/210-GP sign enumeration: "<<surviving_f
     <<" feature patterns, "<<actual.size()<<" direction types exactly match saved list\n";
}
