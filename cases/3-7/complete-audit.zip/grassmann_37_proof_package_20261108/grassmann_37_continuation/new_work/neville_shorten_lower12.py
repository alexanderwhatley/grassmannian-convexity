#!/usr/bin/env python3
"""Replace each positive-shear block by exact Neville factors.

Each block ends at an observed target sign change.  Its product is totally
nonnegative; if Neville elimination succeeds with nonnegative multipliers,
we have a much shorter exact positive word with the identical block product.
All identities and target crossings are checked with rational arithmetic.
"""
from fractions import Fraction as Q
from pathlib import Path
import json

root=Path(__file__).resolve().parent
z=json.loads((root/'short_lower12_merged.json').read_text())
initial=z['initial_columns']
word=[(j,Q(t)) for j,t in z['moves']]

def det(a,b,c):
    return (a[0]*(b[1]*c[2]-b[2]*c[1])
            -a[1]*(b[0]*c[2]-b[2]*c[0])
            +a[2]*(b[0]*c[1]-b[1]*c[0]))

def product(block):
    a=[[Q(i==j) for j in range(7)] for i in range(7)]
    for j,t in block:
        j-=1
        for i in range(7):a[i][j]+=t*a[i][j+1]
    return a

def factors(a):
    b=[row[:] for row in a]; result=[]
    for col in range(6):
        for i in range(6,col,-1):
            den=b[i-1][col];num=b[i][col]
            if not den:
                assert not num,('zero pivot',col,i)
                continue
            t=num/den
            assert t>=0,('negative factor',col,i,t)
            if t:
                result.append((i,t))
                b[i]=[x-t*y for x,y in zip(b[i],b[i-1])]
    assert b==[[Q(i==j) for j in range(7)] for i in range(7)]
    assert product(result)==a
    return result

v=[[Q(x) for x in col] for col in initial]
sgn=lambda x: (x>0)-(x<0)
old=sgn(det(*v[:3]));blocks=[];block=[]
for j,t in word:
    block.append((j,t));i=j-1
    v[i]=[x+t*y for x,y in zip(v[i],v[i+1])]
    now=sgn(det(*v[:3]));assert now
    if now!=old:
        blocks.append(block);block=[];old=now
assert len(blocks)==12
short=[]
for i,block in enumerate(blocks):
    w=factors(product(block))
    print('block',i+1,'old',len(block),'factors',len(w))
    short.extend(w)
out={'initial_columns':initial,'moves':[[j,str(t)] for j,t in short],
     'crossings':12,'method':'Exact nonnegative Neville elimination on 12 blocks.'}
(root/'neville_lower12.json').write_text(json.dumps(out,indent=2)+'\n')
print('total',len(short))
