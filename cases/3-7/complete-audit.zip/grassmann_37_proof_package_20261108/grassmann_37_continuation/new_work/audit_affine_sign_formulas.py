#!/usr/bin/env python3
"""Symbolically audit the affine edge-direction encoding of the 50 signs."""
from itertools import combinations
import sympy as s

Y=s.symbols('y1:6');Z=s.symbols('z1:6');X=s.symbols('x1:6',nonzero=True)
P={i:s.Matrix([Y[i-1],Z[i-1]]) for i in range(1,6)}
V={i:s.Matrix([X[i-1],X[i-1]*Y[i-1],X[i-1]*Z[i-1]]) for i in range(1,6)}
V[6]=s.Matrix([0,1,0]);V[7]=s.Matrix([0,0,1])
def d2(a,b):return s.det(s.Matrix.hstack(a,b))
def p(a,b,c):return s.det(s.Matrix.hstack(V[a],V[b],V[c]))
edges=list(combinations(range(1,6),2));checked=0
for a,b,c in combinations(range(1,6),3):
 assert s.expand(p(a,b,c)-X[a-1]*X[b-1]*X[c-1]*d2(P[b]-P[a],P[c]-P[a]))==0
 checked+=1
for a,b in edges:
 e=P[b]-P[a]
 assert s.expand(p(a,b,6)+X[a-1]*X[b-1]*e[1])==0
 assert s.expand(p(a,b,7)-X[a-1]*X[b-1]*e[0])==0
 checked+=2
for (a,b),(c,d) in combinations(edges,2):
 cross=d2(P[b]-P[a],P[d]-P[c]);u=sorted(set((a,b,c,d)))
 if len(u)==3:
  i,j,k=u;assert s.expand(cross-d2(P[j]-P[i],P[k]-P[i]))==0
 else:
  F=p(a,b,6)*p(c,d,7)-p(a,b,7)*p(c,d,6)
  assert s.expand(F-X[a-1]*X[b-1]*X[c-1]*X[d-1]*cross)==0
 checked+=1
print('PASS',checked,'symbolic affine-minor and edge-direction identities')
