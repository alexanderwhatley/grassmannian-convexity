#!/usr/bin/env python3
"""Audit the actual 16-circuit C++ filter against its proved identities."""
from pathlib import Path
import re

root=Path(__file__).resolve().parent.parent
ns={}
source=(root/'verify_feature_classification.py').read_text().split('def edge')[0]
exec(compile(source,'verify_feature_classification.py','exec'),ns)
header=(root/'affine_circuit_filter16.hpp').read_text()
def array(name):
 m=re.search(r'\b'+name+r'\[\]\s*=\s*\{([^}]*)\}',header)
 assert m,name
 return [int(x) for x in re.findall(r'\d+',m.group(1))]
plus=array('gc37_small_plus');minus=array('gc37_small_minus')
denom=array('gc37_small_denominator_masks')
assert len(plus)==len(minus)==len(ns['relations'])==16
for i,rel in enumerate(ns['relations']):
 assert plus[i]==sum(1<<j for j,s in rel if s==1),(i,'plus')
 assert minus[i]==sum(1<<j for j,s in rel if s==-1),(i,'minus')
assert len(denom)==len(ns['labels'])==15
for i,lab in enumerate(ns['labels']):
 assert denom[i]==sum(1<<(j-1) for j in lab),(i,lab,denom[i])
print('PASS C++ 16 relation masks and all 15 affine-normalization masks match the exact identities')
