// Independent reconstruction of all 50-sign keys from the saved (f,t)
// direction-sign list.  Axes are inserted by a direct gap formula and
// signs are computed from determinant identities, not add_axes/word_key.
// A separate GP enumeration verifies the saved 4,560 (f,t) list.
#define main gc37_graph_unused_main
#include "../rebuild_full_graph.cpp"
#undef main
int main(){
 init();auto original_dirs=direction_types(true);auto original_masks=sign_masks();
 Hash H(1ull<<25);uint32_t n=0;
 for(auto&w:original_dirs)for(auto&z:add_axes(w)){auto base=word_key(z);for(auto m:original_masks)H.insert(base^m,n++);}
 assert(n==16051200);
 vector<pair<int,int>>edges;for(int i=1;i<=5;i++)for(int j=i+1;j<=5;j++)edges.push_back({i,j});
 map<array<int,4>,int>feature;
 for(int i=0;i<15;i++)feature[flab[i]]=i;
 map<array<int,3>,int>triangle;int id=0;
 for(int i=1;i<=5;i++)for(int j=i+1;j<=5;j++)for(int k=j+1;k<=5;k++)triangle[{i,j,k}]=id++;
 int kind[10][10],ind[10][10];
 for(int i=0;i<10;i++)for(int j=i+1;j<10;j++){
  auto [a,b]=edges[i];auto [c,d]=edges[j];vector<int>u={a,b,c,d};sort(u.begin(),u.end());u.erase(unique(u.begin(),u.end()),u.end());
  if(u.size()==3){kind[i][j]=1;ind[i][j]=triangle.at({u[0],u[1],u[2]});}
  else{kind[i][j]=0;ind[i][j]=feature.at({a,b,c,d});}
 }
 array<uint64_t,16>independent_masks{};
 for(int x=0;x<16;x++){
  for(int b=0;b<35;b++)for(int i:ps[b])if(i<=4&&(x>>(i-1)&1))independent_masks[x]^=1ull<<b;
  for(int b=0;b<15;b++)for(int i:flab[b])if(i<=4&&(x>>(i-1)&1))independent_masks[x]^=1ull<<(35+b);
 }
 vector<uint8_t>seen(n);uint64_t generated=0;int patterns=0;
 ifstream input("../directions_filtered.txt");unsigned f,t;
 while(input>>f>>t){
  patterns++;int chi[10][10]{};
  for(int i=0;i<10;i++)for(int j=i+1;j<10;j++){
   unsigned bits=kind[i][j]?t:f;chi[i][j]=(bits>>ind[i][j]&1)?1:-1;chi[j][i]=-chi[i][j];}
  int side[10];side[0]=1;for(int i=1;i<10;i++)side[i]=chi[0][i];
  vector<int>order;for(int i=1;i<10;i++)order.push_back(i);
  sort(order.begin(),order.end(),[&](int a,int b){return side[a]*side[b]*chi[a][b]>0;});
  int pos[10]={};for(int r=0;r<9;r++)pos[order[r]]=1+r+(side[order[r]]<0?10:0);
  for(int i=0;i<10;i++)for(int j=i+1;j<10;j++)assert((((pos[j]-pos[i]+20)%20)<10?1:-1)==chi[i][j]);
  for(int gapA=0;gapA<20;gapA++)for(int rel=0;rel<=10;rel++){
   int gapB=(gapA+rel)%20;uint64_t base=0;
   for(int b=0;b<35;b++){
    auto I=ps[b];int a=I[0],c=I[1],d=I[2],sg;
    if(d<=5)sg=(t>>triangle.at({a,c,d})&1)?1:-1;
    else if(c<=5){int edge=eid[a][c];int gap=d==6?gapA:gapB;
     sg=((gap-pos[edge]+20)%20)<10?1:-1;}
    else sg=1;
    if(sg>0)base|=1ull<<b;
   }
   for(int b=0;b<15;b++)if(f>>b&1)base|=1ull<<(35+b);
   for(int x=0;x<16;x++){
    uint64_t k=base^independent_masks[x];uint32_t j=H.find(k);
    if(j==UINT32_MAX){cerr<<"FAIL missing key "<<k<<" f="<<f<<" t="<<t<<" gaps="<<gapA<<","<<gapB<<" x="<<x<<"\n";return 1;}
    if(seen[j]){cerr<<"FAIL duplicate independent key "<<k<<"\n";return 1;}
    seen[j]=1;generated++;
   }
  }
 }
 assert(patterns==4560&&generated==n&&count(seen.begin(),seen.end(),1)==n);
 cout<<"PASS independent gap/determinant reconstruction: "<<patterns<<" direction types and "<<generated<<" unique 50-sign keys match original generator\n";
}
