// Look up optimal 52-sign graph ranks of exact scalar-cascade endpoints.
#define main gc37_original_unused_main
#include "../rebuild_full_graph.cpp"
#undef main
#include "../history_20261108/g_features.hpp"
int main(){
 init();GFeatures G;auto dirs=direction_types(true);auto masks=sign_masks();Hash H(1ull<<25);uint32_t n=0;
 for(auto&w:dirs)for(auto&z:add_axes(w)){uint64_t base=word_key(z);for(auto s:masks)H.insert(base^s,n++);}assert(n==16051200);
 vector<uint8_t>rank(4ull*n);ifstream f("augmented_optimal_rank.bin",ios::binary);assert(f);f.read((char*)rank.data(),rank.size());assert(f.gcount()==int64_t(rank.size()));
 ifstream in("scalar_four_keys.txt");assert(in);uint64_t key;int proj;uint64_t table[13][9]{};int total=0;
 while(in>>key>>proj){uint64_t base=key&((1ull<<50)-1);int g=(key>>50)&3;uint32_t i=H.find(base);
  assert(i!=UINT32_MAX&&G.pass(base,g)&&proj>=0&&proj<=8);int h=rank[4ull*i+g];assert(h<=8);table[h][proj]++;total++;}
 cout<<"PASS lookup for "<<total<<" exact scalar-cascade endpoints (H is graph upper rank)\n";
 for(int h=0;h<=8;h++)for(int p=0;p<=8;p++)if(table[h][p])cout<<"H="<<h<<" sampled projected rank="<<p<<" count="<<table[h][p]<<'\n';
}
