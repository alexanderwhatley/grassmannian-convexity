// Check exact graph H for the keys produced by search_graph_rank_gap.py.
#define main gc37_original_unused_main
#include "../rebuild_full_graph.cpp"
#undef main
#include "../history_20261108/g_features.hpp"
int main(){
 init();GFeatures G;auto dirs=direction_types(true);auto masks=sign_masks();
 Hash lookup(1ull<<25);uint32_t n=0;
 for(auto&w:dirs)for(auto&z:add_axes(w)){uint64_t base=word_key(z);for(auto m:masks)lookup.insert(base^m,n++);}
 assert(n==16051200);
 vector<uint8_t>rank(4ull*n);ifstream in("augmented_optimal_rank.bin",ios::binary);assert(in);
 in.read((char*)rank.data(),rank.size());assert(in.gcount()==int64_t(rank.size()));
 ifstream keys("graph_rank_gap_keys.txt");assert(keys);uint64_t key;int projected;size_t i=0;uint64_t counts[13][9]{};
 while(keys>>key>>projected){uint64_t base=key&((1ull<<50)-1);int g=(key>>50)&3;uint32_t p=lookup.find(base);
  assert(p!=UINT32_MAX&&G.pass(base,g));int h=rank[4ull*p+g];assert(h<=12&&projected<=8);counts[h][projected]++;
  if(h>projected)cout<<"GAP candidate index="<<i<<" key="<<key<<" H="<<h<<" projected="<<projected<<"\n";
  i++;
 }
 cout<<"PASS "<<i<<" exact keys looked up\n";for(int h=0;h<=12;h++)for(int p=0;p<=8;p++)if(counts[h][p])cout<<"H="<<h<<" projection="<<p<<" count="<<counts[h][p]<<"\n";
}
