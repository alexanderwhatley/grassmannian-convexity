#!/usr/bin/env python3
"""Exploratory 28-move search; any reported success is replayed exactly.

Delete one U5 from the 29-step witness, vary the 12 positive-chart start
parameters and all remaining positive move times, and optimize target-sign
margins. Floating-point search failure gives no impossibility conclusion.
"""
from fractions import Fraction as Q
from itertools import combinations
from pathlib import Path
from random import Random
import json
import numpy as np
from scipy.optimize import least_squares

root=Path(__file__).resolve().parent
z=json.loads((root/'witness_29_integer.json').read_text());initial=np.array(z['initial_columns'],float).T
original=[(j,float(t)) for j,t in z['moves']];rect=[4,3,2,1,5,4,3,2,6,5,4,3]
def det(a,b,c):return np.dot(a,np.cross(b,c))
D=np.array([(-1.)**i for i in range(1,8)])
X=initial*D
p=lambda a,b,c:det(X[:,a-1],X[:,b-1],X[:,c-1])/det(X[:,4],X[:,5],X[:,6])
a0=np.array([p(1,6,7)*p(4,5,6)/p(1,5,6),p(1,5,6)*p(3,4,5)/(p(1,4,5)*p(4,5,6)),
 p(1,4,5)*p(2,3,4)/(p(1,3,4)*p(3,4,5)),p(1,3,4)/p(2,3,4),
 p(1,2,7)*p(1,5,6)/(p(1,2,6)*p(1,6,7)),p(1,2,6)*p(1,4,5)/(p(1,2,5)*p(1,5,6)),
 p(1,2,5)*p(1,3,4)/(p(1,2,4)*p(1,4,5)),p(1,2,4)/p(1,3,4),
 p(1,2,6)/p(1,2,7),p(1,2,5)/p(1,2,6),p(1,2,4)/p(1,2,5),p(1,2,3)/p(1,2,4)])
assert (a0>0).all()
def chart(a):
    Y=np.zeros((3,7));Y[:,4:7]=np.eye(3)
    for j,t in zip(rect,a):Y[:,j-1]+=t*Y[:,j]
    return Y
Y=chart(a0);B=X[:,4:7]@np.linalg.inv(Y[:,4:7]);assert np.allclose(B@Y,X,rtol=1e-7,atol=1e-7)
v=initial.copy()
for j,t in original[:22]:v[:,j-1]+=t*v[:,j]
condition=np.linalg.inv(v[:,:3])@B
def initial_units(x,derivative=False):
    a=np.exp(x[:12]);Y=np.zeros((3,7));Y[:,4:7]=np.eye(3)
    K=np.zeros((3,7,len(x))) if derivative else None
    for i,(j,t) in enumerate(zip(rect,a)):
        old=Y[:,j].copy();Y[:,j-1]+=t*old
        if derivative:
            K[:,j-1,:]+=t*K[:,j,:];K[:,j-1,i]+=t*old
    Y=(condition@Y)*D
    if derivative:
        K=np.einsum('ab,bcn->acn',condition,K)*D[None,:,None]
    norms=np.linalg.norm(Y,axis=0);U=Y/norms
    if derivative:
        K=(K-U[:,:,None]*np.einsum('ac,acn->cn',U,K)[None,:,:])/norms[None,:,None]
    return U,K,norms
def run(x,word,weights=None):
    U,K,norms=initial_units(x,True);vals=[];der=[]
    for i,j in enumerate(word):
        r=np.exp(x[12+i]);q=j-1;v=U[:,q]+r*U[:,q+1]
        dv=K[:,q,:]+r*K[:,q+1,:];dv[:,12+i]+=r*U[:,q+1]
        norm=np.linalg.norm(v);u=v/norm
        K[:,q,:]=(dv-u[:,None]*(u@dv)[None,:])/norm;U[:,q]=u
        if j==3:
            a,b,c=U[:,0],U[:,1],U[:,2];value=det(a,b,c)
            grad=np.cross(b,c)@K[:,0,:]+np.cross(c,a)@K[:,1,:]+np.cross(a,b)@K[:,2,:]
            vals.append(value);der.append(grad)
    return np.array(vals),np.array(der)
base_x=np.r_[np.log(a0),np.zeros(len(original))]
_,_,norms=initial_units(base_x,False);units,_,norms=initial_units(base_x,False)
times=[]
for j,t in original:
    q=j-1;r=t*norms[q+1]/norms[q];times.append(np.log(r))
    v=units[:,q]+r*units[:,q+1];s=np.linalg.norm(v);units[:,q]=v/s;norms[q]*=s
base_x[12:]=times
start_units,_,_=initial_units(base_x,False)
initial_sign=np.sign(det(start_units[:,0],start_units[:,1],start_units[:,2]));assert initial_sign
desired=initial_sign*np.array([(-1.)**i for i in range(1,13)])
fullvals,_=run(base_x,[j for j,t in original]);assert np.all(desired*fullvals>0),fullvals
weights=1/np.maximum(np.abs(fullvals),2e-10)
print('baseline normalized crossing magnitudes',np.abs(fullvals),flush=True)

def exact_candidate(x,word):
    aa=[Q(format(float(a),'.15g')) for a in np.exp(x[:12])]
    V=[[Q(int(i==j-4)) if j>=4 else Q(0) for j in range(7)] for i in range(3)]
    for j,t in zip(rect,aa):
        for i in range(3):V[i][j-1]+=t*V[i][j]
    cols=[[V[i][j]*(-1)**(j+1) for i in range(3)] for j in range(7)]
    u,_,norms=initial_units(x,False);lognorm=np.log(norms);moves=[]
    for i,j in enumerate(word):
        q=j-1;r=np.exp(x[12+i]);t=np.exp(x[12+i]+lognorm[q]-lognorm[q+1]);
        if not np.isfinite(t) or t<=0:return None
        rat=Q(format(float(t),'.15g'));moves.append([j,str(rat)])
        v=u[:,q]+r*u[:,q+1];norm=np.linalg.norm(v);u[:,q]=v/norm;lognorm[q]+=np.log(norm)
    def determinant(a,b,c):return a[0]*(b[1]*c[2]-b[2]*c[1])-a[1]*(b[0]*c[2]-b[2]*c[0])+a[2]*(b[0]*c[1]-b[1]*c[0])
    triples=list(combinations(range(7),3));old=determinant(*cols[:3]);flips=[]
    for step,(j,t) in enumerate(moves,1):
        t=Q(t);cols[j-1]=[a+t*b for a,b in zip(cols[j-1],cols[j])]
        pp=[determinant(*(cols[i] for i in I)) for I in triples]
        if not all(pp):return None
        if (pp[0]>0)!=(old>0):flips.append(step)
        old=pp[0]
    if len(flips)!=12:return None
    Y=[[Q(int(i==j-4)) if j>=4 else Q(0) for j in range(7)] for i in range(3)]
    for j,t in zip(rect,aa):
        for i in range(3):Y[i][j-1]+=t*Y[i][j]
    start=[[str(Y[i][j]*(-1)**(j+1)) for i in range(3)] for j in range(7)]
    return {'initial_columns':start,'moves':moves,'target_flip_steps':flips,'method':'numerical search; exact rational replay'}

rng=Random(37128);best=1e300
for trial in range(90):
    dropped=[i for i,(j,t) in enumerate(original) if j==5][trial%3]
    word=[j for i,(j,t) in enumerate(original) if i!=dropped]
    x=np.r_[base_x[:12],np.delete(base_x[12:],dropped)]
    if trial>=3:x+=np.array([rng.gauss(0,0.2 if i<12 else 0.7) for i in range(len(x))])
    def fun(x):
        v,J=run(x,word);return np.minimum(desired*v*weights-1,0)
    def jac(x):
        v,J=run(x,word);active=(desired*v*weights<1)
        return J*(active*desired*weights)[:,None]
    q=least_squares(fun,x,jac=jac,max_nfev=700,ftol=1e-12,xtol=1e-12,gtol=1e-12,
                    bounds=(np.full(len(x),-35.),np.full(len(x),35.)))
    score=np.linalg.norm(q.fun)
    if score<best:best=score;print('trial',trial,'drop',dropped+1,'best',score,flush=True)
    if score<1e-8:
        result=exact_candidate(q.x,word)
        if result:
            (root/'witness_28_chart_search.json').write_text(json.dumps(result,indent=2)+'\n')
            print('PASS exact 28-move, 12-flip witness!',flush=True);break
else:print('No exact success in finite exploratory search; no impossibility conclusion')
