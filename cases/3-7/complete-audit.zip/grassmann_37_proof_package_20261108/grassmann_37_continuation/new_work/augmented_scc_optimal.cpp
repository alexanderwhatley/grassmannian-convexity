// Compute the exact longest target-change rank of the 52-sign overapproximation.
// This is exploratory: unlike the direct Q certificate, it computes SCCs.
// Run here with the existing filtered_rank.bin and nohalf K certificate.
#define main gc37_original_unused_main
#include "../rebuild_full_graph.cpp"
#undef main
#include "../history_20261108/g_features.hpp"

int main(){
 auto start=chrono::steady_clock::now();init();GFeatures G;
 for(auto e:G.new_events)events.push_back(e);
 auto dirs=direction_types(true);auto masks=sign_masks();
 Hash H(1ull<<26);vector<uint64_t>keys;vector<uint32_t>code;
 keys.reserve(23246848);code.reserve(23246848);uint32_t base_id=0;
 for(auto&w:dirs)for(auto&z:add_axes(w)){uint64_t b=word_key(z);for(auto s:masks){
  uint64_t base=b^s;
  for(int g=0;g<4;g++)if(G.pass(base,g)){
   uint64_t k=base|(uint64_t(g)<<50);H.insert(k,keys.size());
   keys.push_back(k);code.push_back(4*base_id+g);
  }
  base_id++;
 }}
 uint32_t n=keys.size();assert(base_id==16051200&&n==23246848);
 cerr<<"generated "<<n<<" admissible states; constructing edges\n";
 const int nt=8;vector<vector<uint32_t>>chunks(nt);vector<uint8_t>degree(n);
 vector<thread>threads;
 for(int t=0;t<nt;t++)threads.emplace_back([&,t](){
  size_t lo=size_t(n)*t/nt,hi=size_t(n)*(t+1)/nt;auto&v=chunks[t];v.reserve((hi-lo)*7);
  for(size_t i=lo;i<hi;i++){
   uint64_t k=keys[i],candidate=0;for(auto e:events)if(eligible(k,e))candidate|=1ull<<e.target;
   int deg=0;while(candidate){int bit=__builtin_ctzll(candidate);candidate&=candidate-1;
    uint32_t dest=H.find(k^(1ull<<bit));if(dest==UINT32_MAX)continue;
    v.push_back(dest|(bit==0?0x80000000u:0u));deg++;
   }
   assert(deg<256);degree[i]=deg;
  }
 });
 for(auto&t:threads)t.join();threads.clear();uint64_t m=0,weighted=0;
 for(auto&v:chunks){m+=v.size();for(auto x:v)weighted+=x>>31;}
 assert(m==144788896&&weighted==663552&&m<UINT32_MAX);
 cerr<<"built "<<m<<" distinct edges, "<<weighted<<" target edges; releasing hash\n";
 vector<uint64_t>().swap(H.k);vector<uint32_t>().swap(H.v);
 vector<uint32_t>off(n+1);for(uint32_t i=0;i<n;i++)off[i+1]=off[i]+degree[i];assert(off[n]==m);
 vector<uint32_t>arcs;arcs.reserve(m);
 for(auto&v:chunks){arcs.insert(arcs.end(),v.begin(),v.end());vector<uint32_t>().swap(v);}
 vector<uint32_t>rev(n+1);for(auto e:arcs)rev[(e&0x7fffffffu)+1]++;
 for(uint32_t i=0;i<n;i++)rev[i+1]+=rev[i];assert(rev[n]==m);
 vector<uint32_t>cursor=rev,back(m);
 for(uint32_t u=0;u<n;u++)for(uint32_t p=off[u];p<off[u+1];p++)back[cursor[arcs[p]&0x7fffffffu]++]=u;
 vector<uint32_t>().swap(cursor);cerr<<"reverse graph built; computing forward DFS\n";
 vector<uint8_t>seen(n),next(n);vector<uint32_t>order,stack;order.reserve(n);
 for(uint32_t root=0;root<n;root++)if(!seen[root]){
  seen[root]=1;stack.push_back(root);
  while(!stack.empty()){
   uint32_t u=stack.back();
   if(next[u]<degree[u]){uint32_t v=arcs[off[u]+next[u]++]&0x7fffffffu;
    if(!seen[v]){seen[v]=1;stack.push_back(v);}}
   else{stack.pop_back();order.push_back(u);}
  }
 }
 assert(order.size()==n);vector<uint8_t>().swap(seen);vector<uint8_t>().swap(next);
 cerr<<"forward DFS complete; computing reverse components\n";
 vector<uint32_t>component(n,UINT32_MAX);uint32_t count=0,largest=0;
 for(uint64_t z=n;z;z--){uint32_t root=order[z-1];if(component[root]!=UINT32_MAX)continue;
  uint32_t size=0;component[root]=count;stack.push_back(root);
  while(!stack.empty()){
   uint32_t u=stack.back();stack.pop_back();size++;
   for(uint32_t e=rev[u];e<rev[u+1];e++){uint32_t v=back[e];if(component[v]==UINT32_MAX){component[v]=count;stack.push_back(v);}}
  }
  largest=max(largest,size);count++;
 }
 vector<uint32_t>().swap(order);vector<uint32_t>().swap(stack);
 vector<uint32_t>().swap(rev);vector<uint32_t>().swap(back);
 cerr<<"SCC count "<<count<<", largest "<<largest<<"; computing exact ranks\n";
 vector<uint32_t>coff(count+1),members(n);for(uint32_t c:component)coff[c+1]++;
 for(uint32_t c=0;c<count;c++)coff[c+1]+=coff[c];vector<uint32_t>fill=coff;
 for(uint32_t u=0;u<n;u++)members[fill[component[u]]++]=u;
 vector<uint32_t>().swap(fill);vector<uint8_t>optimal(count);
 for(uint64_t z=count;z;z--){uint32_t c=z-1;unsigned best=0;
  for(uint32_t k=coff[c];k<coff[c+1];k++){
   uint32_t u=members[k];for(uint32_t e=off[u];e<off[u+1];e++){
    uint32_t x=arcs[e],v=x&0x7fffffffu,w=x>>31,d=component[v];
    if(d==c){if(w){cerr<<"FAIL positive-weight cycle\n";return 1;}}
    else{assert(d>c);best=max(best,w+optimal[d]);}
   }
  }
  assert(best<=12);optimal[c]=best;
 }
 vector<uint8_t>old(16051200),K(8025600),mcache(16051200,255),out(4ull*16051200,255);
 ifstream rf("../filtered_rank.bin",ios::binary);rf.read((char*)old.data(),old.size());assert(rf.gcount()==int64_t(old.size()));
 ifstream kf("../history_20261108/g_reachable_50_nohalf.bin",ios::binary);kf.read((char*)K.data(),K.size());assert(kf.gcount()==int64_t(K.size()));
 auto mv=[&](uint64_t key){int best=0;
  for(int a=1;a<=7;a++)for(int b=a+1;b<=7;b++){int last=0,num=0;
   for(int i=1;i<=7;i++)if(i!=a&&i!=b){array<int,3>p={a,b,i};sort(p.begin(),p.end());
    int s=(key>>pid[p[0]][p[1]][p[2]]&1)?1:-1;if(i&1)s=-s;
    if(last&&last!=s)num++;last=s;}
   best=max(best,num);
  }return 4-best;
 };
 uint64_t hist[5][13]{},slack[13]{};int maxh[5]{};
 for(uint32_t u=0;u<n;u++){
  uint32_t c=code[u],bi=c/4;int h=optimal[component[u]];
  if(mcache[bi]==255)mcache[bi]=mv(keys[u]);int m=mcache[bi];assert(m<=4);
  int p=int(old[bi])-2*int(bool(K[c/8]&(1u<<(c%8))));int q=p-2*int(p>8+m);
  assert(h<=q&&q<=8+m);hist[m][h]++;slack[q-h]++;maxh[m]=max(maxh[m],h);out[c]=h;
 }
 ofstream file("augmented_optimal_rank.bin",ios::binary);file.write((char*)out.data(),out.size());assert(file);
 cout<<"PASS exact 52-sign SCC rank: states="<<n<<" edges="<<m<<" components="<<count<<" largest="<<largest<<" max="<<int(*max_element(optimal.begin(),optimal.end()))<<"\n";
 for(int j=0;j<=4;j++){cout<<"m="<<j<<" max="<<maxh[j]<<" distribution";for(int h=0;h<=12;h++)if(hist[j][h])cout<<' '<<h<<':'<<hist[j][h];cout<<'\n';}
 cout<<"Q minus exact rank:";for(int d=0;d<=12;d++)if(slack[d])cout<<' '<<d<<':'<<slack[d];cout<<'\n';
 cout<<"saved augmented_optimal_rank.bin, "<<out.size()<<" bytes; seconds="<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<"\n";
}
