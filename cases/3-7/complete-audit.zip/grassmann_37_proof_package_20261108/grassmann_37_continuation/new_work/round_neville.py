#!/usr/bin/env python3
"""Find a simpler decimal rational witness and verify it with exact arithmetic.

Every candidate is accepted only after all 35 minor signs at all vertices,
and all 12 target changes, have been checked with rational arithmetic.
"""
from fractions import Fraction
from itertools import combinations
from pathlib import Path
import json

root = Path(__file__).resolve().parent
original = json.loads((root / 'neville_lower12.json').read_text())
initial = original['initial_columns']
moves = [(j, Fraction(t)) for j, t in original['moves']]
triples = list(combinations(range(7), 3))

def determinant(a, b, c):
    return (a[0]*(b[1]*c[2]-b[2]*c[1])
            - a[1]*(b[0]*c[2]-b[2]*c[0])
            + a[2]*(b[0]*c[1]-b[1]*c[0]))

def replay(sequence, all_minors=False):
    columns = [[Fraction(x) for x in v] for v in initial]
    previous = determinant(*columns[:3])
    if not previous:
        return None
    crossings = []
    for step, (j, t) in enumerate(sequence, 1):
        if t <= 0:
            return None
        columns[j-1] = [a+t*b for a,b in zip(columns[j-1], columns[j])]
        target = determinant(*columns[:3])
        if not target:
            return None
        if (previous > 0) != (target > 0):
            crossings.append(step)
        previous = target
        if all_minors and any(not determinant(*(columns[i] for i in I)) for I in triples):
            return None
    return crossings

baseline = replay(moves)
assert baseline and len(baseline) == 12
for precision in range(1, 33):
    scale = 10**precision
    candidate = [(j, Fraction((2*t.numerator*scale+t.denominator)//(2*t.denominator), scale))
                 for j, t in moves]
    if replay(candidate) == baseline and replay(candidate, True) == baseline:
        destination = root / 'neville_lower12_decimal.json'
        destination.write_text(json.dumps({'initial_columns': initial,
            'moves': [[j, str(t)] for j,t in candidate],
            'crossings': baseline,
            'method': f'exact replay of all minors after rounding to {precision} decimal places'},
            indent=2)+'\n')
        print('PASS', precision, 'decimal places,', len(candidate),
              'moves; exact target changes', baseline)
        break
else:
    raise AssertionError('no candidate passed')
