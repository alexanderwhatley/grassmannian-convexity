// Direct independent verification of the proposed 0..12 prerank
// P(base,g)=old_rank(base)-2*1_K(base,g) on EVERY necessary 52-sign state.
// This does not use the G-search, its cyclic-word table or the SCC code.
// It shares the original 50-state generator and the two supplied certificates.
#define main gc37_graph_unused_main
#include "../rebuild_full_graph.cpp"
#undef main

struct Test {int move,target,a,b,sg;};
int main(){
 init();auto dirs=direction_types(true);auto masks=sign_masks();Hash H(1ull<<25);
 vector<uint64_t>keys;keys.reserve(16051200);
 for(auto&w:dirs)for(auto&z:add_axes(w)){uint64_t base=word_key(z);for(auto mask:masks){
  uint64_t k=base^mask;H.insert(k,keys.size());keys.push_back(k);}}
 const uint32_t n=keys.size();assert(n==16051200);
 vector<uint8_t>rank(n),K(uint64_t(n)*4/8),valid(n);
 ifstream rf("../filtered_rank.bin",ios::binary);rf.read((char*)rank.data(),n);assert(rf.gcount()==n);
 ifstream kf("../history_20261108/g_reachable_50_nohalf.bin",ios::binary);
 kf.read((char*)K.data(),K.size());assert(kf.gcount()==int64_t(K.size()));char extra;assert(!kf.read(&extra,1));
 auto ink=[&](uint32_t i,int g){uint32_t k=i*4+g;return int((K[k/8]>>(k%8))&1u);};
 auto sign=[](uint64_t k,int i){return ((k>>i)&1)?1:-1;};
 auto oriented=[&](uint64_t k,int a,int b,int c){
  int parity=(a>b)+(a>c)+(b>c);array<int,3>I={a,b,c};sort(I.begin(),I.end());
  int x=sign(k,pid[I[0]][I[1]][I[2]]);return parity&1?-x:x;
 };
 auto valid_state=[&](uint64_t k,int bits){
  int A[3],B[3];for(int i=0;i<3;i++){A[i]=sign(k,pid[1][2][5+i]);B[i]=sign(k,pid[3][4][5+i]);}
  int E[3]={(bits&1)?1:-1,(bits&2)?1:-1,sign(k,35)}; // 56,57,67
  auto force=[](int a,int b,int z){return a==b||z==a;};
  if(!force(A[0]*B[1],A[1]*B[0],E[0])||!force(A[0]*B[2],A[2]*B[0],E[1])||
     !force(A[1]*B[2],A[2]*B[1],E[2]))return false;
  if(abs(A[0]*E[2]-A[1]*E[1]+A[2]*E[0])==3)return false;
  if(abs(B[0]*E[2]-B[1]*E[1]+B[2]*E[0])==3)return false;
  for(int h=0;h<2;h++){
   pair<int,int> pp[3]={{1,2},{3,4},{5,6+h}};int z=(bits>>h&1)?1:-1;
   for(int r=0;r<3;r++){
    auto[a,b]=pp[r];auto[c,d]=pp[(r+1)%3];auto[e,f]=pp[(r+2)%3];
    int x=oriented(k,a,b,e)*oriented(k,c,d,f),y=oriented(k,a,b,f)*oriented(k,c,d,e);
    if(x!=y&&x!=z)return false;
   }
  }
  return true;
 };
 vector<Test>tests;ifstream et("../event_table.txt");Test q;
 while(et>>q.move>>q.target>>q.a>>q.b>>q.sg)if(q.target<50)tests.push_back(q);
 assert(tests.size()==108);
 tests.push_back({2,50,pid[1][3][4],pid[3][5][6],1});
 tests.push_back({4,50,pid[1][2][5],pid[3][5][6],1});
 tests.push_back({6,50,51,-1,1});
 tests.push_back({2,51,pid[1][3][4],pid[3][5][7],1});
 tests.push_back({4,51,pid[1][2][5],pid[3][5][7],1});
 tests.push_back({5,51,35,-1,1});
 vector<thread>threads;
 for(int th=0;th<8;th++)threads.emplace_back([&,th](){
  for(size_t u=size_t(n)*th/8;u<size_t(n)*(th+1)/8;u++){
   uint8_t v=0;for(int g=0;g<4;g++)if(valid_state(keys[u],g))v|=1u<<g;valid[u]=v;
  }
 });
 for(auto&t:threads)t.join();threads.clear();
 atomic<uint64_t>states{0},edges{0},target_edges{0},stored{0};
 for(int th=0;th<8;th++)threads.emplace_back([&,th](){
  uint64_t ns=0,ne=0,nw=0,nk=0;
  for(size_t u=size_t(n)*th/8;u<size_t(n)*(th+1)/8;u++){
   assert(rank[u]<=14);uint64_t base=keys[u];
   for(int g=0;g<4;g++){
    bool admitted=valid[u]&(1u<<g);int member=ink(u,g);
    if(!admitted){assert(!member);continue;}
    int Ru=int(rank[u])-2*member;assert(Ru>=0&&Ru<=12);ns++;nk+=member;
    uint64_t state=base|(uint64_t(g)<<50);
    for(const Test&e:tests){
     int target=sign(state,e.target),der=e.sg*sign(state,e.a)*(e.b<0?1:sign(state,e.b));
     if(target==der)continue;
     uint32_t v;int h,weight;
     if(e.target<50){v=H.find(base^(1ull<<e.target));if(v==UINT32_MAX)continue;h=g;weight=e.target==pid[1][2][3];}
     else{v=u;h=g^(1<<(e.target-50));weight=0;}
     if(!(valid[v]&(1u<<h)))continue;
     int Rv=int(rank[v])-2*ink(v,h);
     if(Ru<Rv+weight){cerr<<"FAIL prerank at key="<<state<<" target="<<e.target<<" move="<<e.move<<"\n";abort();}
     ne++;nw+=weight;
    }
   }
  }
  states+=ns;edges+=ne;target_edges+=nw;stored+=nk;
 });
 for(auto&t:threads)t.join();
 cout<<"PASS direct 0..12 prerank on "<<states<<" admitted 52-sign states ("<<stored<<" in K)\n";
 cout<<"PASS all "<<edges<<" move-labeled candidate transitions, including "<<target_edges<<" target transitions\n";
}
