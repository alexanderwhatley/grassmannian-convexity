#!/usr/bin/env python3
"""Check that every original tracked polynomial is affine on each move.

Run from the parent project directory.  The G features are checked by the
separate full-substitution audit.
"""
import runpy
import sympy as s

ns=runpy.run_path('verify_event_table_symbolic.py')
values=ns['values'][:50]
v=ns['v']
checks=0
for j in range(6):
    for p in values:
        d=sum(s.diff(p,v[j][k])*v[j+1][k] for k in range(3))
        dd=sum(s.diff(d,v[j][k])*v[j+1][k] for k in range(3))
        assert s.expand(dd)==0,(j,p)
        checks+=1
print('PASS',checks,'original feature/move polynomials are affine')
