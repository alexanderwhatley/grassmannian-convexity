#!/usr/bin/env python3
"""Independently replay a 12-crossing rational sequence on all Pluecker minors.

Unlike the construction, this never evolves the 3x7 matrix or uses root
isolation, floating point, or symbolic libraries: it applies the exact exterior
power update to all 35 integer/rational minors at every elementary move.
"""
from fractions import Fraction as Q
from itertools import combinations
from pathlib import Path
import json

z = json.loads((Path(__file__).with_name('rational_lower12_constant_flow.json')).read_text())
v = z['initial_columns']
samples = [Q(s) for s in z['sample_times']]
m = z['subdivisions_per_interval']
assert len(v) == 7 and all(len(col)==3 for col in v)
assert len(samples)==13 and all(a<b for a,b in zip(samples,samples[1:])) and m>0

def det(a,b,c):
    return (a[0]*b[1]*c[2]+a[1]*b[2]*c[0]+a[2]*b[0]*c[1]
            -a[2]*b[1]*c[0]-a[1]*b[0]*c[2]-a[0]*b[2]*c[1])

triples = list(combinations(range(7),3))
P = {I:Q(det(*(v[i] for i in I))) for I in triples}
assert all(P.values())
sgn=lambda x: 1 if x>0 else -1
old=sgn(P[(0,1,2)]); boundary=[old]; crosses=0; steps=0
for a,b in zip(samples,samples[1:]):
    t=(b-a)/m; assert t>0
    for _ in range(m):
        for j in range(6):
            changes=[]
            for I in triples:
                if j in I and j+1 not in I:
                    K=tuple(sorted((set(I)-{j})|{j+1}))
                    changes.append((I,P[I]+t*P[K]))
            for I,x in changes:
                P[I]=x
            assert all(P.values()), (steps,j)
            now=sgn(P[(0,1,2)])
            crosses += now!=old
            old=now;steps+=1
    boundary.append(old)
assert boundary == z['expected_target_signs']
assert crosses==z['target_crossings']==12 and steps==12*6*m
print('PASS exact exterior-power replay:',steps,'strictly positive moves,',crosses,'target crossings')
print('PASS all 35 maximal minors nonzero at every recorded matrix; sample signs alternate 13 times')
