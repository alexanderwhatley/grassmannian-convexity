#!/usr/bin/env python3
"""Independent exact certificate of 15-feature strict-sign classification.

16 displayed identities are independently checked as linear exterior-product
identities. They admit exactly 1920 of 32768 sign patterns. Nine exact generic
integer/rational matrices, under all point permutations and planar reflection,
produce all 1920 patterns. No LP or externally generated circuit list is used.
"""
from fractions import Fraction as Q
from itertools import combinations,permutations
import json
from pathlib import Path

labels=[(1,2,3,4),(1,3,2,4),(1,4,2,3),(1,2,3,5),(1,3,2,5),
        (1,5,2,3),(1,2,4,5),(1,4,2,5),(1,5,2,4),(1,3,4,5),
        (1,4,3,5),(1,5,3,4),(2,3,4,5),(2,4,3,5),(2,5,3,4)]
relations=[[(0,1),(3,-1),(6,1)],[(0,1),(11,-1),(14,1)],
 [(1,1),(4,-1),(9,1)],[(1,1),(8,-1),(13,-1)],[(2,1),(5,-1),(12,-1)],
 [(2,1),(7,-1),(10,1)],[(3,1),(10,-1),(13,1)],[(4,1),(7,-1),(14,-1)],
 [(5,1),(8,-1),(11,1)],[(6,1),(9,-1),(12,1)],
 [(0,1),(4,1),(8,-1),(10,-1),(12,-1)],
 [(0,1),(5,1),(7,-1),(9,1),(13,1)],
 [(1,1),(3,1),(7,-1),(11,-1),(12,1)],
 [(1,1),(5,-1),(6,1),(10,-1),(14,-1)],
 [(2,1),(3,1),(8,-1),(9,-1),(14,1)],
 [(2,1),(4,-1),(6,1),(11,1),(13,1)]]

def edge(i,j):
    return [int(j==k)-int(i==k) for k in range(1,5)]
def form(i,j,k,l):
    a,b=edge(i,j),edge(k,l)
    return [a[r]*b[s]-a[s]*b[r] for r,s in combinations(range(4),2)]
forms=[form(*t) for t in labels]
for rel in relations:
    assert all(sum(sign*forms[i][j] for i,sign in rel)==0 for j in range(6))

def allowed(mask):
    for rel in relations:
        signs=[s*(1 if mask&(1<<i) else -1) for i,s in rel]
        if all(s==signs[0] for s in signs):return False
    return True
admissible={q for q in range(1<<15) if allowed(q)}
assert len(admissible)==1920

def det(a,b,c):
    return a[0]*(b[1]*c[2]-b[2]*c[1])-a[1]*(b[0]*c[2]-b[2]*c[0])+a[2]*(b[0]*c[1]-b[1]*c[0])
def get_mask(v):
    out=0
    for k,(i,j,r,s) in enumerate(labels):
        a,b,c,d=v[i-1],v[j-1],v[r-1],v[s-1]
        t=det(a,b,v[5])*det(c,d,v[6])-det(a,b,v[6])*det(c,d,v[5])
        assert t
        if t>0:out|=1<<k
    return out

examples=json.loads(Path('nine_rational_examples.json').read_text());assert len(examples)==9
seen=set();sizes=[]
for ex in examples:
    v=[tuple(Q(x) for x in col) for col in ex['columns']]
    assert all(det(*(v[i] for i in t)) for t in combinations(range(7),3))
    assert all(det(v[i],v[5],v[6])>0 for i in range(5))
    assert get_mask(v)==ex['pattern']
    orb=set()
    for perm in permutations(range(5)):
        p=[v[i] for i in perm]+v[5:]
        assert all(det(*(p[i] for i in t)) for t in combinations(range(7),3))
        mask=get_mask(p)
        orb.add(mask);orb.add(mask^((1<<15)-1))
    assert len(orb)==ex['orbit_size'] and not (orb&seen)
    seen|=orb;sizes.append(len(orb))
assert seen==admissible
print('PASS 16 exact universal identities, 1920 feasible masks among 32768')
print('PASS nine exact generic matrix examples and relabelings realize every mask; orbit sizes',sizes)
