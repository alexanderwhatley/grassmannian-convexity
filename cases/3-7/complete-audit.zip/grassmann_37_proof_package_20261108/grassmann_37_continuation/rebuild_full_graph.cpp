// Independent reconstruction of the full-intersection-order sign graph.
// See README: this is a finite sign over-approximation, not a realization claim.
// Compile: c++ -O3 -std=c++17 -pthread rebuild_full_graph.cpp -o rebuild_full_graph
#include "affine_circuit_filter16.hpp"
#include <algorithm>
#include <array>
#include <atomic>
#include <cassert>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iostream>
#include <map>
#include <numeric>
#include <random>
#include <string>
#include <thread>
#include <tuple>
#include <vector>
using namespace std;
using Word10=array<int8_t,20>;
using Word12=array<int8_t,24>;
using P=array<int,3>;using F4=array<int,4>;
const F4 flab[15]={{1,2,3,4},{1,3,2,4},{1,4,2,3},{1,2,3,5},{1,3,2,5},
 {1,5,2,3},{1,2,4,5},{1,4,2,5},{1,5,2,4},{1,3,4,5},
 {1,4,3,5},{1,5,3,4},{2,3,4,5},{2,4,3,5},{2,5,3,4}};
vector<P> ps;int pid[8][8][8];vector<pair<int,int>> es;int eid[8][8];
map<F4,int> fid;
vector<pair<unsigned,unsigned>> direction_patterns;
using Pairing=array<pair<int,int>,3>;
vector<Pairing> extras,allpair;

struct Expr { int a=-1,b=-1,sign=0; };
struct Event { int target; Expr d; int move; };
vector<Event> events;
int inv3(int a,int b,int c){return (a>b)+(a>c)+(b>c);}
Expr feature_expr(int a,int b,int c,int d){
 if(a==b||c==d)return {};
 int sg=1;
 if(a>b){swap(a,b);sg=-sg;}if(c>d){swap(c,d);sg=-sg;}
 if(pair<int,int>{a,b}>pair<int,int>{c,d}){swap(a,c);swap(b,d);sg=-sg;}
 if(a==6||b==6||c==6||d==6){
   if(c==6||d==6){swap(a,c);swap(b,d);sg=-sg;}
   assert(b==6&&a<6&&c<d&&d<6);
   return {pid[a][6][7],pid[c][d][6],-sg};
 }
 int common=0;
 if(a==c||a==d)common=a;else if(b==c||b==d)common=b;
 if(common){
   if(b==common){swap(a,b);sg=-sg;}
   if(d==common){swap(c,d);sg=-sg;}
   assert(a==c);if(b==d)return {};
   int x=a,y=b,z=d;int parity=inv3(x,y,z);array<int,3> q={x,y,z};sort(q.begin(),q.end());
   return {pid[a][6][7],pid[q[0]][q[1]][q[2]],sg*((parity&1)?-1:1)};
 }
 return {35+fid.at({a,b,c,d}),-1,sg};
}
void init(){
 memset(pid,-1,sizeof(pid));memset(eid,-1,sizeof(eid));
 for(int a=1;a<=7;a++)for(int b=a+1;b<=7;b++)for(int c=b+1;c<=7;c++){
   pid[a][b][c]=ps.size();ps.push_back({a,b,c});}
 assert(ps.size()==35);
 for(int a=1;a<=5;a++)for(int b=a+1;b<=5;b++){eid[a][b]=es.size();es.push_back({a,b});}
 for(int i=0;i<15;i++)fid[flab[i]]=i;
 for(int j=1;j<=6;j++){
   for(int i=0;i<35;i++){
     auto p=ps[i];bool has=false,block=false;
     for(int v:p){has|=v==j;block|=v==j+1;}if(!has||block)continue;
     for(int&v:p)if(v==j)v=j+1;sort(p.begin(),p.end());
     events.push_back({i,{pid[p[0]][p[1]][p[2]],-1,1},j});
   }
   if(j<=5)for(int i=0;i<15;i++){
     F4 f=flab[i];bool has=false;for(int &x:f)if(x==j){x=j+1;has=true;}
     if(!has)continue;Expr e=feature_expr(f[0],f[1],f[2],f[3]);if(e.sign)events.push_back({35+i,e,j});
   }
 }
}
void pairings(vector<int> rest,vector<pair<int,int>> cur){
 if(rest.empty()){
  Pairing x={cur[0],cur[1],cur[2]};bool old=false;for(auto p:x)old|=p==pair<int,int>{6,7};
  allpair.push_back(x);if(!old)extras.push_back(x);return;
 }
 int a=rest[0];for(size_t i=1;i<rest.size();i++){
  vector<int> next;for(size_t j=1;j<rest.size();j++)if(j!=i)next.push_back(rest[j]);
  auto c=cur;c.push_back({a,rest[i]});pairings(next,c);
 }
}
int oriented_p(uint64_t key,int a,int b,int c){
 int inv=inv3(a,b,c);array<int,3> x={a,b,c};sort(x.begin(),x.end());
 int s=(key>>pid[x[0]][x[1]][x[2]]&1)?1:-1;return inv&1?-s:s;
}
int force_extra(uint64_t key,const Pairing& pp){
 int forced=0;
 for(int r=0;r<3;r++){
  auto [a,b]=pp[r];auto [c,d]=pp[(r+1)%3];auto [e,f]=pp[(r+2)%3];
  int A=oriented_p(key,a,b,e)*oriented_p(key,c,d,f);
  int B=oriented_p(key,a,b,f)*oriented_p(key,c,d,e);
  if(A!=B){if(forced&&forced!=A){cerr<<"inconsistent extra forcing\n";abort();}forced=A;}
 }
 return forced;
}
Expr extra_derivative(Pairing pp,int move){
 int sg=1;bool present=false;
 for(auto& [a,b]:pp){if(a==move){a++;present=true;}else if(b==move){b++;present=true;}
  if(a==b)return {};if(a>b){swap(a,b);sg=-sg;}}
 if(!present)return {};
 int inv=0;for(int i=0;i<3;i++)for(int j=i+1;j<3;j++)inv+=pp[i]>pp[j];if(inv&1)sg=-sg;
 sort(pp.begin(),pp.end());if(pp[0]==pp[1]||pp[1]==pp[2])return {};
 int I=-1,J=-1,q=-1;
 for(int i=0;i<3;i++)for(int j=i+1;j<3;j++){
  int x=pp[i].first==pp[j].first||pp[i].first==pp[j].second?pp[i].first:
        pp[i].second==pp[j].first||pp[i].second==pp[j].second?pp[i].second:-1;
  if(x!=-1){assert(q==-1);I=i;J=j;q=x;}}
 assert(q!=-1);int K=3-I-J;int order[3]={I,J,K};
 inv=(order[0]>order[1])+(order[0]>order[2])+(order[1]>order[2]);if(inv&1)sg=-sg;
 auto a=pp[I],b=pp[J],c=pp[K];
 if(a.second==q){swap(a.first,a.second);sg=-sg;}if(b.second==q){swap(b.first,b.second);sg=-sg;}
 array<int,3> t1={q,a.second,b.second},t2={q,c.first,c.second};
 inv=inv3(t1[0],t1[1],t1[2])+inv3(t2[0],t2[1],t2[2]);if(inv&1)sg=-sg;
 sort(t1.begin(),t1.end());sort(t2.begin(),t2.end());
 return {pid[t1[0]][t1[1]][t1[2]],pid[t2[0]][t2[1]][t2[2]],sg};
}
struct OrderRule {int a,b,c,d,sign1,sign2,feature,m1,m2;};
vector<OrderRule> order_rules;
void init_order(const vector<int>&chosen){
 int mmap[256];fill(mmap,mmap+256,-1);int full=0;for(int k=2;k<=7;k++)full|=1<<k;
 int n=0;for(int x=0;x<256;x++)if(__builtin_popcount(unsigned(x))==3 && (x&~full)==0 && x<=(full^x))mmap[x]=n++;
 assert(n==10);
 auto ppidx=[&](int a,int b,int c){int s=inv3(a,b,c)&1?-1:1;array<int,3> p={a,b,c};sort(p.begin(),p.end());return pair<int,int>{pid[p[0]][p[1]][p[2]],s};};
 vector<pair<Pairing,int>> checks;
 for(auto pp:allpair){bool old=false;for(auto p:pp)old|=p==pair<int,int>{6,7};if(!old)continue;
  auto [a,b]=pp[0];auto [c,d]=pp[1];checks.push_back({pp,35+fid.at({a,b,c,d})});}
 for(size_t k=0;k<chosen.size();k++)checks.push_back({extras[chosen[k]],int(50+k)});
 for(auto [pp,bit]:checks)for(int r=0;r<3;r++){
  auto [a,b]=pp[r];auto [c,d]=pp[(r+1)%3];auto [e,f]=pp[(r+2)%3];
  auto [a1,s1]=ppidx(a,b,e);auto [b1,t1]=ppidx(c,d,f);auto [c1,s2]=ppidx(a,b,f);auto [d1,t2]=ppidx(c,d,e);
  int x=(1<<a)|(1<<b)|(1<<e),y=(1<<a)|(1<<b)|(1<<f);
  int m1=mmap[min(x,full^x)],m2=mmap[min(y,full^y)];assert(m1>=0&&m2>=0&&m1!=m2);
  order_rules.push_back({a1,b1,c1,d1,s1*t1,s2*t2,bit,m1,m2});
 }
}
bool consistent_extras(uint64_t key){
 uint16_t graph[10]={};
 for(const auto&r:order_rules){
  int sg=(key>>r.feature&1)?1:-1;
  int s1=r.sign1*((key>>r.a&1)?1:-1)*((key>>r.b&1)?1:-1);
  int s2=r.sign2*((key>>r.c&1)?1:-1)*((key>>r.d&1)?1:-1);
  if(s1!=s2){if(sg!=s1)return false;continue;}
  if(sg==s1)graph[r.m1]|=1u<<r.m2;else graph[r.m2]|=1u<<r.m1;
 }
 for(int k=0;k<10;k++)for(int i=0;i<10;i++)if(graph[i]&(1u<<k))graph[i]|=graph[k];
 for(int i=0;i<10;i++)if(graph[i]&(1u<<i))return false;
 return true;
}
bool pass3(unsigned q){
 const int triples[10][3]={{1,-4,7},{1,-12,15},{2,-5,10},{2,-9,-14},
  {3,-6,-13},{3,-8,11},{4,-11,14},{5,-8,-15},{6,-9,12},{7,-10,13}};
 for(auto& rel:triples){int v=0;for(int x:rel){int s=(q>>(abs(x)-1)&1)?1:-1;v+=(x>0?s:-s);}if(abs(v)==3)return false;}
 return true;
}
vector<Word10> direction_types(bool filtered){
 int kind[10][10]={},id[10][10]={};map<P,int> tids;int count=0;
 for(int a=1;a<=5;a++)for(int b=a+1;b<=5;b++)for(int c=b+1;c<=5;c++)tids[{a,b,c}]=count++;
 for(int a=0;a<10;a++)for(int b=a+1;b<10;b++){
   auto [i,j]=es[a];auto [k,l]=es[b];
   if(i==k||i==l||j==k||j==l){vector<int> u={i,j,k,l};sort(u.begin(),u.end());
     u.erase(unique(u.begin(),u.end()),u.end());kind[a][b]=1;id[a][b]=tids.at({u[0],u[1],u[2]});}
   else {kind[a][b]=2;id[a][b]=fid.at({i,j,k,l});}
 }
 vector<Word10> out;
 for(unsigned f=0;f<(1u<<15);f++){
  if(!pass3(f)||(filtered&&!gc37_pass_circuits16(31,f)))continue;
  for(unsigned t=0;t<(1u<<10);t++){
   int s[10][10]={};for(int a=0;a<10;a++)for(int b=a+1;b<10;b++){
    unsigned q=kind[a][b]==1?t:f;s[a][b]=(q>>id[a][b]&1)?1:-1;s[b][a]=-s[a][b];}
   int side[10]={},rank[10]={},at[9]={},pos[10]={};bool okay=true;
   for(int a=1;a<10;a++)side[a]=s[0][a];
   for(int a=1;a<10;a++)for(int b=a+1;b<10;b++){
    int v=side[a]*side[b]*s[a][b];if(v>0)rank[b]++;else rank[a]++;}
   for(int a=1;a<10;a++){if(rank[a]>=9||at[rank[a]]){okay=false;break;}at[rank[a]]=a;}
   if(!okay)continue;
   pos[0]=0;for(int r=0;r<9;r++){int a=at[r];pos[a]=1+r+(side[a]<0?10:0);}
   for(int a=0;a<10&&okay;a++)for(int b=a+1;b<10;b++){
    int delta=(pos[b]-pos[a]+20)%20;if((delta<10?1:-1)!=s[a][b]){okay=false;break;}}
   if(!okay)continue;
   Word10 w{};w[0]=1;for(int r=0;r<9;r++)w[r+1]=side[at[r]]*(at[r]+1);
   for(int i=0;i<10;i++)w[i+10]=-w[i];out.push_back(w);direction_patterns.push_back({f,t});
  }
 }
 return out;
}
vector<Word12> add_axes(const Word10& w){
 vector<Word12> out;out.reserve(220);
 for(int g=0;g<20;g++){
  vector<int8_t> v;v.reserve(22);
  for(int k=0;k<20;k++){v.push_back(w[k]);if(k==g)v.push_back(11);if(k==(g+10)%20)v.push_back(-11);}
  int at=find(v.begin(),v.end(),11)-v.begin();
  for(int a=0;a<11;a++){
   int h=(at+a)%22;Word12 z{};int n=0;
   for(int k=0;k<22;k++){z[n++]=v[k];if(k==h)z[n++]=12;if(k==(h+11)%22)z[n++]=-12;}
   assert(n==24&&z[0]==1);for(int k=0;k<12;k++)assert(z[k+12]==-z[k]);
   out.push_back(z);
  }
 }
 assert(out.size()==220);return out;
}
int dirsign(const int* pos,int a,int b){int d=(pos[b]-pos[a]+24)%24;assert(d!=0&&d!=12);return d<12?1:-1;}
uint64_t word_key(const Word12& w){
 int pos[13]={};for(int i=0;i<24;i++)if(w[i]>0)pos[w[i]]=i;
 assert(dirsign(pos,11,12)>0);uint64_t key=0;
 for(int m=0;m<35;m++){
   auto p=ps[m];int a=p[0],b=p[1],c=p[2],s;
   if(c<=5)s=dirsign(pos,eid[a][b]+1,eid[a][c]+1);
   else if(b<=5)s=dirsign(pos,eid[a][b]+1,c==6?11:12);
   else s=1;
   if(s>0)key|=1ull<<m;
 }
 for(int m=0;m<15;m++){
   auto f=flab[m];int s=dirsign(pos,eid[f[0]][f[1]]+1,eid[f[2]][f[3]]+1);
   if(s>0)key|=1ull<<(35+m);
 }
 return key;
}
array<uint64_t,16> sign_masks(){
 array<uint64_t,16> out{};
 for(int x=0;x<16;x++){
  for(int i=0;i<35;i++){int mask=0;for(int v:ps[i])if(v<=4)mask|=1<<(v-1);if(__builtin_parity(mask&x))out[x]|=1ull<<i;}
  for(int i=0;i<15;i++){int mask=0;for(int v:flab[i])if(v<=4)mask|=1<<(v-1);if(__builtin_parity(mask&x))out[x]|=1ull<<(35+i);}
 }
 return out;
}
uint64_t mix(uint64_t z){z=(z^(z>>30))*0xbf58476d1ce4e5b9ULL;z=(z^(z>>27))*0x94d049bb133111ebULL;return z^(z>>31);}
struct Hash {
 uint64_t cap;vector<uint64_t> k;vector<uint32_t> v;
 explicit Hash(uint64_t c):cap(c),k(c,0),v(c,0){}
 void insert(uint64_t key,uint32_t value){assert(key);uint64_t i=mix(key)&(cap-1);while(k[i]){if(k[i]==key){cerr<<"duplicate key\n";abort();}i=(i+1)&(cap-1);}k[i]=key;v[i]=value;}
 uint32_t find(uint64_t key)const{uint64_t i=mix(key)&(cap-1);while(k[i]){if(k[i]==key)return v[i];i=(i+1)&(cap-1);}return UINT32_MAX;}
};
bool eligible(uint64_t key,const Event&e){
 int s=(key>>e.target&1)?1:-1;
 int d=e.d.sign*((key>>e.d.a&1)?1:-1);
 if(e.d.b>=0)d*=((key>>e.d.b&1)?1:-1);
 return s!=d;
}
using V3=array<long long,3>;
long long det3(const V3&a,const V3&b,const V3&c){return a[0]*(b[1]*c[2]-b[2]*c[1])-a[1]*(b[0]*c[2]-b[2]*c[0])+a[2]*(b[0]*c[1]-b[1]*c[0]);}
array<long long,62> exact_values(const array<V3,7>&v,const vector<int>&chosen){
 array<long long,62> out{};auto p=[&](int a,int b,int c){return det3(v[a-1],v[b-1],v[c-1]);};
 for(int i=0;i<35;i++)out[i]=p(ps[i][0],ps[i][1],ps[i][2]);
 for(int i=0;i<15;i++){auto [a,b,c,d]=flab[i];out[35+i]=p(a,b,6)*p(c,d,7)-p(a,b,7)*p(c,d,6);}
 for(size_t i=0;i<chosen.size();i++){auto [a,b]=extras[chosen[i]][0];auto [c,d]=extras[chosen[i]][1];auto [e,f]=extras[chosen[i]][2];
   out[50+i]=p(a,b,e)*p(c,d,f)-p(a,b,f)*p(c,d,e);}
 return out;
}
void audit_actual(const Hash&H,const vector<int>&chosen){
 mt19937 rng(37026);uniform_int_distribution<int> pick(-24,24);int accepted=0;uint64_t checked=0;
 while(accepted<10000){
  array<V3,7> v;for(auto &col:v)for(auto &x:col)x=pick(rng);
  auto raw=exact_values(v,chosen);if(raw[pid[5][6][7]]<0){for(auto&col:v)col[0]=-col[0];raw=exact_values(v,chosen);}
  int len=50+chosen.size();bool good=true;for(int i=0;i<len;i++)good&=raw[i]!=0;if(!good)continue;
  uint64_t key=0;for(int i=0;i<len;i++)if(raw[i]>0)key|=1ull<<i;
  if(H.find(key)==UINT32_MAX){cerr<<"real generic state missing from graph\n";abort();}
  for(int j=1;j<=6;j++){
   auto v1=v,v2=v;for(int k=0;k<3;k++){v1[j-1][k]+=v[j][k];v2[j-1][k]+=2*v[j][k];}
   auto r1=exact_values(v1,chosen),r2=exact_values(v2,chosen);
   for(int i=0;i<len;i++){
    long long delta=r1[i]-raw[i];if(r2[i]-2*r1[i]+raw[i]!=0){cerr<<"nonlinear event\n";abort();}
    const Event* ev=nullptr;for(const auto&e:events)if(e.target==i&&e.move==j){ev=&e;break;}
    if(!ev){if(delta){cerr<<"missing active event "<<i<<" "<<j<<"\n";abort();}continue;}
    int s=ev->d.sign*((key>>ev->d.a&1)?1:-1);if(ev->d.b>=0)s*=((key>>ev->d.b&1)?1:-1);
    if((delta>0)-(delta<0)!=s){cerr<<"incorrect derivative "<<i<<" "<<j<<"\n";abort();}
    checked++;
   }
  }
  accepted++;
 }
 cout<<"PASS exact membership and "<<checked<<" active derivative signs for "<<accepted<<" actual matrices\n";
}
int main(int argc,char**argv){
 bool filtered=false,run_scc=false,save_rank=false,dump=false,audit=false,order_filter=false,eventdump=false,wall36=false;vector<int> chosen;
 for(int i=1;i<argc;i++){string a=argv[i];if(a=="filtered")filtered=true;
   else if(a=="scc")run_scc=true;else if(a=="save")save_rank=true;else if(a=="dump")dump=true;
   else if(a=="audit")audit=true;else if(a=="eventdump")eventdump=true;else if(a=="order")order_filter=true;else if(a=="wall36")wall36=true;
   else if(a.rfind("extra",0)==0)chosen.push_back(stoi(a.substr(5)));else {cerr<<"unknown arg "<<a<<"\n";return 2;}}
 int nthreads=8;
 init();pairings({2,3,4,5,6,7},{});assert(extras.size()==12);if(order_filter)init_order(chosen);
 assert(chosen.size()<=4);for(size_t i=0;i<chosen.size();i++){assert(chosen[i]>=0&&chosen[i]<12);
  for(int j=1;j<=6;j++){Expr e=extra_derivative(extras[chosen[i]],j);if(e.sign)events.push_back({int(50+i),e,j});}}
 array<uint64_t,54> wallmask{};array<vector<uint64_t>,54> wallvalues;
 if(wall36){
  if(chosen!=vector<int>({2,3,7,8})||!filtered||!order_filter){cerr<<"wall36 requires filtered extra2 extra3 extra7 extra8 order\n";return 2;}
  ifstream in("wall36_guards.txt");int bit;uint64_t mask,value;int n=0;
  while(in>>bit>>mask>>value){assert(bit>=0&&bit<54&&!(mask&(1ull<<bit))&&(value&~mask)==0);
   assert(!wallmask[bit]||wallmask[bit]==mask);wallmask[bit]=mask;wallvalues[bit].push_back(value);n++;}
  if(n!=512){cerr<<"expected 512 wall36 guards, got "<<n<<"\n";return 2;}
  for(auto& v:wallvalues){sort(v.begin(),v.end());assert(unique(v.begin(),v.end())==v.end());}
 }
 if(eventdump){ofstream out("event_table.txt");for(const auto&e:events)out<<e.move<<" "<<e.target<<" "<<e.d.a<<" "<<e.d.b<<" "<<e.d.sign<<"\n";return 0;}
 auto start=chrono::steady_clock::now();
 cerr<<"generating directions, filtered="<<filtered<<" events="<<events.size()<<"\n";
 auto dirs=direction_types(filtered);cerr<<"directions="<<dirs.size()<<"\n";
 if(dump){ofstream f(filtered?"directions_filtered.txt":"directions_unfiltered.txt");
   for(auto [a,b]:direction_patterns)f<<a<<" "<<b<<"\n";return 0;}
 auto masks=sign_masks();uint64_t expected=dirs.size()*220ull*16;
 Hash H(1ull<<(chosen.empty()?25:26));vector<uint64_t> keys;keys.reserve(expected*(chosen.empty()?1:2));
 for(auto&w:dirs){for(auto&z:add_axes(w)){uint64_t b=word_key(z);for(int x=0;x<16;x++){
   uint64_t base=b^masks[x];
   for(unsigned opt=0;opt<(1u<<chosen.size());opt++){
    uint64_t key=base;bool okay=true;
    for(size_t i=0;i<chosen.size();i++){
     int forced=force_extra(base,extras[chosen[i]]),s=(opt>>i&1)?1:-1;
     if(forced&&forced!=s){okay=false;break;}if(s>0)key|=1ull<<(50+i);
    }
    if(okay&&order_filter)okay=consistent_extras(key);
    if(okay){H.insert(key,keys.size());keys.push_back(key);}
   }
 }}}
 if(chosen.empty()&&!order_filter)assert(keys.size()==expected);else cerr<<"extra features="<<chosen.size()<<" retained states="<<keys.size()<<" vs old="<<expected<<" order="<<order_filter<<"\n";
 if(audit){audit_actual(H,chosen);return 0;}
 cerr<<"states="<<keys.size()<<" building arcs\n";
 vector<uint8_t> degrees(keys.size(),0);vector<vector<uint32_t>> chunks(nthreads);
 vector<thread> threads;atomic<int> done{0};atomic<uint64_t> rejected{0};uint32_t target=pid[1][2][3];
 for(int thread=0;thread<nthreads;thread++)threads.emplace_back([&,thread](){
   size_t lo=keys.size()*thread/nthreads,hi=keys.size()*(thread+1)/nthreads;
   auto& out=chunks[thread];out.reserve((hi-lo)*8);uint64_t blocked=0;
   for(size_t i=lo;i<hi;i++){
    uint64_t key=keys[i],candidate=0;unsigned degree=0;
    for(const auto&e:events)if(eligible(key,e))candidate|=1ull<<e.target;
    while(candidate){
      int bit=__builtin_ctzll(candidate);candidate&=candidate-1;
      uint32_t dest=H.find(key^(1ull<<bit));
      if(dest!=UINT32_MAX){
       if(wall36&&wallmask[bit]&&binary_search(wallvalues[bit].begin(),wallvalues[bit].end(),key&wallmask[bit])){blocked++;continue;}
       out.push_back(dest|((bit==int(target))?0x80000000u:0u));degree++;}
    }
    assert(degree<256);degrees[i]=degree;
   }
   rejected+=blocked;cerr<<"thread done "<<++done<<"/"<<nthreads<<" arcs="<<out.size()<<" blocked="<<blocked<<"\n";
 });
 for(auto&t:threads)t.join();uint64_t m=0;for(auto&v:chunks)m+=v.size();
 uint64_t weighted=0;for(auto&v:chunks)for(auto x:v)weighted+=(x>>31);
 cerr<<"arcs="<<m<<" weighted="<<weighted<<" seconds="<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<"\n";
 cout<<"states "<<keys.size()<<" edges "<<m<<" target_edges "<<weighted<<" wall36_blocked "<<rejected<<"\n";
 if(!run_scc)return 0;
 assert(m<UINT32_MAX);uint32_t n=keys.size();
 vector<uint64_t>().swap(H.k);vector<uint32_t>().swap(H.v);if(!save_rank)vector<uint64_t>().swap(keys);
 vector<uint32_t> off(n+1,0);for(uint32_t i=0;i<n;i++)off[i+1]=off[i]+degrees[i];assert(off[n]==m);
 vector<uint32_t> arcs;arcs.reserve(m);
 for(auto&v:chunks){arcs.insert(arcs.end(),v.begin(),v.end());vector<uint32_t>().swap(v);}
 vector<uint32_t> rev(n+1,0);
 for(uint32_t e:arcs)rev[(e&0x7fffffffu)+1]++;
 for(uint32_t i=0;i<n;i++)rev[i+1]+=rev[i];assert(rev[n]==m);
 vector<uint32_t> revcur=rev,r_arcs(m);
 for(uint32_t u=0;u<n;u++)for(uint32_t e=off[u];e<off[u+1];e++){
   uint32_t v=arcs[e]&0x7fffffffu;r_arcs[revcur[v]++]=u;}
 vector<uint32_t>().swap(revcur);
 cerr<<"reverse graph built; starting forward DFS\n";
 vector<uint8_t> visited(n,0),next(n,0);vector<uint32_t> order,stack;
 order.reserve(n);
 for(uint32_t root=0;root<n;root++)if(!visited[root]){
  visited[root]=1;stack.push_back(root);
  while(!stack.empty()){
   uint32_t u=stack.back();
   if(next[u]<degrees[u]){
    uint32_t v=arcs[off[u]+next[u]++]&0x7fffffffu;
    if(!visited[v]){visited[v]=1;stack.push_back(v);}
   }else{stack.pop_back();order.push_back(u);}
  }
 }
 assert(order.size()==n);vector<uint8_t>().swap(visited);vector<uint8_t>().swap(next);
 cerr<<"forward DFS complete; starting reverse DFS\n";
 vector<uint32_t> comp(n,UINT32_MAX);uint32_t count=0,largest=0;
 for(uint64_t z=n;z>0;z--){uint32_t root=order[z-1];if(comp[root]!=UINT32_MAX)continue;
  uint32_t size=0;comp[root]=count;stack.push_back(root);
  while(!stack.empty()){
   uint32_t u=stack.back();stack.pop_back();size++;
   for(uint32_t e=rev[u];e<rev[u+1];e++){uint32_t v=r_arcs[e];if(comp[v]==UINT32_MAX){comp[v]=count;stack.push_back(v);}}
  }
  largest=max(largest,size);count++;
 }
 vector<uint32_t>().swap(order);vector<uint32_t>().swap(stack);vector<uint32_t>().swap(rev);vector<uint32_t>().swap(r_arcs);
 cerr<<"SCCs="<<count<<" largest="<<largest<<"; computing rank\n";
 vector<uint32_t> coff(count+1,0);for(uint32_t c:comp)coff[c+1]++;
 for(uint32_t c=0;c<count;c++)coff[c+1]+=coff[c];
 vector<uint32_t> fill=coff,members(n);
 for(uint32_t u=0;u<n;u++)members[fill[comp[u]]++]=u;
 vector<uint32_t>().swap(fill);vector<uint8_t> rank(count,0);
 for(uint64_t zz=count;zz>0;zz--){uint32_t c=zz-1;unsigned best=0;
  for(uint32_t k=coff[c];k<coff[c+1];k++){
   uint32_t u=members[k];
   for(uint32_t e=off[u];e<off[u+1];e++){
    uint32_t x=arcs[e],v=x&0x7fffffffu,weight=x>>31,d=comp[v];
    if(d==c){if(weight){cerr<<"positive cycle in abstract graph\n";return 3;}}
    else {if(d<c){cerr<<"SCC order error\n";return 4;}best=max(best,weight+rank[d]);}
   }
  }
  if(best>255){cerr<<"rank exceeds byte\n";return 5;}rank[c]=best;
 }
 unsigned maxrank=*max_element(rank.begin(),rank.end());
 cout<<"SCCs "<<count<<" largest "<<largest<<" abstract maximum "<<maxrank<<"\n";
 if(save_rank){
  string tag;for(int v:chosen)tag+="_"+to_string(v);if(order_filter)tag+="_order";if(wall36)tag+="_wall36";
  string filename=!tag.empty()?"extra"+tag+"_rank.bin":filtered?"filtered_rank.bin":"unfiltered_rank.bin";ofstream f(filename,ios::binary);
  for(uint32_t u=0;u<n;u++){char x=rank[comp[u]];f.write(&x,1);}assert(f.good());
  cout<<"saved "<<filename<<" bytes "<<n<<"\n";
  // Find an explicit abstract maximizing path, including zero-weight moves
  // inside strongly connected components. This is not a matrix trajectory.
  uint32_t cur=0;while(cur<n&&rank[comp[cur]]!=maxrank)cur++;assert(cur<n);
  vector<uint32_t> stamp(n,0),previous(n,UINT32_MAX),queue;uint32_t epoch=0;
  vector<pair<uint32_t,uint32_t>> walk;unsigned guard=0;
  while(rank[comp[cur]]>0){
   if(++guard>1000000){cerr<<"path reconstruction overflow\n";return 6;}
   uint32_t c=comp[cur],need=rank[c],exit_u=UINT32_MAX,exit_v=UINT32_MAX;
   epoch++;queue.clear();queue.push_back(cur);stamp[cur]=epoch;size_t qi=0;
   while(qi<queue.size()&&exit_u==UINT32_MAX){
    uint32_t u=queue[qi++];
    for(uint32_t e=off[u];e<off[u+1];e++){
     uint32_t x=arcs[e],v=x&0x7fffffffu,weight=x>>31,d=comp[v];
     if(d!=c && unsigned(rank[d])+weight==need){exit_u=u;exit_v=v;break;}
     if(d==c&&stamp[v]!=epoch){stamp[v]=epoch;previous[v]=u;queue.push_back(v);}
    }
   }
   if(exit_u==UINT32_MAX){cerr<<"rank path cannot leave SCC\n";return 7;}
   vector<uint32_t> back;for(uint32_t v=exit_u;v!=cur;v=previous[v])back.push_back(v);
   reverse(back.begin(),back.end());for(uint32_t v:back){walk.push_back({cur,v});cur=v;}
   walk.push_back({cur,exit_v});cur=exit_v;
  }
  string pathfile=!tag.empty()?"extra"+tag+"_path.txt":filtered?"filtered_path14.txt":"unfiltered_path14.txt";ofstream p(pathfile);
  unsigned target_count=0;
  for(auto [u,v]:walk){uint64_t diff=keys[u]^keys[v];assert(__builtin_popcountll(diff)==1);
   int bit=__builtin_ctzll(diff),move=0;for(const auto&e:events)if(e.target==bit&&eligible(keys[u],e)){move=e.move;break;}
   assert(move);target_count+=bit==int(target);
   p<<keys[u]<<" "<<keys[v]<<" "<<bit<<" "<<move<<"\n";
  }
  assert(target_count==maxrank&&p.good());
  cout<<"saved "<<pathfile<<" edges "<<walk.size()<<" target_changes "<<target_count<<"\n";
 }
 return 0;
}
