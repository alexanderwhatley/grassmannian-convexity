// Separate rank-inequality checker for the 16-filter graph.
// The state generator is shared; this checker does not use the SCC code.
// Event derivatives are read from event_table.txt and verified symbolically by
// verify_event_table_symbolic.py. Compile with C++17, -O3 and -pthread.
#define main graph_main_not_used
#include "rebuild_full_graph.cpp"
#undef main

int main(){
 init();auto dirs=direction_types(true);assert(dirs.size()==4560);
 auto masks=sign_masks();uint64_t n=dirs.size()*220ull*16;
 Hash H(1ull<<25);vector<uint64_t> keys;keys.reserve(n);
 for(auto&w:dirs)for(auto&z:add_axes(w)){uint64_t b=word_key(z);for(int x=0;x<16;x++){
  uint64_t k=b^masks[x];H.insert(k,keys.size());keys.push_back(k);
 }}
 assert(keys.size()==n);
 vector<uint8_t> rank(n);ifstream file("filtered_rank.bin",ios::binary);
 file.read(reinterpret_cast<char*>(rank.data()),n);assert(file.gcount()==int64_t(n));
 char extra;assert(!file.read(&extra,1));
 struct Test{int move,target,a,b,sg;};vector<Test> tests;
 ifstream efile("event_table.txt");Test t;
 while(efile>>t.move>>t.target>>t.a>>t.b>>t.sg)if(t.target<50)tests.push_back(t);
 assert(tests.size()==108);
 atomic<uint64_t> tested{0},weighted{0};vector<thread> threads;
 for(int th=0;th<8;th++)threads.emplace_back([&,th](){
  uint64_t nt=0,nw=0;size_t lo=n*th/8,hi=n*(th+1)/8;
  for(size_t u=lo;u<hi;u++){
   uint64_t k=keys[u];assert(rank[u]<=14);
   for(auto e:tests){
    int tgt=(k>>e.target&1)?1:-1,der=e.sg*((k>>e.a&1)?1:-1);
    if(e.b>=0)der*=((k>>e.b&1)?1:-1);
    if(tgt==der)continue;
    uint32_t v=H.find(k^(1ull<<e.target));if(v==UINT32_MAX)continue;
    unsigned w=e.target==pid[1][2][3];
    if(unsigned(rank[u])<unsigned(rank[v])+w){cerr<<"bad rank at "<<u<<" -> "<<v<<"\n";abort();}
    nt++;nw+=w;
   }
  }
  tested+=nt;weighted+=nw;
 });
 for(auto&th:threads)th.join();
 cout<<"PASS rank inequalities on "<<tested<<" move-labeled transitions; target-labeled "<<weighted<<"; max rank "<<int(*max_element(rank.begin(),rank.end()))<<"\n";
}
