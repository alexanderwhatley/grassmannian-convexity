# The cubic-filtered 52-sign graph

The existing data-free 52-sign proof does **not** need the strengthening below. It is an additional structural result: adding a necessary cubic sign rule removes every formal negative-target terminal trap and makes the exact abstract rank have target-sign parity everywhere. The graph is still an over-approximation of real trajectories.

## The rule

For any six distinct indices grouped as ordered pairs \((a,b),(c,d),(e,f)\), set
\[
F_{ab,cd}^{ef}=p_{abe}p_{cdf}-p_{abf}p_{cde}.
\]
The exact identity
\[
p_{ade}F_{ab,cd}^{ef}
 =p_{abe}p_{acd}p_{def}+p_{abd}p_{aef}p_{cde}\tag{1}
\]
implies that if the two terms on the right have the same sign, the sign of \(F\) is forced. Apply the rule to the 15 original F features and \(G_{56},G_{57}\), in all six pair permutations and all eight within-pair orientations: 816 oriented rules. The sign under a pair permutation is its parity, multiplied by \(-1\) for each reversed pair.

`standalone_cubic_strong.cpp` checks (1) symbolically for formal six-column variables and verifies all 48 orientation identities; relabeling covers all 17 features. `cubic_all_filter.hpp` compiles the tests to 272 distinct parity rules. The separate `audit_cubic_all_filter.cpp` reconstructs all 816 oriented sign expressions independently and checks that they are exactly the compiled 272 rules; it also compares them on 120,000 abstract sign assignments.

## Exhaustive result

With all 816 necessary rules imposed, an independently reconstructed graph has:

| Object | Count |
|---|---:|
| Admissible 52-sign states | 22,667,264 |
| Distinct directed feature-flip edges | 141,639,888 |
| Strongly connected components | 760,528 |
| Original-feature move-labeled edges | 205,457,664 |
| G-feature move-labeled edges | 19,848,192 |

The SCC algorithm rejects a positive target-weight edge inside an SCC, verifies topological order, and constructs the exact longest-target-path rank \(H_{\rm cub}\). Its maximum is 12. A separate final loop checks the rank inequality directly on **all 225,305,856 move-labeled edges** and verifies
\[
0\le H_{\rm cub}(s)\le8+m(s)
\]
on every admitted state. The maxima for \(m=0,1,2,3,4\) are respectively 8, 9, 10, 11, 12. The earlier unfiltered, standalone proof already gives the same real-matrix bound, so neither the cubic rule nor these computations are a dependency of that proof.

Exactly 12 states have \(H_{\rm cub}=0\). They are **exactly** the 12 admitted states with all 35 maximal minors positive; their G signs are \(G_{56},G_{57},G_{67}>0\). Each terminal state has its own exact rational realization, obtained by alternating-column reorientation of one of the 12 previously verified rational \(H=12\) representatives. `verify_cubic_zero_representatives.py` checks this bijection by exact fractions. These are static realizations; no extra trajectory-realizability claim follows.

On every one of the 22,667,264 admitted states,
\[
H_{\rm cub}(s)\equiv[p_{123}(s)<0]\pmod 2.\tag{2}
\]
The direct loop checks (2). It also follows conceptually from the exact graph-rank construction: a path attaining the optimal rank can be taken to a zero-rank state, all such states have \(p_{123}>0\), and each counted edge flips that sign.

For comparison with the previous graph, 579,584 of its 23,246,848 states are removed. All 25,519 previous parity mismatches were negative-target \(H=0\) states, and all are removed. The other 554,065 removed states had the correct parity. On **every surviving state**, the exact cubic-filtered rank equals the old exact graph rank; the stronger static filter improves the terminal interpretation, but gives no smaller upper rank on a state it retains.

This is not a 51-sign simplification: separately checked abstract 14-crossing paths survive either one-G-sign projection even when all 816 cubic rules hold at both endpoints of each edge for a common hidden sign. See `one_feature_projection_obstructions.md`.

## Reproduction and scope

From this folder, with GCC or Clang and Python 3:

```sh
c++ -O3 -std=c++17 -pthread standalone_cubic_strong.cpp -o standalone_cubic_strong
GC37_DUMP_KEYS=keys_by_sorted_key_le64.bin ./standalone_cubic_strong
c++ -O3 -std=c++17 -pthread audit_cubic_all_filter.cpp -o audit_cubic_all_filter
./audit_cubic_all_filter
python3 verify_cubic_zero_representatives.py
```

The C++ graph program reads no input files; the optional environment variable writes the sorted key stream for the terminal-realization check. It also writes `cubic_H_sorted.bin`, one byte per sorted base key and G-sign code, with 255 denoting an inadmissible lift. The rational check additionally reads the saved 12 matrices in `../sector_agent/rank14_rational_matrices.jsonl` and uses NumPy. For the comparison to the prior graph, run `sort_old_h_by_key.cpp` against the saved `../new_work/augmented_optimal_rank.bin`, then `compare_cubic_and_old_h.py`.

Checksums for the audited sources and result:

```text
443e18ca99c451f3cf0b1b4c96880cf831718efe53687e83fb4b1490a72d5326  standalone_cubic_strong.cpp
5b318cbd15b0b6bd0499365e6791b06b93ebc0b0a9fba0b3021bfa127f4f6b8a  cubic_all_filter.hpp
21a9c33b9cbb3072104fce06787bf3b7e8767487ca26cec5a0ea656439294ca5  cubic_H_sorted.bin
```

As with the original proof, independent review of the geometric coverage, exact event correspondence and source code remains important. These exact finite results do not constitute independent peer review or a claim that an abstract optimal path is a real trajectory.
