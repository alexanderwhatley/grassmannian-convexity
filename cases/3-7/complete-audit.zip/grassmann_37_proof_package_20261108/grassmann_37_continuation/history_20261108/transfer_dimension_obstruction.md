# At least six shears are generically needed for target transfer

Fix any generic alternating `3`-by-`7` starting matrix `M`. For almost every generic alternating target `N`, there is **no** sequence of five or fewer positive elementary shears taking `M` to `A N Lambda` for some `A in GL_3` and positive diagonal `Lambda`. Thus a uniform construction that transfers to an arbitrary prescribed alternating target, up to these equivalences, needs at least six shears. The previously proved 12-shear transfer remains an upper bound; this argument leaves six through eleven open.

This statement concerns exact target transfer. It is **not** a six-move lower bound for producing twelve target sign changes: a trajectory may realize those changes without transferring to any prescribed target.

## Six explicit target invariants

Multiply alternating column `i` by `(-1)^i`, so the row space becomes a positive Grassmannian point. Use the elementary positive chart from `elementary_positive_chart_and_global_rank.md`:
\[
 E U_4(a_1)U_3(a_2)U_2(a_3)U_1(a_4)
 U_5(a_5)U_4(a_6)U_3(a_7)U_2(a_8)
 U_6(a_9)U_5(a_{10})U_4(a_{11})U_3(a_{12}),
\]
where all parameters are positive. The chart is a diffeomorphism with the full positive Grassmannian.

Right multiplication by `Lambda=diag(lambda_1,...,lambda_7)` changes every factor `U_j(a)` to `U_j(a lambda_j/lambda_{j+1})`, up to a harmless invertible row transformation of `E`. Thus six independent positive ratios `lambda_j/lambda_{j+1}` independently scale all chart factors with generator `j`. One representative parameter for each generator can be normalized to 1, and the remaining six ratios
\[
 \left(\frac{a_8}{a_3},\frac{a_7}{a_2},\frac{a_{12}}{a_2},
       \frac{a_6}{a_1},\frac{a_{11}}{a_1},\frac{a_{10}}{a_5}\right)
 \in(0,\infty)^6\tag{1}
\]
are global smooth coordinates for the quotient by positive column scalings. In particular, two alternating matrices have the same coordinates exactly when they differ by an invertible left row transformation and a positive diagonal column scaling.

## Dimension argument

Fix a word `(j_1,...,j_ell)` with `ell<=5`. Its positive shear parameters lie in `(0,infinity)^ell`. On the open set of parameters where the endpoint remains alternating, form the six coordinates (1). The resulting map to `(0,infinity)^6` is smooth: the endpoint matrix is polynomial in the shear parameters and the chart inverse is rational with nonzero denominators in the alternating chamber.

A smooth map from an open subset of `R^ell` to `R^6`, with `ell<6`, has image of six-dimensional measure zero. For an elementary proof, cover its domain by countably many compact cubes on which the derivative is bounded. A cube subdivided at mesh `delta` yields `O(delta^{-ell})` image sets of diameter `O(delta)`, whose total six-dimensional volume is `O(delta^{6-ell})`, tending to zero. There are only finitely many words of length at most five, so their union still has measure zero. It cannot cover the open six-dimensional target space. This proves the assertion.

More generally, for `0<k<n` the positive Grassmannian has dimension `k(n-k)`. Its positive diagonal action has a one-dimensional scalar stabilizer and hence orbit dimension `n-1`: since every maximal minor is nonzero, a diagonal stabilizer gives the same product on every `k`-subset, and exchanging one index forces all diagonal entries equal. Consequently the quotient dimension is
\[
 k(n-k)-(n-1)=(k-1)(n-k-1).
\]
The same finite-word argument shows that a generic target requires at least that many shears, even when arbitrary positive column scalings and invertible row operations are allowed. The bound can be zero in the projectively trivial cases `k=1` or `n-k=1`.
