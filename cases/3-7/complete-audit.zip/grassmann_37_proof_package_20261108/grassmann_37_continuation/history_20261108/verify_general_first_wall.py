#!/usr/bin/env python3
"""Exact orientation and abstract variation checks of the all-(k,n) lemma."""
from itertools import combinations
from fractions import Fraction
from random import Random
rng=Random(371170)
def det(a):
 n=len(a);a=[x[:] for x in a];s=1;last=1
 for j in range(n-1):
  pivot=next((i for i in range(j,n) if a[i][j]),None)
  if pivot is None:return 0
  if pivot!=j:a[j],a[pivot]=a[pivot],a[j];s=-s
  q=a[j][j]
  for i in range(j+1,n):
   for t in range(j+1,n):a[i][t]=(a[i][t]*q-a[i][j]*a[j][t])//last
  for i in range(j+1,n):a[i][j]=0
  last=q
 return s*a[-1][-1]
def minor(A,I):return det([[row[i-1] for i in I] for row in A])
identities=ratio_cases=variation_cases=0
for n in range(3,9):
 for k in range(1,n):
  P=list(combinations(range(1,n+1),k));K=set(range(1,k+1));neg={I:(1 if sum(I)%2==0 else -1) for I in P}
  neg[tuple(range(1,k+1))]*=-1;variations=[]
  for J in combinations(range(1,n+1),k-1):
   seq=[(-1 if i%2 else 1)*neg[tuple(sorted(J+(i,)))] for i in range(1,n+1) if i not in J]
   v=sum(a!=b for a,b in zip(seq,seq[1:]));variations.append((J,v))
  assert max(v for J,v in variations)==1
  assert all(v==(1 if set(J)<=K else 0) for J,v in variations)
  variation_cases+=1
  if k==1:continue
  A=[[rng.randint(-9,9) for _ in range(n)] for _ in range(k)]
  def D(*I):return minor(A,tuple(sorted(I)))
  # Check exact ordered Plucker signs, including S interleaving all four labels.
  for a in range(1,k):
   for b in range(k+2,n+1):
    rest=sorted(set(range(1,n+1))-{a,k,k+1,b})
    for S in combinations(rest,k-2):
     assert D(*S,a,k+1)*D(*S,k,b)-D(*S,a,k)*D(*S,k+1,b)==D(*S,a,b)*D(*S,k,k+1)
     identities+=1
  # The moment curve has all increasing minors strictly positive.
  def V(I):return prod(j-i for i,j in combinations(I,2))
  from math import prod
  first=tuple(range(1,k));t0=Fraction(V(tuple(sorted(first+(k,)))),V(tuple(sorted(first+(k+1,)))))
  remaining=sorted(set(range(1,n+1))-{k,k+1})
  for I in combinations(remaining,k-1):
   t=Fraction(V(tuple(sorted(I+(k,)))),V(tuple(sorted(I+(k+1,)))))
   assert (t==t0)==(I==first) and (I==first or t>t0)
   ratio_cases+=1
print('PASS',identities,'exact Plucker orientations,',ratio_cases,'positive-plane ratios, and',variation_cases,'general Karp sign patterns')
