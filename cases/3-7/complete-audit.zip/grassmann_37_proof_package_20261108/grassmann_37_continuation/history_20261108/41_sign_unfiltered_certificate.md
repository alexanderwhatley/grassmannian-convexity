# A 41-sign certificate for the `(3,7)` bound

This is a computer-assisted certificate of the pointwise upper bound
\[
 r(M)\leq 8+m(M)\leq12,
\]
where the move is \(v_j\leftarrow v_j+t v_{j+1}\), \(t>0\), the counted sign is that of \(p_{123}=\det(v_1,v_2,v_3)\), and \(m(M)\) is the minimum number of sign changes in the strictly nonzero list \((\omega(v_1),\ldots,\omega(v_7))\). Start and recorded vertices have nonzero maximal minors. Multiplying a row by \(-1\) if necessary, normalize \(p_{567}>0\), which is preserved by every move.

The rank uses only 41 signs: all 35 maximal minors and the six signs
\[
 F_{12,34}^{67},\quad F_{12,45}^{67},\quad F_{13,45}^{67},\quad
 F_{23,45}^{67},\quad F_{12,34}^{56},\quad F_{12,34}^{57},
 \qquad F_{ab,cd}^{ef}=p_{abe}p_{cdf}-p_{abf}p_{cde}.
\]
No cubic sign rule, realizability assumption, trajectory history, or auxiliary data file is needed to construct the rank. All rules applied in the full sign model are necessary, and the smaller graph permits hidden signs to reset between edges. Its paths need not come from real matrices. The proof therefore gives an upper bound; the known exact 28-move witness supplies the matching lower bound 12 separately.

## The finite assertion and its direct check

First construct the same necessary 50-sign set used by the data-free 52-sign checker: the 35 minor signs and the 15 signs \(F_{ab,cd}^{67}\) for the three pairings of each four-subset of \([5]\). For each base sign word retain each pair of \(F_{12,34}^{56}\), \(F_{12,34}^{57}\) signs allowed by the exact Plücker identities in `gvalid`. There are 16,051,200 base keys and 23,246,848 resulting full augmented states.

Forget the 11 old \(F\)-signs outside the six displayed signs. For each **visible** old-feature event, draw a projected directed edge whenever the two states have a common choice of all forgotten signs with an admissible full event. For a visible new \(G\)-event require a common full lift in the same way. A forgotten-only event is a self-step. Different visible edges may choose different hidden lifts, which enlarges the graph. **The 4,960,256 count below is the number of projected potential states, not the whole computation**: building and independently checking the certificate still enumerate the 16,051,200 full base keys and 23,246,848 valid full augmented states.

The resulting graph has:

| Quantity | Count |
|:--|--:|
| Projected base keys | 3,378,432 |
| Projected augmented states | 4,960,256 |
| Distinct directed visible sign-flip edges | 27,866,144 |
| Strongly connected components | 455,402 |
| Target edges inside a component | 0 |
| Maximum number of target edges along an abstract path | 12 |

The exact longest-target-path rank \(H_{41}\) is a nonnegative integer, is at most 12, does not increase on any edge, and decreases by at least one on a target edge. The construction verifies those inequalities directly on every projected edge after computing the SCC ranks. It also checks the sharper bound at **every** projected state:

| \(m\) | Number of projected states | Maximum \(H_{41}\) | States with \(H_{41}>8+m\) |
|--:|--:|--:|--:|
| 0 | 1,705,088 | 8 | 0 |
| 1 | 2,640,169 | 9 | 0 |
| 2 | 601,143 | 10 | 0 |
| 3 | 13,853 | 11 | 0 |
| 4 | 3 | 12 | 0 |

An independent *direct edge check* does not read the projected graph, SCC data, or its edge-generation code. It reads only the 41-sign rank bytes, reconstructs all full 52-sign states and all 114 nonzero feature/move derivative laws, and verifies the rank inequalities on **all 230,629,888 move-labeled full-state edges**. These comprise 209,042,944 old-feature and 21,586,944 new-feature edges. An event in a forgotten sign has equal projected rank on both ends. It separately verifies the bound \(H_{41}\le8+m\) for every one of the 23,246,848 full states; the maxima and full-state counts are

| \(m\) | Full states | Maximum \(H_{41}\) | Violations |
|--:|--:|--:|--:|
| 0 | 7,991,104 | 8 | 0 |
| 1 | 12,397,835 | 9 | 0 |
| 2 | 2,793,874 | 10 | 0 |
| 3 | 63,999 | 11 | 0 |
| 4 | 36 | 12 | 0 |

For a generic rank-three matrix, the checker evaluates \(m\) by the signed-Plücker cocircuit variation formula; a separate four-circuit implementation was compared with that formula on all base states in `../../trajectory_search_20261108/verify_variation_rank_all_edges.cpp`. The extrema and zero violation counts are asserted, not just printed. The 41-sign rank does **not** always have the target-sign parity on this deliberately loose graph: there are 6,559 parity mismatches, so parity is not used in this proof.

A second direct checker, `../../m1_analytic_20261108/verify_projected41_bound_independent.cpp`, separately implements the \(G\)-sign filter and computes \(m\) from positive four-circuits. It reconstructs full keys using the older `rebuild_full_graph.cpp` generator and reads the independently checked `event_table.txt` together with six explicit \(G\) derivatives. It verifies all 23,246,848 states and **144,788,896 distinct full edges**, obtaining the same five maxima and zero violations. The two checks use separate source implementations of the same underlying angular enumeration; neither is a formal proof of the geometric coverage argument below.

## Coverage of strict real trajectories

Here is the reduction that the finite assertions use; it is a mathematical input, not a claim that every enumerated sign word is realizable.

1. For any generic matrix, apply an invertible row transformation so that \(v_6=e_2\), \(v_7=e_3\), and write \(v_i=x_i(1,y_i,z_i)\) for \(i\le5\). This is possible because every \(p_{i67}\ne0\), and \(p_{567}>0\) makes \(x_5>0\). Thus only the four signs of \(x_1,\ldots,x_4\) need to be added back. In this chart, each old \(F\) is the product of four \(x\)'s times the planar determinant of two of the ten edge vectors between \((y_i,z_i)\). The first-five triple minors are the corresponding oriented triangle determinants, and the minors containing 6 or 7 give signs against the two oriented axes. `check_affine_normalization()` proves these identities by exact polynomial arithmetic.

2. Each genuine arrangement of the ten directed planar edges has a cyclic ordering of their 20 rays and antipodes. The signs of all pairs determine this ordering: compare each ray to a fixed reference ray, sort the two open semicircles using the pairwise determinant signs, and verify all comparisons. The code enumerates every possible sign vector, then every gap for the first axis and every compatible gap for the second axis within the positively oriented open half-circle. It also applies all 16 column reorientations. The sixteen universal exterior identities used to discard impossible old-feature signs are verified symbolically; discarding a word that violates one cannot discard a real matrix. The resulting 16,051,200-key set is therefore an over-approximation of every strict real 50-sign word, even though some words need not be realizable.

3. The two new \(G\)-signs are filtered only by their defining two-term differences, three cyclic expressions for each \(G\), and the two linear dependencies among \(G_{56},G_{57},G_{67}\) and the relevant minors. All these polynomial identities are checked exactly by `symbolic_events()`. `gvalid` rejects only assignments violating the signs of these identities, so every strict real augmented sign word survives.

4. Along one fixed move, every tracked feature is affine in the move parameter. Its exact derivative is zero or has a sign determined by one or two tracked features. The direct checker derives and verifies all 114 nonzero and 198 zero derivative identities symbolically. With generic separated events, the sign before an event must oppose its derivative, all other signs agree on the two sides, and both full states survive the necessary filters. Hence the corresponding full move-labeled edge is checked. Projecting it either gives a visible edge or a self-step; in particular, the common hidden assignment is the actual assignment immediately before and after that one event.

5. A finite move sequence can be perturbed so that all 52 endpoint features are nonzero and all events in each move are separated, while every originally strict recorded target sign and positive move parameter is preserved. The checker supplies an exact integer nonzero resultant witness for each of the 1,070 pairs of features simultaneously active under one generator. Thus none of the prohibited equal-root conditions is an identity. Each prefix is an invertible column transformation, so these finitely many generic conditions can be achieved by an arbitrarily small perturbation of the original matrix and move parameters. A functional witnessing the initial minimum \(m(M)\) has a strictly nonzero evaluation list; the perturbation can keep its signs, so the perturbed initial minimum is no larger than \(m(M)\). The direct edge inequalities then bound the original sequence by \(8+m(M)\).

## Reproduction and scope

Work in this directory and compile with assertions enabled; `-DNDEBUG` is explicitly rejected by the shared checked source. The builder requires no input data. The direct checker reads only the rank file produced by that builder.

```sh
c++ -std=c++17 -O3 -pthread build_rank41_unfiltered.cpp -o build_rank41_unfiltered
./build_rank41_unfiltered 41 44 47
c++ -std=c++17 -O3 -pthread verify_rank41_unfiltered_all_edges.cpp -o verify_rank41_unfiltered_all_edges
./verify_rank41_unfiltered_all_edges rank_41_unfiltered.bin
```

The builder and checker both include `standalone_data_free_checked.cpp`, so they share the 50-sign enumeration, exact polynomial arithmetic, and event derivation. The latter is overflow-checked and has also passed a combined address/undefined-behavior sanitizer run. The independent direct edge check avoids relying on the SCC computation or stored graph, but shared code is a remaining audit dependency. The source and result are not a proof-assistant certificate or an externally reviewed proof.

SHA-256 values for the files used above:

```text
2e8bef75e8cd69a31a5fb37b987bd8ee948fb2c33b372d1ac9e16f307fcc0ec4  build_rank41_unfiltered.cpp
64c52d298385df1ebbcefe48e1584b322f8428af577fb8e5794b9ffb4e961950  verify_rank41_unfiltered_all_edges.cpp
ad5acbcba71e601f16eb628982988088ae953d797a83794304ece4170ab36946  standalone_data_free_checked.cpp
79defa24dc15f85dde4530941a6d478c9dbaabe56e90e0e98fee63dd97043553  rank_41_unfiltered.bin
```

To reproduce the second check, from `../../m1_analytic_20261108` run:

```sh
c++ -std=c++17 -O3 -pthread verify_projected41_bound_independent.cpp -o verify_projected41_bound_independent
./verify_projected41_bound_independent
```

It uses the relative paths in its source and therefore should be run from that directory. The independent checker's SHA-256 is `fbf854f92cf05f0c71fb667c400ad032c127cf913a4c0c72c4887056928a5fd3`.

The old 50-sign base keys are unsigned integers in increasing order. Bits 0–34 are the lexicographically ordered minor signs, bits 35–49 are the old \(F^{67}\) signs in the order generated by `labels()`, and bit value 1 means positive. Project each base key using `((1ull<<36)-1)|(1ull<<41)|(1ull<<44)|(1ull<<47)`, sort the distinct projected integers, and call their indices `u`. For \(g=0,1,2,3\), bit 0 of `g` means \(G_{56}>0\) and bit 1 means \(G_{57}>0\). The file stores one byte at offset `4*u+g`; 255 marks an invalid projected state, and other bytes are ranks 0–12. Its total size is 13,513,728 bytes. The mask retains old bits 35, 41, 44, 47; in particular bit 47 is \(F_{23,45}^{67}\).

A separate cross-check retains the same 41 signs but additionally applies all 816 necessary oriented cubic sign rules on common full lifts. That filtered graph has 4,823,808 states, 27,299,328 edges, and maximum rank 12 with the same pointwise bound. The separately constructed rules check 272 distinct resulting rules, the cubic identity, and all 48 pair orientations. `verify_rank41_all_full_edges.cpp` then checks its rank directly on all 22,667,264 cubic-valid full states and 225,305,856 labeled edges. This second graph shares the state generator and is not needed by the unfiltered proof.
