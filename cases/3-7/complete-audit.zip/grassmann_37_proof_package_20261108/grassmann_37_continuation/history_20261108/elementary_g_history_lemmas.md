# Two elementary history obstructions for the 52-sign model

These two lemmas apply directly to real matrices and positive elementary moves. They do not depend on a graph enumeration. They were extracted from two independently verified abstract 14-crossing paths in 51-sign projections; the paths are not realizable trajectories. `verify_two_event_lemma.py` checks the identities and examples exactly.

Write \(p_{ijk}=\det(v_i,v_j,v_k)\), and put
\[
\begin{aligned}
G_{56}&=p_{125}p_{346}-p_{126}p_{345},\\
G_{57}&=p_{125}p_{347}-p_{127}p_{345},\\
G_{67}&=p_{126}p_{347}-p_{127}p_{346}.
\end{aligned}
\]
A positive move replaces \(v_j\) by \(v_j+t v_{j+1}\), with \(t\ge0\). Throughout, regard a finite sequence of moves as the associated continuous, piecewise-affine path.

## Lemma 1: an impossible \(p_{134}\) crossing

Suppose at the starting matrix
\[
p_{125},p_{126},p_{134},p_{157},G_{56}>0,\qquad
p_{127},p_{234},p_{357},G_{67}<0.\tag{1}
\]
Along any finite positive trajectory on which
\[
p_{125},p_{157}>0,\qquad p_{234},p_{357},G_{67}<0\tag{2}
\]
remain strict, \(p_{134}\) cannot reach zero. In particular, it cannot cross from positive to negative. No persistence of \(p_{126}\), \(p_{127}\), or \(G_{56}\) is required after the starting instant, and other features may change freely.

**Proof.** The identity
\[
p_{125}G_{67}-p_{126}G_{57}+p_{127}G_{56}=0
\]
and (1) imply \(G_{57}<0\) initially. Until the first zero of \(p_{134}\), the only nonzero move derivatives of \(G_{57}\) are
\[
\partial_2G_{57}=p_{134}p_{357}<0,\quad
\partial_4G_{57}=p_{125}p_{357}<0,\quad
\partial_5G_{57}=G_{67}<0.
\]
Thus \(G_{57}\) is nonincreasing up to that zero. However, the exact identity
\[
G_{57}=p_{134}p_{257}-p_{234}p_{157}
\]
gives \(G_{57}=-p_{234}p_{157}>0\) at the zero, a contradiction. ∎

The hypotheses are nonvacuous. The seven integer columns
\[
(1,1,2),\ (2,-2,-1),\ (-1,-2,-1),\ (2,1,1),\ (0,2,-1),\ (1,2,-1),\ (-2,-1,-2)
\]
satisfy (1), have all 52 tracked features nonzero, and give \((G_{56},G_{57},G_{67})=(1,-57,-69)\). In the saved `g56_common_hidden_path14.txt`, the corresponding obstructed visible events are rows 107–108: \(G_{56}:+\to-\), then \(p_{134}:+\to-\). The lemma permits other sign events between them, provided (2) holds.

## Lemma 2: an impossible order of two zero events

Let \(a<b\) be times on a finite positive trajectory. Assume that at time \(a\)
\[
p_{125}=0,\qquad p_{126}>0,\qquad p_{345}<0,\tag{3}
\]
and throughout the closed interval \([a,b]\)
\[
p_{125}\ge0,\qquad p_{134}>0,\qquad p_{356}>0,\qquad G_{57}>0.\tag{4}
\]
Then it is impossible that at time \(b\)
\[
p_{123}=0,\qquad p_{124}<0.\tag{5}
\]
The signs in (3), other than \(p_{125}\ge0\), need only hold at \(a\); the sign \(p_{124}<0\) need only hold at \(b\). Other features may change freely.

**Proof.** At \(a\), the definition of \(G_{56}\) and (3) give
\(G_{56}=-p_{126}p_{345}>0\). Along the interval its only nonzero move derivatives satisfy
\[
\partial_2G_{56}=p_{134}p_{356}>0,\quad
\partial_4G_{56}=p_{125}p_{356}\ge0,\quad
\partial_6G_{56}=G_{57}>0.
\]
Hence \(G_{56}\) is nondecreasing. On the other hand,
\[
G_{56}=p_{124}p_{356}-p_{123}p_{456}
\]
and (4)–(5) give \(G_{56}=p_{124}p_{356}<0\) at \(b\), a contradiction. ∎

Both individual walls occur in genuine local positive moves. One integer matrix at the \(p_{125}\) wall has columns
\[
(-2,1,-2),\ (-2,-2,-2),\ (-2,0,2),\ (2,1,-2),\ (4,1,4),\ (-1,2,2),\ (0,0,1),
\]
with \(p_{126}=18,p_{345}=-16,p_{134}=8,p_{356}=30,G_{57}=96\). A separate integer matrix at the \(p_{123}\) wall has columns
\[
(-1,-1,1),\ (-2,1,-2),\ (2,-4,6),\ (2,2,1),\ (2,-2,1),\ (1,-1,1),\ (-1,0,-2),
\]
with \(p_{124}=-9,p_{125}=7,p_{134}=18,p_{356}=2,G_{57}=144\). These matrices are not claimed to be connected by the persistent-sign path ruled out above. The exact checker supplies generic rational matrices immediately before and after each wall, related by the corresponding positive move.

In `g57_common_hidden_path14.txt`, rows 70–79 start with \(p_{125}:-\to+\), end with \(p_{123}:+\to-\), and obey the signs used in the lemma. They form a shortest non-liftable contiguous window of that particular path; no global minimality among all histories is claimed.

## Exact verification

From this folder, with Python 3 and SymPy:

```sh
python3 verify_two_event_lemma.py
python3 projected_history_obstruction.py g56
python3 projected_history_obstruction.py g57
```

The first script symbolically verifies both cyclic identities, the relation among \(G_{56},G_{57},G_{67}\), all six move derivatives and affineness for both G features, the generic integer example, both individual wall matrices and their local crossings, and the specified saved witness rows. The other scripts independently propagate both possible hidden signs through every contiguous window, allowing arbitrary hidden-only sign flips and any eligible generator.
