#!/usr/bin/env python3
"""Exact replay of the finite counterexamples in human_potential_obstructions.md."""
from fractions import Fraction as Q
from itertools import combinations

v=[[3,-1,-4],[-6,-1,-6],[-7,4,-3],[-7,1,-1],[-8,3,7],[1,0,6],[7,0,5]]
I=list(combinations(range(1,8),3))
def det(a,b,c):return a[0]*(b[1]*c[2]-b[2]*c[1])-a[1]*(b[0]*c[2]-b[2]*c[0])+a[2]*(b[0]*c[1]-b[1]*c[0])
def ps(v):return {i:det(*(v[z-1] for z in i)) for i in I}
def rank(p):
 d={}
 for a in reversed(I):
  nexts=[]
  for j in range(3):
   b=list(a);b[j]+=1
   if b[j]<=7 and (j==2 or b[j]<b[j+1]):nexts.append(tuple(b))
  d[a]=max((d[b]+int((p[a]>0)!=(p[b]>0)) for b in nexts),default=0)
 return d[(1,2,3)]
p=ps(v);v[1]=[v[1][i]+v[2][i] for i in range(3)];q=ps(v)
assert all(p.values()) and all(q.values())
assert min(map(abs,p.values()))==5 and min(map(abs,q.values()))==3
assert p[(1,2,3)]==q[(1,2,3)]==181
assert p[(5,6,7)]==q[(5,6,7)]==111
assert rank(p)==8 and rank(q)==10
print('PASS all 35 minors strict; poset variation increases 8 -> 10 with target=181 unchanged')

nodes=[1,2,4,8,16,32,64]
w=[[(-1)**(i+1)*a for a in (1,t,t*t)] for i,t in enumerate(nodes)]
p=ps(w)
assert (p[(1,2,3)],p[(1,2,4)],p[(1,2,5)])==(6,-42,210)
# (42+210i)(-1+5i)=-1092; division by 182 equals -6.
assert 42*(-1)-210*5==-1092 and 42*5+210*(-1)==0
assert Q(-1092,182)==-6
print('PASS actual moment-curve generating polynomial 6+42y+210xy has upper-half-plane zero')

def F(x):return 1-sum(x)+100*x[0]*x[1]+100*x[2]*x[3]
path=[(0,0,0,0),(2,0,0,0),(2,Q(1,10),0,0),(2,Q(1,10),30,0),(2,Q(1,10),30,1)]
values=[F(x) for x in path]
assert all((values[i]>0)!=(values[i+1]>0) for i in range(4))
print('PASS abstract degree-two sign-alternating polynomial has four monotone-path crossings:',values)

# A planar generic state with V=6 but analytic true-rank upper bound 4.
from functools import cmp_to_key
v=[(74,-51,1),(78,-45,1),(-26,-12,1),(-14,66,1),(-60,-81,1),(56,-74,1),(56,-37,1)]
p=ps(v)
assert all(p.values()) and min(map(abs,p.values()))==16 and rank(p)==6
chain=[(1,2,3),(1,2,4),(1,3,4),(2,3,4),(2,3,5),(2,3,6),(2,3,7),(2,4,7),(3,4,7),(3,5,7),(4,5,7),(4,6,7),(5,6,7)]
assert ''.join('+' if p[a]>0 else '-' for a in chain)=='++--++-+-++++'
x=[450*a-271*b+26187*c for a,b,c in v]
assert x==[73308,73482,17739,2001,21138,71441,61414]
w=[(x[i]*v[i+1][0]-x[i+1]*v[i][0],x[i]*v[i+1][1]-x[i+1]*v[i][1]) for i in range(6)]
def cross(a,b):return a[0]*b[1]-a[1]*b[0]
assert all(cross(w[i],w[j]) for i,j in combinations(range(6),2))
assert cross(w[4],w[5])>0
def half(a):return 0 if a[1]>0 or a[1]==0 and a[0]>0 else 1
def cmp(a,b):
 z,t=a[0],b[0];u,v=half(z),half(t)
 if u!=v:return u-v
 return -1 if cross(z,t)>0 else 1
rays=[]
for i,z in enumerate(w):rays.extend([(z,i+1),((-z[0],-z[1]),-i-1)])
rays.sort(key=cmp_to_key(cmp));word=[x[1] for x in rays]
assert word==[-2,5,1,6,-4,3,2,-5,-1,-6,4,-3]
pos=[word.index(i) for i in range(1,7)]
d=[(b-a)%12 for a,b in zip(pos,pos[1:])];d=[z if z<6 else z-12 for z in d]
assert d==[4,-1,5,3,2]
assert 2*(4//6+1//6+10//6)+3-1==4
pencil=[p[a] for a in [(1,2,3),(1,3,4),(2,3,4),(3,4,5),(3,4,6),(3,4,7),(5,6,7)]]
assert pencil==[756,-8268,-8508,1824,-7140,-6696,4292]
assert sum(pencil[i]*pencil[i+1]<0 for i in range(6))==4
print('PASS V=6 planar example: exact all-positive covector has rank-two upper bound 4; pencil lower bound 4')
