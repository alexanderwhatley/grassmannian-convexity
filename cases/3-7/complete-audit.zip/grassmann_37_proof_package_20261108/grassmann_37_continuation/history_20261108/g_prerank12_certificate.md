# A candidate computer-assisted 12-prerank from two concurrency signs

**Status.** The independently checked finite certificate below gives a
computer-assisted proof of the conjectured 12-bound, provided the original
50-sign state-coverage argument, the generic-event reduction, and the
software are correct. It has not received external review. It is not a
claimed elementary proof. A direct all-state verifier checks the final
12-prerank, so the parity extension is not needed for the main bound.

## 1. Original 50-sign rank

Let \(M=(v_1,\ldots,v_7)\), \(p_{ijk}=\det(v_i,v_j,v_k)\), and normalize
\(p_{567}>0\). A positive move replaces \(v_j\) by \(v_j+t v_{j+1}\),
\(t>0\). Record the 35 maximal-minor signs and the 15 signs
\[
F_{ij,kl}^{67}=p_{ij6}p_{kl7}-p_{ij7}p_{kl6},
\]
for partitions of four distinct indices in \(\{1,\ldots,5\}\). The
reconstructed sign graph has 16,051,200 states. Its byte-valued rank
\(R\) satisfies \(0\le R\le14\), and for every move-labeled graph edge
\(u\to v\),
\[
R(u)\ge R(v)+[p_{123}\text{ changes sign}].\tag{1}
\]
`../verify_filtered_rank.cpp` checks (1) for 151,713,792 move-labeled
transitions without using the SCC routine that constructed `filtered_rank.bin`.
It shares the original state enumerator. The mathematical coverage of all
generic real matrices by that enumerator is described in the earlier
checkpoint and checked in `../verify_feature_classification.py` and
`../verify_joint_classification.py`.

## 2. Two additional signs

Add
\[
G_{56}=p_{125}p_{346}-p_{126}p_{345},\qquad
G_{57}=p_{125}p_{347}-p_{127}p_{345},
\]
and write the already tracked \(G_{67}=F_{12,34}^{67}\). The only
nonzero directional derivatives under the six elementary generators are
\[
\begin{array}{c|ccc}
 &j=2&j=4&j=6\\\hline
G_{56}&p_{134}p_{356}&p_{125}p_{356}&G_{57}
\end{array}\qquad
\begin{array}{c|ccc}
 &j=2&j=4&j=5\\\hline
G_{57}&p_{134}p_{357}&p_{125}p_{357}&G_{67}.
\end{array}\tag{2}
\]
All these polynomials are affine along any one elementary move. The twelve
move laws, including the six zero derivatives, are verified symbolically
in `verify_g_features_symbolic.py`; an independent full-substitution
verification is in `../new_work/audit_g_symbolic_independent.py`.

The augmented 52-sign graph imposes only the following **necessary** strict
sign conditions. Put \(A_e=p_{12e}\), \(B_e=p_{34e}\) for \(e=5,6,7\).
For each pair \(e<f\), if the signs of \(A_eB_f\) and \(A_fB_e\) differ,
the sign of \(G_{ef}=A_eB_f-A_fB_e\) is forced to equal the first sign.
Further,
\[
A_5G_{67}-A_6G_{57}+A_7G_{56}=0,\quad
B_5G_{67}-B_6G_{57}+B_7G_{56}=0;\tag{3}
\]
the three signed summands in either identity cannot all have the same sign.
Finally, for each of \(G_{56},G_{57}\), apply the same opposite-summand
forcing to all three cyclic expressions
\[
F_{ab,cd}^{ef}=F_{cd,ef}^{ab}=F_{ef,ab}^{cd}.
\]
All six cyclic identities and (3) are checked symbolically. No assertion is
made that these signs are jointly sufficient for a real matrix.

`g_features.hpp` constructs the first set of constraints via the 192 angular
orders of the 2-vectors \((A_e,B_e)\) and the coordinate axes. The separate
checker `verify_g_closure.cpp` instead constructs the same necessary filter
directly from (3) and the three opposite-summand tests; it checks all 512
possible sign assignments and confirms the 192 allowed patterns agree with
explicit integer 2-vector triples. A further diagnostic verifies 100,000
generic integer matrices and 36,096 actual move-labeled G crossings.

## 3. Closed-set certificate and the 12-prerank

For an augmented sign state \(s=(u,\operatorname{sgn}G_{56},
\operatorname{sgn}G_{57})\), let \(R(s)=R(u)\). An augmented graph edge
changes one tracked sign and is allowed only if its derivative in the
corresponding positive move points toward zero and its destination satisfies
the necessary sign conditions above. Call it **tight** when equality holds in
(1). A change of either G sign has target weight zero.

The 12 original rank-14 states have 36 augmented sign assignments satisfying
the necessary conditions. `g_tight_search.cpp`, run with `nohalf`, starts
from all 36 and exhausts the tight augmented edges, without any halfspace,
cyclic-word-history, or trajectory-realizability filter. Its visited set
\(K\), encoded by `g_reachable_50_nohalf.bin`, has 10,685,161 states and no
state with \(R=0\).

The separate `verify_g_closure.cpp` reads that bitset and verifies:

1. All 36 valid augmented rank-14 states lie in \(K\).
2. No state in \(K\) has \(R=0\).
3. Every tight augmented edge from a state of \(K\), using the necessary
   sign conditions and the independent event table, ends in \(K\). It
   checks 92,992,035 move-labeled base edges and 9,774,840 move-labeled G
   edges.

The still stronger independent checker `verify_g_double_closure.cpp`
verifies that all **2,981** admissible augmented states with \(R\ge13\)
lie in \(K\), every state in \(K\) has \(R\ge2\) (the observed minimum
is 5), and every edge from \(K\) whose old integer slack
\(R(u)-R(v)-w\) is 0 or 1 remains in \(K\). It checks the same 92,992,035
base and 9,774,840 G move-labeled edges. In fact,
`check_original_rank_parity.cpp` independently confirms that
\(R\bmod2=[p_{123}<0]\) for all 16,051,200 base states, so old edge slack
is always even; nonetheless the double-closure checker explicitly includes
both 0 and 1.

It is unnecessary that every stored state be reachable: any set satisfying
these strengthened properties suffices. Define
\[
P(s)=R(s)-2\mathbf1_{K}(s).\tag{4}
\]
Then \(0\le P\le12\). Every augmented edge obeys the same prerank
inequality as (1): edges remaining inside or outside \(K\) inherit it;
an outside-to-inside edge gains two units of slack; an inside-to-outside
edge has old integer slack at least two by the double-closure test. Every
generic target sign crossing therefore decreases \(P\) by at least one,
yielding at most 12 crossings directly.

As an additional independent check, `verify_g_prerank12_direct.cpp` does not
use this closure argument: it directly checks \(P\in[0,12]\) and the
prerank inequality on **every** admissible augmented state and every
move-labeled augmented edge, including non-tight ones. It finds 23,246,848
admissible augmented states and verifies 209,042,944 base transitions plus
21,586,944 G transitions. Thus the saved rank bytes themselves need not be
assumed to satisfy (1) if this full direct check is accepted. The direct
checker still shares the original 50-state enumerator and event data.

All 52 tracked sign polynomials are affine along one elementary move.
`../new_work/audit_52_sign_ties.py` constructs exact nonzero resultant
witnesses for all 1,070 pairs of active events, so a generic perturbation
can separate their zero times. Other finitely many degeneracies can likewise
be avoided while preserving a chosen finite collection of strict target
sign changes. This is the required bridge from the finite graph to general
finite positive trajectories; it warrants particular independent review.

## 4. Lower bound and equality

An explicit exact rational 12-crossing sequence is checked by
`../sector_agent/verify_rational_lower12_independent.py`; the published
general lower bound also gives 12. Subject to the mathematical and software
audits identified above, these combine to a computer-assisted proof of
\(r(3,7)=12\).

## 5. Reproduction and hashes

From `grassmann_37_continuation`:

```sh
c++ -O3 -std=c++17 -pthread verify_filtered_rank.cpp -o verify_filtered_rank
./verify_filtered_rank
python3 verify_event_table_symbolic.py
python3 verify_feature_classification.py
python3 verify_joint_classification.py
python3 new_work/audit_g_symbolic_independent.py
python3 new_work/audit_52_sign_ties.py
cd history_20261108
python3 verify_g_features_symbolic.py
c++ -O3 -std=c++17 -pthread test_g_features.cpp -o test_g_features
./test_g_features
python3 verify_g_rank2_table.py
c++ -O3 -std=c++17 -pthread g_tight_search.cpp -o g_tight_search
./g_tight_search nohalf
c++ -O3 -std=c++17 -pthread verify_g_closure.cpp -o verify_g_closure
./verify_g_closure
c++ -O3 -std=c++17 -pthread verify_g_double_closure.cpp -o verify_g_double_closure
./verify_g_double_closure
c++ -O3 -std=c++17 -pthread check_original_rank_parity.cpp -o check_original_rank_parity
./check_original_rank_parity
c++ -O3 -std=c++17 -pthread verify_g_prerank12_direct.cpp -o verify_g_prerank12_direct
./verify_g_prerank12_direct
sha256sum ../filtered_rank.bin g_reachable_50_nohalf.bin
cd ../sector_agent
python3 verify_endpoint_extension.py
python3 verify_rational_lower12_independent.py
```

The saved rank and closure files have SHA-256:

```text
edbc416d792f8d0019a24f10d004b2fd86f53bf8aae6f3cdc5997ecec64d085e  filtered_rank.bin
8c816bd1d5bb839f1007c9ac821f738cf92eb4ee66d62c2d90334ca9c715bdef  g_reachable_50_nohalf.bin
```
