#!/usr/bin/env python3
"""Verify normal boundary arithmetic and rejection of each deliberate overflow."""
import resource,subprocess

def no_core():resource.setrlimit(resource.RLIMIT_CORE,(0,0))
subprocess.run(['./verify_checked_arithmetic'],check=True,preexec_fn=no_core)
for mode in ('add64','sub64','mul64','neg64','add128','sub128','mul128'):
 p=subprocess.run(['./verify_checked_arithmetic',mode],stdout=subprocess.PIPE,stderr=subprocess.PIPE,preexec_fn=no_core)
 assert p.returncode!=0 and b'Assertion' in p.stderr,(mode,p.returncode,p.stderr)
 print('PASS rejected deliberate',mode,'overflow')
print('PASS exact signed bounds and all seven overflow guards')
