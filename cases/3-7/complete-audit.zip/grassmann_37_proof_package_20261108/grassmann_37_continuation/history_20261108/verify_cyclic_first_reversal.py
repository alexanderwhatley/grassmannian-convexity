#!/usr/bin/env python3
"""Audit the exact ±1 jump of the rank-two cyclic prerank when w1 reverses."""
from itertools import permutations,product
from collections import Counter

def deltas(word,n):
    pos={a:word.index(a) for a in range(1,n+1)}
    out=[]
    for i in range(1,n):
        d=(pos[i+1]-pos[i])%(2*n)
        assert d not in (0,n)
        out.append(d if d<n else d-2*n)
    return out

def rank(word,n):
    ds=deltas(word,n)
    runs=[]
    for d in ds:
        if not runs or runs[-1][0]*d<0:runs.append([d,abs(d)])
        else:runs[-1][1]+=abs(d)
    return 2*sum(x[1]//n for x in runs)+len(runs)-1

for n in range(3,8):
    counts=Counter();deldiff=Counter();examined=0
    for perm in permutations(range(2,n+1)):
      for signs in product((1,-1),repeat=n-1):
        half=[1]+[a*b for a,b in zip(perm,signs)]
        word=half+[-a for a in half]
        # normalize the final pair's determinant positive
        if deltas(word,n)[-1]<0:continue
        flip=[-a if abs(a)==1 else a for a in word]
        old,new=rank(word,n),rank(flip,n)
        assert new-old in (-1,1)
        assert (new+0)-(old+1) in (-2,0)
        # Antipodal reversal complements the first short arc exactly.
        x,y=deltas(word,n),deltas(flip,n)
        assert y[1:]==x[1:]
        assert y[0]==-(1 if x[0]>0 else -1)*(n-abs(x[0]))
        sub=[(1 if a>0 else -1)*(abs(a)-1) for a in word if abs(a)!=1]
        oldsub=rank(sub,n-1)
        assert 0<=old-oldsub<=2
        counts[new-old]+=1;deldiff[old-oldsub]+=1;examined+=1
    assert examined==(2**(n-2))*__import__('math').factorial(n-1)
    print(f'n={n} words={examined} reversal={dict(sorted(counts.items()))} deletion={dict(sorted(deldiff.items()))}')
print('PASS all cyclic first-vector reversal and deletion checks')
