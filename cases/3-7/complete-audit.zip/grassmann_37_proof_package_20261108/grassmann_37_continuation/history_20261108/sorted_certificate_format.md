# Key-sorted rank certificate

The reconstructed base graph has \(N=16,051,200\) distinct 50-bit unsigned keys. Sort these keys in increasing numeric order, with 0-based index \(k\). The 35 Plücker signs occupy bits 0–34 and the fifteen 67-concurrency signs occupy bits 35–49, with positive sign represented by 1. The precise feature indexing is in `../rebuild_full_graph.cpp` and `../event_table.txt`.

* `rank_by_sorted_key.bin`: exactly \(N\) bytes; byte \(k\) is the original rank \(R\) at sorted key \(k\).
* `K_by_sorted_key.bin`: exactly \(N/2\) bytes. For key index \(k\), the low nibble of byte \(\lfloor k/2\rfloor\) is used if \(k\) is even, and the high nibble if \(k\) is odd. The bit \(g\) of this nibble indicates membership in \(K\) for the augmented key with \(g\in\{0,1,2,3\}\), where bit 0 is the positive sign of \(G_{56}\) and bit 1 is the positive sign of \(G_{57}\).
* `keys_by_sorted_key_le64.bin`: the sorted key stream itself, as exactly \(N\) unsigned 64-bit little-endian integers. This 128,409,600-byte file is a checksum/reference convenience; it is not needed when an independent program regenerates and sorts the keys.

SHA-256:

```text
06c37f56febbca63c53323830aa73944c1e7039990f51b28c86e4d59aba19606  rank_by_sorted_key.bin
00f17b96a8892607fbcbfb8e341f6bab451fc50d9ad3f23564ee12e2d77079a1  K_by_sorted_key.bin
ba7753806df78ca0432062ad1fb0009572b3702cd9a0febdb6fc5f52e9ccb02f  keys_by_sorted_key_le64.bin
```

Generate and verify from this directory:

```sh
c++ -O3 -std=c++17 -pthread make_sorted_key_certificate.cpp -o make_sorted_key_certificate
./make_sorted_key_certificate
c++ -O3 -std=c++17 -pthread verify_sorted_key_certificate.cpp -o verify_sorted_key_certificate
./verify_sorted_key_certificate
sha256sum rank_by_sorted_key.bin K_by_sorted_key.bin keys_by_sorted_key_le64.bin
```

The verifier regenerates the original-order key stream, checks that its sorted copy equals the stored strict ascending key stream, and binary-searches the stream for each original-order key to verify all rank bytes and packed K nibbles. It shares the original key enumerator and therefore does not independently establish mathematical state coverage. The independently reconstructed key enumerator is checked separately.
