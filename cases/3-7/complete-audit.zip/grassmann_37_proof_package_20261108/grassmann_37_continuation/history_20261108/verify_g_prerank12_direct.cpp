// Direct check of the claimed 12-prerank R''=R-2*1_K on every augmented state
// and every move-labeled augmented edge, using only algebraic sign filters.
// Shares the old 50-sign state enumerator/rank file, but does not include
// g_features.hpp, g_tight_search.cpp, the SCC code, or the G-search BFS.
// The old event table and the new six events are read/reconstructed directly.
// Run from this directory, after g_reachable_50_nohalf.bin has been created.
#define main gc37_graph_unused_main
#include "../rebuild_full_graph.cpp"
#undef main

struct Test {int move,target,a,b,sg;};
int main(){
 init();auto dirs=direction_types(true);auto masks=sign_masks();Hash H(1ull<<25);
 vector<uint64_t>keys;keys.reserve(16051200);
 for(auto&w:dirs)for(auto&z:add_axes(w)){uint64_t base=word_key(z);for(auto mask:masks){uint64_t k=base^mask;H.insert(k,keys.size());keys.push_back(k);}}
 uint32_t n=keys.size();assert(n==16051200);
 vector<uint8_t>rank(n),reach(uint64_t(n)*4/8),allowed(n);
 ifstream rf("../filtered_rank.bin",ios::binary);rf.read((char*)rank.data(),n);assert(rf.gcount()==n);
 ifstream bf("g_reachable_50_nohalf.bin",ios::binary);bf.read((char*)reach.data(),reach.size());assert(bf.gcount()==int64_t(reach.size()));
 char ch;assert(!bf.read(&ch,1));
 auto contains=[&](uint32_t u,int g){uint32_t code=u*4+g;return bool(reach[code/8]&(1u<<(code%8)));};

 // Independently build the filter from direct product-sign implications
 // and the two exact 3-term identities A5*G67-A6*G57+A7*G56=0
 // and B5*G67-B6*G57+B7*G56=0.  These are only necessary for the proof.
 array<uint8_t,512>qsign{},integer_realized{};
 for(int code=0;code<512;code++){
  int s[9];for(int i=0;i<9;i++)s[i]=(code>>i&1)?1:-1;
  auto forced=[](int a,int b,int want){return a==b||a==want;};
  if(!forced(s[0]*s[3],s[2]*s[1],s[6])||!forced(s[0]*s[5],s[4]*s[1],s[7])||
     !forced(s[2]*s[5],s[4]*s[3],s[8]))continue;
  if(abs(s[0]*s[8]-s[2]*s[7]+s[4]*s[6])==3)continue;
  if(abs(s[1]*s[8]-s[3]*s[7]+s[5]*s[6])==3)continue;
  qsign[code]=1;
 }
 assert(count(qsign.begin(),qsign.end(),1)==192);
 // As a diagnostic, every allowed pattern is realized by an explicit
 // integer triple and no other pattern is produced.
 vector<pair<int,int>>coords;
 for(int a:{-3,-2,-1,1,2,3})for(int b:{-3,-2,-1,1,2,3})coords.emplace_back(a,b);
 for(auto[a,b]:coords)for(auto[c,d]:coords)for(auto[e,f]:coords){
  int g56=a*d-c*b,g57=a*f-e*b,g67=c*f-e*d;if(!g56||!g57||!g67)continue;
  int vals[9]={a,b,c,d,e,f,g56,g57,g67},code=0;for(int i=0;i<9;i++)if(vals[i]>0)code|=1<<i;integer_realized[code]=1;
 }
 assert(integer_realized==qsign);
 auto orient=[&](uint64_t k,int a,int b,int c){
  int inv=(a>b)+(a>c)+(b>c);array<int,3>z={a,b,c};sort(z.begin(),z.end());
  int s=(k>>pid[z[0]][z[1]][z[2]]&1)?1:-1;return inv&1?-s:s;
 };
 auto necessary=[&](uint64_t key,int g){
  const int psign[6]={pid[1][2][5],pid[3][4][5],pid[1][2][6],pid[3][4][6],pid[1][2][7],pid[3][4][7]};
  int code=0;for(int i=0;i<6;i++)if(key>>psign[i]&1)code|=1<<i;
  if(g&1)code|=1<<6;if(g&2)code|=1<<7;if(key>>35&1)code|=1<<8;
  if(!qsign[code])return false;
  // Use all three equivalent bracket expressions for each G.  Whenever
  // the two product signs oppose, their difference has a forced sign.
  for(int i=0;i<2;i++){
   pair<int,int> pp[3]={{1,2},{3,4},{5,i?7:6}};int want=(g>>i&1)?1:-1;
   for(int t=0;t<3;t++){
    auto[a,b]=pp[t];auto[c,d]=pp[(t+1)%3];auto[e,f]=pp[(t+2)%3];
    int A=orient(key,a,b,e)*orient(key,c,d,f),B=orient(key,a,b,f)*orient(key,c,d,e);
    if(A!=B&&A!=want)return false;
   }
  }
  return true;
 };
 vector<thread>threads;atomic<uint64_t>states_checked{0},base_tests{0},g_tests{0};atomic<int>maximum{0};
 for(int th=0;th<8;th++)threads.emplace_back([&,th](){
  size_t lo=size_t(n)*th/8,hi=size_t(n)*(th+1)/8;
  for(size_t u=lo;u<hi;u++){uint8_t mask=0;for(int g=0;g<4;g++)if(necessary(keys[u],g))mask|=1u<<g;allowed[u]=mask;}
 });
 for(auto&t:threads)t.join();threads.clear();

 vector<Test>tests;ifstream et("../event_table.txt");Test t;
 while(et>>t.move>>t.target>>t.a>>t.b>>t.sg)if(t.target<50)tests.push_back(t);
 assert(tests.size()==108);
 tests.push_back({2,50,pid[1][3][4],pid[3][5][6],1});
 tests.push_back({4,50,pid[1][2][5],pid[3][5][6],1});
 tests.push_back({6,50,51,-1,1});
 tests.push_back({2,51,pid[1][3][4],pid[3][5][7],1});
 tests.push_back({4,51,pid[1][2][5],pid[3][5][7],1});
 tests.push_back({5,51,35,-1,1});
 for(int th=0;th<8;th++)threads.emplace_back([&,th](){
  uint64_t states=0,nb=0,ng=0;int mx=0;size_t lo=size_t(n)*th/8,hi=size_t(n)*(th+1)/8;
  for(size_t u=lo;u<hi;u++){
   assert(rank[u]<=14);uint64_t base=keys[u];
   for(int g=0;g<4;g++){
    bool stored=contains(u,g),valid=allowed[u]&(1u<<g);
    if(!valid){assert(!stored);continue;}
    int Ru=int(rank[u])-2*int(stored);assert(Ru>=0&&Ru<=12);mx=max(mx,Ru);
    states++;uint64_t key=base|(uint64_t(g)<<50);
    for(const Test&e:tests){
     int s=(key>>e.target&1)?1:-1,der=e.sg*((key>>e.a&1)?1:-1);
     if(e.b>=0)der*=((key>>e.b&1)?1:-1);
     if(s==der)continue;
     if(e.target<50){
      uint32_t v=H.find(base^(1ull<<e.target));if(v==UINT32_MAX)continue;
      unsigned weight=e.target==pid[1][2][3];
      if(!(allowed[v]&(1u<<g)))continue;
      int Rv=int(rank[v])-2*int(contains(v,g));
      if(Ru<Rv+int(weight)){cerr<<"prerank failure base "<<u<<" -> "<<v<<" bit "<<e.target<<"\n";abort();}nb++;
     }else{
      int h=g^(1<<(e.target-50));if(!(allowed[u]&(1u<<h)))continue;
      int Rv=int(rank[u])-2*int(contains(u,h));
      if(Ru<Rv){cerr<<"prerank failure G "<<u<<" bit "<<e.target<<"\n";abort();}ng++;
     }
    }
   }
  }
  states_checked+=states;base_tests+=nb;g_tests+=ng;int old=maximum;while(old<mx&&!maximum.compare_exchange_weak(old,mx)){}
 });
 for(auto&t:threads)t.join();
 cout<<"PASS direct 12-prerank on "<<states_checked<<" admissible augmented states; maximum "<<maximum<<"\n";
 cout<<"PASS rank inequalities on "<<base_tests<<" move-labeled base transitions and "<<g_tests<<" move-labeled G transitions\n";
}
