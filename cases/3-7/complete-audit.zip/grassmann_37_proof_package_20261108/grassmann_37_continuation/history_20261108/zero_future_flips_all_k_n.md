# A zero-future-flip criterion in every Grassmannian

Let \(0<k<n\), and let \(M=(v_1,\ldots,v_n)\) be a real \(k\times n\) matrix with every maximal minor nonzero. Normalize the final minor
\[
p_{n-k+1,\ldots,n}>0
\]
by a left change of orientation, which does not affect sign changes. An elementary positive move replaces \(v_j\) by \(v_j+t v_{j+1}\), \(t>0\). Let \(r(M)\) be the supremum of the number of sign changes of \(p_{1,\ldots,k}\) over finite positive-move sequences with generic recorded vertices.

**Theorem.** \(r(M)=0\) if and only if every maximal minor of \(M\) is positive. More precisely:

* If \(p_{1,\ldots,k}<0\), then \(r(M)\ge1\).
* If \(p_{1,\ldots,k}>0\) and some maximal minor is negative, then \(r(M)\ge2\).

The theorem is elementary and does not use the 52-sign graph, the cubic rules, or the \((3,7)\) computation. It concerns generic initial maximal minors; it makes no assertion about an initial zero final minor.

## A sign-targeting lemma

For every \(k\)-subset \(I\subseteq\{1,\ldots,n\}\), there is a finite sequence of positive elementary moves after which the sign of \(p_{1,\ldots,k}\) equals the **initial** sign of \(p_I(M)\). All recorded matrices can be made to have nonzero maximal minors.

Let \(J\) be the lower shift, \(J_{i+1,i}=1\), and let \(D_L\) be diagonal with \(d_i=L\) for \(i\in I\) and \(d_i=1\) otherwise. If \(B\) is any lower unitriangular matrix whose minors \(\Delta_{K,[k]}(B)\) are strictly positive for all \(|K|=k\), Cauchy–Binet gives
\[
\Bigl(\prod_{c=1}^{k}d_c\Bigr)
 p_{[k]}\!\left(MD_LBD_L^{-1}\right)
 =\sum_{|K|=k}p_K(M)\,\Delta_{K,[k]}(B)
   L^{|K\cap I|}.\tag{1}
\]
The coefficient of \(L^k\) is uniquely \(p_I(M)\Delta_{I,[k]}(B)\), so the right side has the sign of \(p_I(M)\) for all sufficiently large \(L\). We give two choices of \(B\).

### Explicit finite sweeps

Write \(U_j(t)=I+tE_{j+1,j}\), and take
\[
S=U_{n-1}(1)U_{n-2}(1)\cdots U_1(1),\qquad B=S^k.
\]
Then \(S_{ij}=1\) for \(i\ge j\), otherwise 0, and
\[
B_{ij}=\binom{k+i-j-1}{k-1}\quad(i\ge j).
\]
For \(K=\{j_1<\cdots<j_k\}\), its flag minor is
\[
\Delta_{K,[k]}(B)
 =\frac{\prod_{r<s}(j_s-j_r)}{\prod_{r=0}^{k-1}r!}>0.\tag{2}
\]
Indeed, the determinant is alternating in the \(j_r\); its columns are polynomials of degree at most \(k-1\), so its total degree is at most \(k(k-1)/2\). It is a constant multiple of the Vandermonde. Evaluating at \(j_r=r\), where the flag minor is 1, yields (2).

Conjugation gives
\[
D_L U_j(1)D_L^{-1}=U_j(d_{j+1}/d_j),
\]
so \(D_LBD_L^{-1}\) is **exactly \(k(n-1)\) positive shears**; no limiting process is needed. For example, it suffices to choose \(L\ge1\) larger than
\[
\frac{\sum_{K\ne I}|p_K(M)|\,\Delta_{K,[k]}(B)}
 {|p_I(M)|\,\Delta_{I,[k]}(B)}.
\]
Then the degree-\(k\) term in (1) strictly dominates all lower-degree terms.

### Exponential alternative

The same conclusion follows with \(B=e^J\), whose flag minors are
\[
\Delta_{K,[k]}(e^J)
 =\frac{\prod_{r<s}(j_s-j_r)}{\prod_{r=1}^{k}(j_r-1)!}>0.\tag{3}
\]
After factoring \(1/(j_r-1)!\) from row \(r\), the columns are the monic falling-factorial polynomials of degrees \(0,\ldots,k-1\), giving the Vandermonde. For each fixed large \(L\), a product formula approximates \(D_Le^JD_L^{-1}\) by finite products of the same positive elementary shears, and the strict target sign persists. This alternative is not needed for the finite-sweep proof.

For either construction, generic recorded vertices require one final observation. Treat the finitely many positive shear parameters as independent variables. Each maximal minor at each prefix is a polynomial in these parameters with nonzero constant term, equal to the corresponding initial minor. Thus none of those polynomials is identically zero. An arbitrarily small perturbation within the positive parameter orthant avoids their finite union of zero sets while preserving the strict final target sign. This proves the sign-targeting lemma.

## Proof of the theorem

If every maximal minor is positive, any positive move either leaves a maximal minor unchanged or adds a positive multiple of another maximal minor. The indices \(j,j+1\) are adjacent, so replacement introduces no reordering sign. Thus all minors remain positive and no target sign change is possible.

Conversely, if the initial target is negative, apply the sign-targeting lemma with \(I=\{n-k+1,\ldots,n\}\). Its minor is positive, so at least one target sign change occurs. If the initial target is positive but some minor \(p_I\) is negative, first target the sign of \(p_I\), producing a negative target and at least one change. The final minor is unchanged by every positive shear, since the final \(k\) columns are multiplied by a lower unitriangular \(k\times k\) block. Target its positive sign next: at least one further change occurs. ∎

For a concrete exact \((3,7)\) illustration, take \(v_i=(-1)^i(1,i,i^2)\), \(1\le i\le7\), then make moves \((j,t)=(3,7/10),(4,3/4),(3,1)\). All 35 maximal minors are nonzero at each recorded matrix, \(p_{567}=2\), and the target values are
\[
2,\quad -11/5,\quad -11/5,\quad 4/5.
\]
Thus the two-flip strengthening is attained in this example.

## Exact checks

`python3 verify_flag_minor_formulas.py` verifies the finite sweep product, both Vandermonde formulas for all 1,004 index sets with \(2\le n\le9\), and the rational two-flip example. The proof above is valid for arbitrary \(k,n\); the finite computations are checks, not the basis of the theorem.
