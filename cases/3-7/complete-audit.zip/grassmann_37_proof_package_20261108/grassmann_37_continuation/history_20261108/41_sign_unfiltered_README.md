# Unfiltered 41-sign certificate: quick reference

For generic real \(3\times7\) matrices under positive adjacent column shears, this certificate checks the pointwise upper bound \(r(M)\le 8+m(M)\le12\), where \(r\) counts changes of the sign of \(p_{123}\) and \(m\) is the minimum sign variation of a strict covector evaluation list. A separate exact 28-move witness attains 12. This is a computer-assisted argument, not external peer review.

The nonnegative rank \(H_{41}\) depends only on the 35 minor signs and six further signs, with
\[
F_{ab,cd}^{ef}=p_{abe}p_{cdf}-p_{abf}p_{cde}:
\qquad F_{12,34}^{67},F_{12,45}^{67},F_{13,45}^{67},F_{23,45}^{67},F_{12,34}^{56},F_{12,34}^{57}.
\]
The finite construction checks that this rank never increases on a visible edge, drops by at least one on a \(p_{123}\) event, and satisfies \(H_{41}\le8+m\). Necessary sign constraints and generic event separation ensure that every real finite trajectory is covered. Hidden feature signs may reset between visible events, so the graph may contain unrealizable paths. No cubic rule is imposed.

| Checked object | Count |
|:--|--:|
| Full 50-sign base keys | 16,051,200 |
| Full valid 52-sign states | 23,246,848 |
| Distinct 41-sign potential states | 4,960,256 |
| Distinct directed 41-sign edges | 27,866,144 |
| 41-sign SCCs | 455,402 |
| 41-sign maximum rank | 12 |
| Directly checked full move-labeled edges | 230,629,888 |

**The projected state count is not the size of the whole computation.** The builder and direct checker still enumerate the full hidden sign model. For \(m=0,1,2,3,4\), the maxima of \(H_{41}\) are respectively \(8,9,10,11,12\), and all violations of \(H_{41}\le8+m\) are explicitly asserted absent. The direct checker reads no SCC or edge data: it rebuilds every full state and checks every labeled edge. A second independently implemented checker uses four-circuits for \(m\) and a separate \(G\) filter, checking all full states and 144,788,896 distinct full edges.

## Reproduce

From this directory, with assertions enabled:

```sh
c++ -std=c++17 -O3 -pthread build_rank41_unfiltered.cpp -o build_rank41_unfiltered
./build_rank41_unfiltered 41 44 47
c++ -std=c++17 -O3 -pthread verify_rank41_unfiltered_all_edges.cpp -o verify_rank41_unfiltered_all_edges
./verify_rank41_unfiltered_all_edges rank_41_unfiltered.bin
```

The builder needs no input data and writes `rank_41_unfiltered.bin`. The direct checker reads that file and includes the checked source named below; both programs share its data-free base enumerator and symbolic event logic. The separate four-circuit check is `../../m1_analytic_20261108/verify_projected41_bound_independent.cpp`, run from that directory. Full definitions, geometric coverage, file format, limitations, complete counts, and the 816-rule filtered cross-check are in `41_sign_unfiltered_certificate.md`.

SHA-256:

```text
2e8bef75e8cd69a31a5fb37b987bd8ee948fb2c33b372d1ac9e16f307fcc0ec4  build_rank41_unfiltered.cpp
64c52d298385df1ebbcefe48e1584b322f8428af577fb8e5794b9ffb4e961950  verify_rank41_unfiltered_all_edges.cpp
ad5acbcba71e601f16eb628982988088ae953d797a83794304ece4170ab36946  standalone_data_free_checked.cpp
79defa24dc15f85dde4530941a6d478c9dbaabe56e90e0e98fee63dd97043553  rank_41_unfiltered.bin
fbf854f92cf05f0c71fb667c400ad032c127cf913a4c0c72c4887056928a5fd3  ../../m1_analytic_20261108/verify_projected41_bound_independent.cpp
```
