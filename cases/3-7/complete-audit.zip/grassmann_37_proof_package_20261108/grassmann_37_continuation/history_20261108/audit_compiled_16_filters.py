#!/usr/bin/env python3
"""Verify necessity of the exact 16 compiled direction filters from scratch.

Use formal planar edge vectors: v5=0, v1..v4 are basis symbols. The oriented
areas form the six-dimensional exterior square. Every compiled signed sum is
checked to vanish identically in this exterior square. The ten relations in
pass3 are independently parsed and checked to occur among these 16.
"""
from pathlib import Path
from itertools import combinations
import ast,re
parent=Path(__file__).resolve().parent.parent
h=(parent/'affine_circuit_filter16.hpp').read_text()
c=(parent/'rebuild_full_graph.cpp').read_text()
def integers(name):
 match=re.search(rf'{name}\[\]\s*=\s*\{{([^}}]+)\}}',h)
 assert match
 return [int(x) for x in match.group(1).split(',')]
plus=integers('gc37_small_plus');minus=integers('gc37_small_minus')
assert len(plus)==len(minus)==16
# These are exactly flab's 15 disjoint pairings, parsed from the C++ source.
block=re.search(r'const F4 flab\[15\]\s*=\s*\{(.*?)\};',c,re.S).group(1)
labels=[tuple(map(int,re.findall(r'\d+',row))) for row in re.findall(r'\{[^{}]+\}',block)]
assert len(labels)==15 and all(len(x)==4 and len(set(x))==4 for x in labels)
def edge(i,j):return tuple(int(j==k)-int(i==k) for k in range(1,5))
def area(i,j,k,l):
 a,b=edge(i,j),edge(k,l)
 return tuple(a[u]*b[v]-a[v]*b[u] for u,v in combinations(range(4),2))
forms=[area(*f) for f in labels]
for pos,neg in zip(plus,minus):
 assert not pos&neg and pos and neg and not ((pos|neg)>>15)
 assert all(sum(((pos>>i&1)-(neg>>i&1))*forms[i][k] for i in range(15))==0 for k in range(6))
triples=re.search(r'const int triples\[10\]\[3\]\s*=\s*\{(.*?)\};',c,re.S).group(1)
rows=[tuple(map(int,re.findall(r'-?\d+',row))) for row in re.findall(r'\{[^{}]+\}',triples)]
assert len(rows)==10 and all(len(row)==3 for row in rows)
for row in rows:
 p=sum(1<<(i-1) for i in row if i>0)
 m=sum(1<<(-i-1) for i in row if i<0)
 assert (p,m) in zip(plus,minus) or (m,p) in zip(plus,minus)
print('PASS all 16 compiled masks are universal planar-edge exterior identities')
print('PASS all ten pass3 exclusions are included among those 16 identities')
print('Every rejection is necessary for any generic real matrix; no realizability assertion needed')
