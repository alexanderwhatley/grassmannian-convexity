# Both new signs matter to this local graph abstraction

The successful 52-sign certificate tracks the concurrency signs \(G_{56}\) and \(G_{57}\). It is natural to ask whether either sign can simply be deleted. The answer for the particular necessary-condition graph used here is no: each resulting 51-sign over-approximation has a 14-target-edge path.

We impose a stronger local rule than simple statewise existential projection. Along each visible sign event, the forgotten \(G\) sign must take one value that makes **both** endpoints satisfy the 52-sign necessary conditions and gives an allowed derivative for the event. The value of the forgotten sign is nevertheless allowed to reset arbitrarily between visible events. This is an over-approximation of genuine generic trajectories. It does not assert that individually feasible signs or edges glue into a trajectory.

| Visible additional sign | Forgotten sign | Edges in witness | Target sign changes |
|---|---|---:|---:|
| \(G_{56}\) | \(G_{57}\) | 184 | 14 |
| \(G_{57}\) | \(G_{56}\) | 173 | 14 |

The paths are `g56_common_hidden_path14.txt` and `g57_common_hidden_path14.txt`. Each line gives the start and end 51-sign keys, visible feature bit, move index, and a hidden-sign value which is common to the two sides of that one event. `verify_projected_51_common_path.cpp` checks every entry directly using an algebraic sign filter, the original event table, and the six independently supplied G derivatives. Both paths are tight for the saved original rank \(R\), starting at \(R=14\) and ending at \(R=0\). Therefore no nonnegative state-only prerank of maximum 13 or less can exist **on either of these particular projected graphs**.

The same verifier carries a two-state set of possible forgotten signs, allowing arbitrary forgotten-sign flips between visible events whenever their derivative direction and static endpoint signs permit, and allowing any elementary-move label at visible events. Even with these generous assumptions, the \(G_{56}\)-visible path has no lift to the 52-sign graph at visible edge 108, after eight target changes; the \(G_{57}\)-visible path has no lift at edge 79, after six target changes. Thus neither witness is a real 14-crossing trajectory. These results also do not rule out a different 51-sign abstraction, extra history information, or a direct mathematical proof using fewer features.

Reproduce from this folder:

```sh
c++ -O3 -std=c++17 -pthread projected_51_common_hidden.cpp -o projected_51_common_hidden
./projected_51_common_hidden g56
./projected_51_common_hidden g57
c++ -O3 -std=c++17 -pthread verify_projected_51_common_path.cpp -o verify_projected_51_common_path
./verify_projected_51_common_path g56
./verify_projected_51_common_path g57
```

The search uses the original state generator, rank bytes and `g_features.hpp`; the verifier independently reconstructs the algebraic sign filter and supplies the G event laws directly but still shares the original state generator and original event table. The 52-sign direct verifier provides the stronger global certificate independently of these two projected path searches.

## A short analytic obstruction extracted from the \(G_{56}\)-visible path

The shortest non-liftable contiguous window in that 184-edge path has just two visible events: \(G_{56}\) changes from positive to negative, then \(p_{134}\) changes from positive to negative. A two-sign history is not actually needed to state the resulting obstruction.

Suppose initially
\[
p_{125},p_{126},p_{134},p_{157},G_{56}>0,\qquad
p_{127},p_{234},p_{357},G_{67}<0.\tag{1}
\]
Along any finite positive trajectory on which
\[
p_{125},p_{157}>0,\qquad p_{234},p_{357},G_{67}<0\tag{2}
\]
remain strict, \(p_{134}\) cannot cross from positive to negative. Other minors and other concurrency features may change without restriction. In particular, the hypothesis does **not** require the two events in the displayed window to be consecutive.

To prove the claim, the identity
\[
p_{125}G_{67}-p_{126}G_{57}+p_{127}G_{56}=0
\]
and (1) force \(G_{57}<0\) initially. Until the first zero of \(p_{134}\), all three nonzero positive-move derivatives of \(G_{57}\) have negative sign:
\[
\partial_2G_{57}=p_{134}p_{357}<0,\quad
\partial_4G_{57}=p_{125}p_{357}<0,\quad
\partial_5G_{57}=G_{67}<0.
\]
Thus \(G_{57}\) cannot increase to a positive value before or at that first zero. But the cyclic Plücker identity
\[
G_{57}=p_{134}p_{257}-p_{234}p_{157}
\]
forces \(G_{57}=-p_{234}p_{157}>0\) at the first zero, a contradiction. The two polynomial identities and derivative laws are exact; `verify_g_features_symbolic.py` and `../new_work/audit_g_symbolic_independent.py` provide symbolic checks.

For the \(G_{57}\)-visible path, independent exhaustive analysis finds a shortest non-liftable window of ten visible events, containing one target sign change. The windows and minimality computation are reproducible by

```sh
python3 projected_history_obstruction.py g56
python3 projected_history_obstruction.py g57
```

Minimality here is only among the contiguous windows of the particular saved witness, not among all possible sign histories.
