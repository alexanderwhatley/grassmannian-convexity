// Coarse 35 minor + G67 + G56 + G57 abstract sign graph.
// Hidden F signs may reset between events, but each base event must admit
// a common hidden 50-sign lift on both sides.
#define main gc37_old_main
#include "../../trajectory_search_20261108/standalone_data_free.cpp"
#undef main
int main(){
 labels();auto tests=symbolic_events();auto fullkeys=generate_keys();auto keys=fullkeys;
 for(auto&x:keys)x&=((1ull<<36)-1);sort(keys.begin(),keys.end());keys.erase(unique(keys.begin(),keys.end()),keys.end());
 uint32_t n=keys.size();cout<<"36-sign base states="<<n<<endl;assert(n==2112000);
 Hash H(1<<23);for(uint32_t u=0;u<n;u++)H.insert(keys[u],u);
 Hash fullhash(1ull<<25);for(uint32_t u=0;u<fullkeys.size();u++)fullhash.insert(fullkeys[u],u);
 vector<atomic<uint64_t>> allowedbase(n);for(auto&x:allowedbase)x.store(0,memory_order_relaxed);
 vector<thread>workers;
 for(int th=0;th<8;th++)workers.emplace_back([&,th](){
  size_t lo=size_t(fullkeys.size())*th/8,hi=size_t(fullkeys.size())*(th+1)/8;
  for(size_t u=lo;u<hi;u++){
   uint64_t full=fullkeys[u],candidates=0,keep=0;
   for(auto e:tests)if(e.target<=35){int s=signbit(full,e.target),d=e.e.sg*signbit(full,e.e.a);if(e.e.b>=0)d*=signbit(full,e.e.b);if(s!=d)candidates|=1ull<<e.target;}
   while(candidates){int bit=__builtin_ctzll(candidates);candidates&=candidates-1;if(fullhash.find(full^(1ull<<bit))!=UINT32_MAX)keep|=1ull<<bit;}
   uint32_t p=H.find(full&((1ull<<36)-1));assert(p!=UINT32_MAX);allowedbase[p].fetch_or(keep,memory_order_relaxed);
  }
 });for(auto&t:workers)t.join();
 cout<<"PASS projected base edges have one common hidden 50-sign lift"<<endl;
 vector<uint8_t>valid(n);vector<uint32_t>dense(size_t(n)*4,UINT32_MAX),code;
 for(uint32_t u=0;u<n;u++)for(int g=0;g<4;g++)if(gvalid(keys[u],g)){
  valid[u]|=1<<g;dense[4*u+g]=code.size();code.push_back(4*u+g);
 }
 uint32_t N=code.size();cout<<"projected augmented states="<<N<<endl;
 vector<uint32_t>off(N+1),arcs;arcs.reserve(size_t(N)*8);
 for(uint32_t id=0;id<N;id++){
  uint32_t c=code[id],u=c/4;int g=c%4;uint64_t key=keys[u],full=key|(uint64_t(g)<<50),candidate=allowedbase[u].load(memory_order_relaxed);
  for(auto e:tests)if(e.target>=50){
   int bit=e.target-14;assert(e.e.a<=35||e.e.a>=50);assert(e.e.b<0||e.e.b<=35||e.e.b>=50);
   int s=signbit(full,e.target),d=e.e.sg*signbit(full,e.e.a);if(e.e.b>=0)d*=signbit(full,e.e.b);if(s!=d)candidate|=1ull<<bit;
  }
  while(candidate){int bit=__builtin_ctzll(candidate);candidate&=candidate-1;uint32_t v=u;int h=g;
   if(bit<=35){v=H.find(key^(1ull<<bit));if(v==UINT32_MAX||!(valid[v]&(1<<h)))continue;}
   else {h=g^(1<<(bit-36));if(!(valid[v]&(1<<h)))continue;}
   uint32_t dest=dense[4*v+h];assert(dest<N);arcs.push_back(dest|(uint32_t(bit==0)<<31));
  }
  off[id+1]=arcs.size();
 }
 uint32_t E=arcs.size();cout<<"distinct sign-flip edges="<<E<<endl;
 vector<uint32_t>roff(N+1);for(auto x:arcs)roff[(x&0x7fffffffu)+1]++;
 for(uint32_t i=0;i<N;i++)roff[i+1]+=roff[i];vector<uint32_t>cur=roff,rarcs(E);
 for(uint32_t u=0;u<N;u++)for(uint32_t z=off[u];z<off[u+1];z++)rarcs[cur[arcs[z]&0x7fffffffu]++]=u;
 vector<uint32_t>().swap(cur);vector<uint8_t>vis(N),next(N);vector<uint32_t>order,stack;order.reserve(N);
 for(uint32_t root=0;root<N;root++)if(!vis[root]){
  vis[root]=1;stack.push_back(root);while(!stack.empty()){
   uint32_t u=stack.back();if(uint32_t(next[u])<off[u+1]-off[u]){
    uint32_t v=arcs[off[u]+next[u]++]&0x7fffffffu;if(!vis[v]){vis[v]=1;stack.push_back(v);}
   }else{stack.pop_back();order.push_back(u);}
  }
 }
 assert(order.size()==N);vector<uint32_t>comp(N,UINT32_MAX);uint32_t nc=0,largest=0;
 for(size_t z=N;z>0;z--){uint32_t root=order[z-1];if(comp[root]!=UINT32_MAX)continue;
  comp[root]=nc;stack.push_back(root);uint32_t size=0;
  while(!stack.empty()){uint32_t u=stack.back();stack.pop_back();size++;
   for(uint32_t e=roff[u];e<roff[u+1];e++){uint32_t v=rarcs[e];if(comp[v]==UINT32_MAX){comp[v]=nc;stack.push_back(v);}}}
  largest=max(largest,size);nc++;
 }
 uint64_t internal=0;for(uint32_t u=0;u<N;u++)for(uint32_t e=off[u];e<off[u+1];e++)if((arcs[e]>>31)&&comp[u]==comp[arcs[e]&0x7fffffffu])internal++;
 cout<<"SCCs="<<nc<<" largest="<<largest<<" target-edges inside SCC="<<internal<<endl;
 uint32_t base=H.find(22994574005ull);assert(base!=UINT32_MAX);uint32_t seed=dense[4*base+2];assert(seed<N);
 vector<uint32_t>parent(N,UINT32_MAX),queue;parent[seed]=seed;queue.push_back(seed);uint32_t bad=UINT32_MAX;
 for(size_t head=0;head<queue.size()&&bad==UINT32_MAX;head++){
  uint32_t u=queue[head];for(uint32_t e=off[u];e<off[u+1];e++){
   uint32_t x=arcs[e],v=x&0x7fffffffu;if((x>>31)&&comp[u]==comp[v]){bad=u;break;}
   if(parent[v]==UINT32_MAX){parent[v]=u;queue.push_back(v);}
  }
 }
 if(bad!=UINT32_MAX){cout<<"ABSTRACT target-positive cycle reachable from alternating seed; visited="<<queue.size()<<endl;return 0;}
 if(internal){cout<<"No target cycle found from seed; visited="<<queue.size()<<endl;return 0;}
 vector<uint32_t>coff(nc+1);for(auto c:comp)coff[c+1]++;for(uint32_t c=0;c<nc;c++)coff[c+1]+=coff[c];vector<uint32_t>fill=coff,members(N);
 for(uint32_t u=0;u<N;u++)members[fill[comp[u]]++]=u;vector<int>rank(nc,0);
 for(uint32_t zz=nc;zz>0;zz--){uint32_t c=zz-1;for(uint32_t i=coff[c];i<coff[c+1];i++){
  uint32_t u=members[i];for(uint32_t e=off[u];e<off[u+1];e++){uint32_t x=arcs[e],v=x&0x7fffffffu,d=comp[v],w=x>>31;
   if(d==c){assert(!w);continue;}assert(d>c);rank[c]=max(rank[c],int(w)+rank[d]);}}
 }
 cout<<"R38-common-hidden maximum="<<*max_element(rank.begin(),rank.end())<<" alternating root="<<rank[comp[seed]]<<" reached="<<queue.size()<<endl;
}
