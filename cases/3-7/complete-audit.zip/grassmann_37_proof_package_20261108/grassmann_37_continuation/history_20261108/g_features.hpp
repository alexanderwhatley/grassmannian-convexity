// Necessary sign constraints and affine move derivatives for
// G56=p125*p346-p126*p345 and G57=p125*p347-p127*p345.
// Requires the definitions in rebuild_full_graph.cpp. Bit 35 is
// F67=p126*p347-p127*p346.
struct GFeatures {
 array<uint8_t,512>realizable{};
 array<Pairing,2>pairings6={Pairing{pair<int,int>{1,2},pair<int,int>{3,4},pair<int,int>{5,6}},
                              Pairing{pair<int,int>{1,2},pair<int,int>{3,4},pair<int,int>{5,7}}};
 vector<Event>new_events;
 GFeatures(){
  array<int,5>perm={1,2,3,4,5};int words=0;
  do{if(perm[0]!=1)continue;for(int bits=0;bits<16;bits++){
   int w[10],pos[6];for(int i=0;i<5;i++){int z=perm[i];if(z!=1&&(bits>>(z-2)&1))z=-z;w[i]=z;w[i+5]=-z;}
   for(int i=0;i<10;i++)if(w[i]>0)pos[w[i]]=i;
   auto orient=[&](int a,int b){return (pos[b]-pos[a]+10)%10<5;};
   if(!orient(1,2))continue;words++;
   bool signs[9]={orient(3,2),orient(1,3),orient(4,2),orient(1,4),orient(5,2),orient(1,5),
                  orient(3,4),orient(3,5),orient(4,5)};
   int code=0;for(int i=0;i<9;i++)if(signs[i])code|=1<<i;
   assert(!realizable[code]);realizable[code]=1;
  }}while(next_permutation(perm.begin(),perm.end()));
  assert(words==192&&count(realizable.begin(),realizable.end(),1)==192);
  new_events={{50,{pid[1][3][4],pid[3][5][6],1},2},
              {50,{pid[1][2][5],pid[3][5][6],1},4},
              {50,{51,-1,1},6},
              {51,{pid[1][3][4],pid[3][5][7],1},2},
              {51,{pid[1][2][5],pid[3][5][7],1},4},
              {51,{35,-1,1},5}};
 }
 int forced(uint64_t key,const Pairing&pp)const{
  int force=0;for(int r=0;r<3;r++){
   auto[a,b]=pp[r];auto[c,d]=pp[(r+1)%3];auto[e,f]=pp[(r+2)%3];
   int A=oriented_p(key,a,b,e)*oriented_p(key,c,d,f),B=oriented_p(key,a,b,f)*oriented_p(key,c,d,e);
   if(A!=B){if(force&&force!=A)return 2;force=A;}}
  return force;
 }
 bool pass(uint64_t key,int g)const{
  // g's low bit is sign G56, high bit sign G57.
  for(int i=0;i<2;i++){int f=forced(key,pairings6[i]),sg=(g>>i&1)?1:-1;if(f==2||(f&&f!=sg))return false;}
  const int labs[6]={pid[1][2][5],pid[3][4][5],pid[1][2][6],pid[3][4][6],pid[1][2][7],pid[3][4][7]};
  int code=0;for(int i=0;i<6;i++)if(key&(1ull<<labs[i]))code|=1<<i;
  if(g&1)code|=1<<6;if(g&2)code|=1<<7;if(key&(1ull<<35))code|=1<<8;
  return realizable[code];
 }
};
