// Independent direct check of an external 41-sign rank potential.
// Reads ONLY rank_41_unfiltered.bin. No projected edges or SCC data are read.
// Reconstructs the full 50-sign keys, exact feature derivatives and tie witness.
// No cubic sign rules are needed or imposed.
#define main gc37_old_main
#include "standalone_data_free_checked.cpp"
#undef main
#include <fstream>
#include <chrono>
int main(int argc,char**argv){
 assert(argc==2);labels();check_affine_normalization();auto tests=symbolic_events();
 auto full=generate_keys();const uint32_t n=full.size();Hash fullhash(1ull<<25);for(uint32_t u=0;u<n;u++)fullhash.insert(full[u],u);
 const uint64_t keep=((1ull<<36)-1)|(1ull<<41)|(1ull<<44)|(1ull<<47);
 vector<uint64_t>proj=full;for(auto&k:proj)k&=keep;sort(proj.begin(),proj.end());proj.erase(unique(proj.begin(),proj.end()),proj.end());
 assert(proj.size()==3378432);Hash projected(1ull<<23);for(uint32_t u=0;u<proj.size();u++)projected.insert(proj[u],u);
 vector<uint8_t>rank(size_t(proj.size())*4);ifstream input(argv[1],ios::binary);assert(input);input.read((char*)rank.data(),rank.size());assert(input.gcount()==int64_t(rank.size()));assert(input.peek()==EOF);
 vector<uint32_t>pindex(n);vector<uint8_t>valid(n);vector<thread>threads;
 for(int th=0;th<8;th++)threads.emplace_back([&,th](){size_t lo=size_t(n)*th/8,hi=size_t(n)*(th+1)/8;
  for(size_t u=lo;u<hi;u++){uint64_t k=full[u];uint32_t p=projected.find(k&keep);assert(p!=UINT32_MAX);pindex[u]=p;
   unsigned mask=0;for(int g=0;g<4;g++)if(gvalid(k,g))mask|=1u<<g;valid[u]=mask;
  }
 });for(auto&t:threads)t.join();threads.clear();
 Variation variation;uint64_t sc[8]{},bc[8]{},gc[8]{},badm[8][5]{},mcount[8][5]{};int maxr[8][5]{};
 for(int th=0;th<8;th++)threads.emplace_back([&,th](){size_t lo=size_t(n)*th/8,hi=size_t(n)*(th+1)/8;
  for(size_t u=lo;u<hi;u++)if(valid[u]){
   uint64_t base=full[u];int m=variation.karp(base);assert(0<=m&&m<=4);
   for(int g=0;g<4;g++)if(valid[u]&(1u<<g)){
    int r=rank[size_t(4)*pindex[u]+g];if(r>12){cerr<<"rank missing/out of range full="<<u<<" g="<<g<<" rank="<<r<<endl;abort();}
    sc[th]++;mcount[th][m]++;maxr[th][m]=max(maxr[th][m],r);badm[th][m]+=r>8+m;
    uint64_t ext=base|(uint64_t(g)<<50);
    for(auto e:tests){int x=signbit(ext,e.target),d=e.e.sg*signbit(ext,e.e.a);if(e.e.b>=0)d*=signbit(ext,e.e.b);if(x==d)continue;
     uint32_t v=u;int h=g;if(e.target<50){v=fullhash.find(base^(1ull<<e.target));if(v==UINT32_MAX||!(valid[v]&(1u<<h)))continue;}
     else{h=g^(1<<(e.target-50));if(!(valid[v]&(1u<<h)))continue;}
     int rr=rank[size_t(4)*pindex[v]+h];if(rr>12||r<rr+int(e.target==0)){
      cerr<<"edge failure full="<<u<<" feature="<<e.target<<" move="<<e.move<<" ranks="<<r<<','<<rr<<endl;abort();
     }
     if(e.target<50)bc[th]++;else gc[th]++;
    }
   }
  }
 });for(auto&t:threads)t.join();
 uint64_t ns=0,nb=0,ng=0;for(int t=0;t<8;t++){ns+=sc[t];nb+=bc[t];ng+=gc[t];}
 assert(ns==23246848&&nb==209042944&&ng==21586944);
 cout<<"PASS 0<=rank<=12 on "<<ns<<" unfiltered full 52-sign states"<<endl;
 cout<<"PASS direct rank inequalities on "<<nb<<" base and "<<ng<<" G move-labeled edges"<<endl;
 const uint64_t expected_counts[5]={7991104,12397835,2793874,63999,36};
 cout<<"m maxima / rank>8+m full-state counts";for(int m=0;m<5;m++){int mr=0;uint64_t bad=0,tot=0;for(int t=0;t<8;t++){mr=max(mr,maxr[t][m]);bad+=badm[t][m];tot+=mcount[t][m];}assert(mr==8+m&&bad==0&&tot==expected_counts[m]);cout<<' '<<m<<':'<<mr<<'/'<<bad<<'/'<<tot;}cout<<endl;
 cout<<"PASS exact per-m maxima, zero violations, and state counts"<<endl;
}
