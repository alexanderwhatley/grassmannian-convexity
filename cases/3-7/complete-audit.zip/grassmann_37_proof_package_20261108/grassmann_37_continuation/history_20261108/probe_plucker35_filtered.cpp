// Explore the coarser 35-Pluecker-sign event graph; abstract paths only.
#define main gc37_old_main
#include "../../trajectory_search_20261108/standalone_data_free.cpp"
#undef main
#include <fstream>
int main(int argc,char**argv){
 int mode=argc>1?atoi(argv[1]):0;assert(mode>=0&&mode<=2);
 labels();auto tests=symbolic_events();auto full=generate_keys();
 for(auto&k:full)k&=((1ull<<35)-1);sort(full.begin(),full.end());full.erase(unique(full.begin(),full.end()),full.end());
 uint32_t N=full.size();cout<<"unique Pluecker sign patterns="<<N<<endl;assert(N==1743360);
 Hash H(1<<22);for(uint32_t u=0;u<N;u++)H.insert(full[u],u);
 uint64_t altmask=0;for(int b=0;b<35;b++){auto p=plabs[b];if((p[0]+p[1]+p[2])&1)altmask|=1ull<<b;}
 auto idealmask=[&](uint64_t k){int m=0;
  for(int start=1;start<=4;start++){
   bool good=true;
   for(int a=start;a<=7&&good;a++)for(int b=a+1;b<=7&&good;b++)for(int c=b+1;c<=7&&good;c++){
    int I[3]={a,b,c},v=pid[a][b][c];if(!((k>>v)&1))continue;
    for(int i=0;i<3;i++){int J[3]={a,b,c};J[i]++;if(J[i]>7||(i<2&&J[i]>=J[i+1]))continue;
     int w=pid[J[0]][J[1]][J[2]];if(!((k>>w)&1)){good=false;break;}}
   }
   if(good)m|=1<<(start-1);
  }return uint8_t(m);
 };
 vector<uint8_t>idirect(N),ireverse(N);if(mode)for(uint32_t u=0;u<N;u++){
  idirect[u]=idealmask(full[u]);ireverse[u]=idealmask(full[u]^altmask);
 }
 vector<uint32_t>off(N+1);vector<uint32_t>arcs;arcs.reserve(size_t(N)*7);
 for(uint32_t u=0;u<N;u++){
  uint64_t key=full[u],candidate=0;
  for(auto e:tests)if(e.target<35){int a=signbit(key,e.target),b=e.e.sg*signbit(key,e.e.a);assert(e.e.b<0);if(a!=b)candidate|=1ull<<e.target;}
  while(candidate){int bit=__builtin_ctzll(candidate);candidate&=candidate-1;uint32_t v=H.find(key^(1ull<<bit));
   if(v==UINT32_MAX)continue;
   if(mode>=1&&(idirect[u]&~idirect[v]))continue;
   if(mode>=2&&(ireverse[v]&~ireverse[u]))continue;
   arcs.push_back(v|(uint32_t(bit==0)<<31));}
  off[u+1]=arcs.size();
 }
 uint32_t E=arcs.size();cout<<"distinct sign-flip edges="<<E<<endl;
 vector<uint32_t>roff(N+1);for(auto x:arcs)roff[(x&0x7fffffffu)+1]++;
 for(uint32_t i=0;i<N;i++)roff[i+1]+=roff[i];vector<uint32_t>cur=roff,rarcs(E);
 for(uint32_t u=0;u<N;u++)for(uint32_t z=off[u];z<off[u+1];z++)rarcs[cur[arcs[z]&0x7fffffffu]++]=u;
 vector<uint32_t>().swap(cur);vector<uint8_t>vis(N),next(N);vector<uint32_t>order,stack;order.reserve(N);
 for(uint32_t root=0;root<N;root++)if(!vis[root]){
  vis[root]=1;stack.push_back(root);
  while(!stack.empty()){
   uint32_t u=stack.back();if(uint32_t(next[u])<off[u+1]-off[u]){
    uint32_t v=arcs[off[u]+next[u]++]&0x7fffffffu;if(!vis[v]){vis[v]=1;stack.push_back(v);}
   }else{stack.pop_back();order.push_back(u);}
  }
 }
 assert(order.size()==N);vector<uint32_t>comp(N,UINT32_MAX);uint32_t nc=0,largest=0;
 for(size_t z=N;z>0;z--){uint32_t root=order[z-1];if(comp[root]!=UINT32_MAX)continue;
  comp[root]=nc;stack.push_back(root);uint32_t size=0;
  while(!stack.empty()){uint32_t u=stack.back();stack.pop_back();size++;
   for(uint32_t e=roff[u];e<roff[u+1];e++){uint32_t v=rarcs[e];if(comp[v]==UINT32_MAX){comp[v]=nc;stack.push_back(v);}}}
  largest=max(largest,size);nc++;
 }
 uint64_t internal=0;for(uint32_t u=0;u<N;u++)for(uint32_t e=off[u];e<off[u+1];e++)if((arcs[e]>>31)&&comp[u]==comp[arcs[e]&0x7fffffffu])internal++;
 cout<<"mode="<<mode<<" SCCs="<<nc<<" largest="<<largest<<" target-edges inside SCC="<<internal<<endl;
 uint32_t seed=H.find(22994574005ull);assert(seed!=UINT32_MAX);
 if(internal==0){
  vector<uint32_t>coff(nc+1);for(auto c:comp)coff[c+1]++;
  for(uint32_t c=0;c<nc;c++)coff[c+1]+=coff[c];vector<uint32_t>fill=coff,members(N);
  for(uint32_t u=0;u<N;u++)members[fill[comp[u]]++]=u;vector<int>rank(nc,0);
  for(uint32_t zz=nc;zz>0;zz--){uint32_t c=zz-1;
   for(uint32_t i=coff[c];i<coff[c+1];i++){uint32_t u=members[i];
    for(uint32_t e=off[u];e<off[u+1];e++){uint32_t x=arcs[e],v=x&0x7fffffffu,d=comp[v],w=x>>31;
     if(d==c){assert(!w);continue;}assert(d>c);rank[c]=max(rank[c],int(w)+rank[d]);
    }
   }
  }
  int maxrank=*max_element(rank.begin(),rank.end());cout<<"R35 maximum="<<maxrank<<" alternating root="<<rank[comp[seed]]<<endl;
  vector<uint64_t>hist(maxrank+1);for(auto c:comp)hist[rank[c]]++;cout<<"rank histogram";for(size_t i=0;i<hist.size();i++)cout<<' '<<i<<':'<<hist[i];cout<<endl;
 }
 vector<uint32_t>parent(N,UINT32_MAX),queue;parent[seed]=seed;queue.push_back(seed);
 uint32_t start=UINT32_MAX,dest=UINT32_MAX;
 for(size_t head=0;head<queue.size()&&start==UINT32_MAX;head++){
  uint32_t u=queue[head];for(uint32_t e=off[u];e<off[u+1];e++){
   uint32_t x=arcs[e],v=x&0x7fffffffu;if((x>>31)&&comp[u]==comp[v]){start=u;dest=v;break;}
   if(parent[v]==UINT32_MAX){parent[v]=u;queue.push_back(v);}
  }
 }
 if(start==UINT32_MAX){cout<<"No target cycle reachable; visited="<<queue.size()<<endl;return 0;}
 vector<uint32_t>prefix;for(uint32_t u=start;;u=parent[u]){prefix.push_back(u);if(u==seed)break;}reverse(prefix.begin(),prefix.end());
 fill(parent.begin(),parent.end(),UINT32_MAX);queue.clear();parent[dest]=dest;queue.push_back(dest);
 for(size_t head=0;head<queue.size()&&parent[start]==UINT32_MAX;head++){
  uint32_t u=queue[head];for(uint32_t e=off[u];e<off[u+1];e++){
   uint32_t v=arcs[e]&0x7fffffffu;if(comp[v]==comp[start]&&parent[v]==UINT32_MAX){parent[v]=u;queue.push_back(v);}
  }
 }
 assert(parent[start]!=UINT32_MAX);vector<uint32_t>cycle;for(uint32_t u=start;;u=parent[u]){cycle.push_back(u);if(u==dest)break;}reverse(cycle.begin(),cycle.end());
 ofstream out("moment_35_target_cycle.txt");
 auto printedge=[&](uint32_t u,uint32_t v){uint64_t a=full[u],b=full[v];int bit=__builtin_ctzll(a^b),move=0;
  for(auto e:tests)if(e.target==bit){int s=signbit(a,e.target),d=e.e.sg*signbit(a,e.e.a);if(s!=d){move=e.move;break;}}
  assert(move);out<<a<<' '<<b<<' '<<bit<<' '<<move<<'\n';};
 out<<"# prefix "<<prefix.size()-1<<"\n";for(size_t i=1;i<prefix.size();i++)printedge(prefix[i-1],prefix[i]);
 out<<"# positive cycle "<<cycle.size()<<"\n";printedge(start,dest);for(size_t i=1;i<cycle.size();i++)printedge(cycle[i-1],cycle[i]);
 cout<<"ABSTRACT target cycle reachable from moment start; prefix edges="<<prefix.size()-1<<" cycle edges="<<cycle.size()<<" comp="<<comp[start]<<endl;
}
