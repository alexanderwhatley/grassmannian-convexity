# Every 28-move extremal path has one generator profile

The exact 28-move minimum is established in `minimum_moves_28.md`. This additional computer-assisted result shows that every 28-move, 12-flip path has the single profile
\[
 \#U_1=2,\quad \#U_5=2,\quad \#U_6=1,\quad
 \#U_3=12,\quad \#U_2+\#U_4=11.\tag{1}
\]
An exact rational 28-move witness and an all-integer version realize this profile; see `trajectory_search_20261108/witness_28_simplified.json` and `witness_28_integer.json`. Separately, the coarser first-six-minor abstraction admits the abstract path `abstract_28_six_path.txt`; those formal events are not the real witness. Its G56-sign history becomes impossible at edge 19 even under a generous hidden-event monitor; see `monitor_28_path_G56.py/.log`.

## A stronger first-six-sign computation

The certified `(3,7)` bound `r<=8+m` implies that any 12-flip path starts in the alternating chamber. Normalize `p567>0`. Its initial 20 maximal minors among the first six columns therefore have signs `(-1)^(i+j+k)`, encoded in lexicographic order by the integer `346837`.

Every real strict 3-by-6 sign pattern satisfies the 30 necessary three-term Grassmann–Plücker sign relations, one for each fixed index and each choice of four of the other five indices. Exactly **23,808** of the `2^20` patterns satisfy these tests. A positive `U_j`, `j=1,...,5`, can flip a minor `p_I` only if `j in I`, `j+1 notin I`, and the signs of `p_I` and `p_{I\setminus j\cup(j+1)}` oppose. Keeping transitions with necessary-valid source and destination gives **115,200** move-labeled single-feature edges.

A `U6` move changes only the sixth of these columns. We relax it to an arbitrary jump between any two necessary states that agree on the ten first-five-column minor signs. A state can make at most one such jump. This loses information and therefore only adds formal paths.

In addition, permit at most one contiguous event-run labeled `U1` and at most three runs labeled `U5`, while allowing **unbounded** numbers of events labeled `U2`, `U3` and `U4`. Each run is allowed to contain arbitrarily many successive events of its label; a single physical shear can indeed cross several minor walls. Sign-silent physical moves are omitted and can only merge visible runs, so visible run counts never exceed actual move counts. A relaxed `U6` jump ends the current run.

A finite longest-path relaxation from the alternating source, with these bounds and arbitrary final sign state, gives **at most 11 target changes**. Two separately written implementations give the same 23,808 states and 115,200 edges:

* `m1_analytic_20261108/probe_3x6_runs_29.cpp` uses an explicit before/inside-run automaton and broadcasts a relaxed jump only when its group and budgets receive a better score.
* `verify_3x6_runs_independent.cpp` instead stores the last visible event label and computes the same bounded-run closure independently. Its check visits 1,311,823 queue states and performs 7,366 group broadcasts.

Both begin from the single alternating sign source and check all reachable transitions. The group broadcast is safe because a `U6` jump forgets every first-six sign involving column 6, preserves exactly the ten first-five signs, consumes its single jump and resets the run mode; among equal group/budget states the larger target count dominates the smaller.

Generic event coverage is exact: `m1_analytic_20261108/verify_3x6_event_separation.py` exhibits one integer matrix on which all 75 same-generator active-minor root resultants are nonzero. Each corresponding polynomial is therefore nonzero, so a small perturbation of any fixed finite generic trajectory separates these events without changing its strict recorded target signs. Prefix products are invertible, and their first-six-column projections are surjective as the initial seven-column matrix varies. Hence the finite graph over-approximates all real trajectories of the stated type.

## Consequence for 28 moves

The proof of `minimum_moves_28.md` shows that 12 target flips require at least 12 `U3` moves, 11 `U2/U4` separators, one `U6`, one `U1`, and two `U5`; it also shows `#U1+#U5>=4`. If there are exactly 28 total moves, every one of these lower bounds is tight. Thus `#U6=1`, `#U3=12`, `#U2+#U4=11`, and the only possibilities for `(#U1,#U5)` are `(1,3)` and `(2,2)`. The first-six-sign computation excludes `(1,3)` even with no restrictions on the number of other interior events. This proves (1).

## Reproduction

From the workspace root:

```sh
c++ -std=c++17 -O3 -pthread m1_analytic_20261108/probe_3x6_runs_29.cpp -o /tmp/gc37_runs_a
/tmp/gc37_runs_a 1 3
c++ -std=c++17 -O3 grassmann_37_continuation/history_20261108/verify_3x6_runs_independent.cpp -o /tmp/gc37_runs_b
/tmp/gc37_runs_b 1 3
python3 m1_analytic_20261108/verify_3x6_event_separation.py
```

The independent output is saved in `verify_3x6_runs_independent.log`. The calculation is a finite sign-graph obstruction; the published rank-two and separately checked `(3,7)` certificates remain explicit mathematical dependencies.
