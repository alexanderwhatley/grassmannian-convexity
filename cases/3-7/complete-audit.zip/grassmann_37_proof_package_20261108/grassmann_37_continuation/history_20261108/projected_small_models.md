# Smaller sign projections tested for the `(3,7)` upper bound

The checked 52-sign graph remains the primary upper-bound certificate. This note records reproducible tests of smaller state models, including a successful 41-sign projection. All paths and longest-path ranks below are abstract: the forgotten signs can reset between visible events, so none of these results asserts a real trajectory with more than 12 target changes.

All models start from the actual alternating moment-curve matrix with nodes `(1,2,4,8,16,32,64)` and columns `(-1)^i(1,t_i,t_i^2)`. The 35-minor word is `22994574005`, and its complete old 50-sign word is `625507671825077`. Generic perturbation and the explicitly verified nonzero event resultants ensure that every genuine finite trajectory is represented in these over-approximations.

## Minor signs alone

Projecting the necessary 50-sign state generator onto the 35 maximal-minor signs yields 1,743,360 states and 9,467,904 labeled-feature-flip edges. Its directed graph has 246,088 strongly connected components, no target-weight edge inside an SCC, and exact longest target-path rank **24** from the alternating start. All 1,743,360 formal states are reachable from that start. `probe_plucker35_filtered.cpp` computes these results directly.

We also imposed the independently proved monotonicity of the negative-minor order-ideal predicate for each suffix, both forward and backward under alternating reorientation. These necessary rules reject **zero** edges in this particular minor-sign graph: its static Plücker conditions already enforce them locally. Thus the 35-sign model cannot prove the desired 12 bound merely by adding these one-step ideal filters. The modes and outputs are in `probe_plucker35_mode0.log`, `probe_plucker35_mode1.log`, and `probe_plucker35_mode2.log`.

## Keep three concurrency signs, forget the other 14

Use all 35 minor signs, the old feature `F35=G67=F_{12,34}^{67}`, and the additional signs `G56=F_{12,34}^{56}` and `G57=F_{12,34}^{57}`. For a visible event, require **one common hidden 52-sign lift** on both sides, with an eligible derivative. The hidden 14 old feature signs may be reset arbitrarily between visible events. In the stronger versions, both common lifts must also obey every one of the 816 oriented cubic sign rules from `cubic_filtered_graph_note.md`.

The common-hidden model without cubic rules has 3,110,400 states, 17,038,208 edges and maximum rank 16 from the alternating start. Imposing all cubic rules reduces this to 3,023,360 states, 16,711,104 edges and 330,042 SCCs; its exact rank from the same initial state is still **16**. There are no target-weight edges internal to an SCC. See `probe_plucker38_common.cpp/.log` and `probe_plucker38_cubic.cpp/.log`.

The still coarser model that simply forgets the unknown derivative sign of `G67` has rank 24; even imposing all direct and cubic sign implications that force this derivative retains rank 24. Those probes are `probe_plucker38_graph.cpp/.log` and `probe_plucker38_forced.cpp/.log`.

## Add one, two or three old F signs

Let `F_{ab,cd}^{67}=p_{ab6}p_{cd7}-p_{ab7}p_{cd6}`. The generator's indices used here are
\[
 F36=F_{13,24}^{67},\quad F37=F_{14,23}^{67},\quad
 F38=F_{12,35}^{67},\quad F39=F_{13,25}^{67},\quad
 F40=F_{15,23}^{67},\quad F41=F_{12,45}^{67},\quad F44=F_{13,45}^{67},\quad F47=F_{23,45}^{67}.
\]
`F38` is natural to try first because it controls a derivative of `G67`. In every row below, the 38-sign core and the displayed features are retained; hidden signs again admit one common cubic-valid lift for each visible edge and can reset between events.

| Added signs | Formal states | Visible edges | SCCs | Alternating-start rank |
|:---|---:|---:|---:|---:|
| F38 | 3,552,512 | 19,849,696 | 353,870 | 16 |
| F38,F36 | 4,326,400 | 24,597,168 | 369,016 | 16 |
| F38,F37 | 4,326,400 | 24,591,728 | 375,286 | 16 |
| F38,F39 | 4,317,312 | 24,565,744 | 372,136 | 16 |
| F38,F36,F37 | 5,244,416 | 30,336,128 | 390,432 | 16 |
| F38,F36,F39 | 5,091,200 | 29,182,656 | 388,216 | 16 |
| F38,F39,F40 | 5,238,016 | 30,374,208 | 404,384 | 16 |
| F41 | 3,552,512 | 19,777,856 | 370,928 | 16 |
| F44 | 3,659,008 | 20,537,856 | 357,024 | 16 |
| F41,F44 | 4,188,160 | 23,566,208 | 397,904 | 16 |
| F41,F44,F38 | 4,823,296 | 27,408,944 | 423,312 | 16 |
| F41,F44,F47 | 4,823,808 | 27,299,328 | 439,286 | **12** |

The model is conservative: all 50 base signs are reconstructed first, both values of each additional G are checked against necessary static identities, and the cubic rules are applied before projecting. For each retained base-feature flip, the construction requires the same full hidden 50-sign assignment on both sides and the same allowed G values; G flips likewise require one common hidden assignment. Forgetting the hidden history between edges can only add paths.

These are selected feature sets, not an exhaustive search over all subsets of one to three old F signs. The source `probe_projection_more_F.cpp` and logs `probe_projection_F38*.log`, `probe_projection_F41*.log` and `probe_projection_F44.log` preserve the exact counts. A 300-edge rank-16 path in the 38-sign core is eliminated by either F41 or F44 separately, even under a generous independent hidden-sign monitor; the full searches above show that other rank-16 paths survive. From this directory:

```sh
c++ -O3 -std=c++17 -pthread probe_projection_more_F.cpp -o probe_projection_more_F
./probe_projection_more_F 38
./probe_projection_more_F 38 36 37
./probe_projection_more_F 38 36 39
./probe_projection_more_F 38 39 40
./probe_projection_more_F 41 44 38
./probe_projection_more_F 41 44 47
```

The source includes the data-free 52-sign generator in `../../trajectory_search_20261108/standalone_data_free.cpp` and the necessary-rule header `cubic_all_filter.hpp`; it reads no input data. An abstract rank-16 path from the 38-sign core, used for feature-selection diagnostics, is written by `extract_projection38_rank16.cpp` when run successfully.

The successful `F41,F44,F47` model still works **without** the cubic rules: it has 4,960,256 projected states, 27,866,144 edges, and rank 12. Its pointwise bound is \(H_{41}\le8+m\). The rank and all full 52-sign move-labeled edges are checked directly in `41_sign_unfiltered_certificate.md`. These are counts of projected potential states; the construction and verification still enumerate the full hidden-state model.

The common hidden lift on *each edge* matters for this projection. `probe_rank41_local_derivative.cpp` uses the same projected states but permits a visible event whenever both visible endpoints exist and its derivative has the right sign; when a derivative uses a forgotten feature it permits either sign, without requiring one hidden full-state assignment common to both ends. This coarser graph has 28,190,112 edges, 395,604 SCCs, no target edge inside an SCC, and exact alternating-start rank **20**. Its formal path is not a real-trajectory construction. Reproduce from this directory:

```sh
c++ -O3 -std=c++17 -pthread probe_rank41_local_derivative.cpp -o probe_rank41_local_derivative
./probe_rank41_local_derivative 41 44 47
```

The output is preserved in `probe_rank41_local_derivative.log`. This is a negative result for this particular weakening, not an obstruction to a different 41-sign proof.
