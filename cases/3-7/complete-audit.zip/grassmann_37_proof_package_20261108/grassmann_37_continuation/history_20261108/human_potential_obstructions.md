# Two concrete obstructions to simple upper-bound potentials

These examples do not challenge the independently checked `(3,7)` upper bound. They rule out two tempting routes to a short proof, including when one restricts attention to trajectories from a fixed alternating start.

## Maximum sign variation along the minor poset is not monotone

Partially order the three-element subsets of `{1,...,7}` componentwise, so a cover increments one index by one. Every saturated chain from `123` to `567` has 12 edges. For a generic matrix let
\[
 V(M)=\max_{\text{saturated }123\leadsto567}
       \#\{\text{sign changes of successive }p_I\}.
\]
For an alternating matrix `V=12`, and `V` has the parity of the sign discrepancy between `p123` and `p567`. Nevertheless it is not a prerank.

Take the columns
\[
\begin{aligned}
&v_1=(3,-1,-4),\quad v_2=(-6,-1,-6),\quad v_3=(-7,4,-3),\\
&v_4=(-7,1,-1),\quad v_5=(-8,3,7),\quad v_6=(1,0,6),\quad v_7=(7,0,5),
\end{aligned}
\]
and perform the positive move `v2 <- v2+v3`. The least absolute value among the 35 maximal minors is 5 before the move and 3 afterward; both matrices are generic. At both endpoints `p123=181` and `p567=111`.

Before the move, the first edge of every chain, `123 -> 124`, has the same positive sign at both ends. The last two edges have the form
\[
 367\ \text{or}\ 457\;\longrightarrow\;467\longrightarrow567,
\]
and all four of these minors are positive. Thus at least three of the 12 edges of every chain do not change sign. Since the endpoints have the same sign, the number of sign changes is even, hence at most 8. The chain
\[
 123,124,134,135,145,146,156,256,356,456,457,467,567
\]
has signs `++--+-+-+-+++` and achieves eight; hence `V=8`.

After the move, the chain
\[
 123,124,125,135,145,146,246,256,356,456,457,467,567
\]
has signs `+-+-+-+-+-+++` and achieves ten. The last two edges are unchanged and have no sign change, so `V=10`. The move is target-silent but **raises** `V` by two. An independent direct exact replay, including all 35 minors and the dynamic-programming rank, is `verify_human_potential_obstructions.py` with output `verify_human_potential_obstructions.log`; the original search is `search_poset_variation_potential.py`.

This counterexample also occurs, up to invertible row operations and positive diagonal column scalings, in a trajectory from *any prescribed* generic alternating start. Indeed, the elementary backward-extension theorem in `elementary_positive_chart_and_global_rank.md` takes some alternating start to this matrix; the positive-cell transfer sends the prescribed alternating start to a row/positive-column scaling of that other start, after which the extension and this single move replay with positive rescaled parameters. These transformations preserve all sign comparisons in `V` and all target changes. Thus fixing a particularly simple alternating moment curve does not make this potential monotone on its reachable states.

## Maximum chain variation can exceed the true rank

The same `V` is not even a lower bound for the true future rank. Take the planar columns
\[
\begin{gathered}
 (74,-51,1),(78,-45,1),(-26,-12,1),(-14,66,1),\\
 (-60,-81,1),(56,-74,1),(56,-37,1).
\end{gathered}
\]
All 35 maximal minors are nonzero. The chain
\[
 123,124,134,234,235,236,237,247,347,357,457,467,567
\]
has signs `++--++-+-++++` and six changes; the finite chain recurrence confirms `V=6`. Yet the actual rank is **exactly four**, for an entirely separate analytic reason.

For the upper bound use the fixed functional `omega=(450,-271,26187)`. Its values on the seven columns are
\[
 (73308,73482,17739,2001,21138,71441,61414),
\]
all positive. Project the six adjacent differences to `ker omega`, as in `monotone_suffix_halfspace_prerank.md`; the projected cyclic word, with the last pair positively oriented, is
\[
 (-2,5,1,6,-4,3,2,-5,-1,-6,4,-3).
\]
Its five signed short steps are `(4,-1,5,3,2)`. The run lengths are `(4,1,10)`, so the rank-two cyclic prerank is `2 floor(10/6)+3-1=4`. No scalar pole is possible while the fixed functional is positive on every column, hence this is a valid upper bound of four on all future `p123` changes.

For the lower bound apply the pencil-variation theorem `m1_analytic_20261108/pencil_variation_lower_bound.md` with `S={3,4}`. In the theorem's order the values are
\[
 (p_{123},p_{134},p_{234},p_{345},p_{346},p_{347},p_{567})
 =(756,-8268,-8508,1824,-7140,-6696,4292),
\]
whose signs `+--+--+` have four changes. Thus the true rank is at least four and therefore exactly four. This conclusion uses neither the 52-sign graph nor its rank. As an optional consistency check, that graph assigns the actual augmented sign state rank four as well.

The direct rational/integer checks, including the functional values, cyclic word, Plücker signs, and pencil, are in `verify_human_potential_obstructions.py/.log`.

## The target polynomial is not a stable polynomial

Take the alternating moment-curve columns `v_i=(-1)^i(1,t_i,t_i^2)` with
`(t_1,...,t_7)=(1,2,4,8,16,32,64)`. The exact target polynomial for two moves is
\[
 p_{123}(M U_4(x)U_3(y))=6-42y+210xy.
\]
Changing variables `x,y` to `-x,-y` makes every nonzero coefficient positive:
\[
 F(x,y)=6+42y+210xy.
\]
But `F` is not real stable: at `x=i` and `y=(-1+5i)/182` both variables have strictly positive imaginary part and `F=0`. Equivalently, its bivariate Rayleigh expression is `F_x F_y-F F_{xy}=-1260`.

The phenomenon is universal, not an artifact of these nodes. From any alternating `(k,n)` start with `k(n-k)>=2`, choose consecutive generators `(k+1,k)` if `n-k>=2`, or `(k-1,k)` if `n-k=1`. After normalizing an overall sign and changing both variables' signs, the target polynomial has the form `a+b y+c xy` with `a,b,c>0`. It vanishes at `x=i`, `y=-a/(b+ci)`, both in the upper half-plane. Therefore standard real-stability or positive-semidefinite-pencil monotonicity cannot simply be assumed for these elementary-move parameter polynomials.

Even total degree and alternating coefficient signs alone are insufficient to bound the number of zeros along a coordinatewise increasing path. For example
\[
 f=1-x_1-x_2-x_3-x_4+100x_1x_2+100x_3x_4
\]
has degree 2 and the alternating coefficient-sign property, but its sign follows `+,-,+,-,+` as the nonnegative variables are successively raised to `(2,1/10,30,1)`, giving four crossings. This last polynomial is an abstract example, not claimed to be a Grassmannian target polynomial.
