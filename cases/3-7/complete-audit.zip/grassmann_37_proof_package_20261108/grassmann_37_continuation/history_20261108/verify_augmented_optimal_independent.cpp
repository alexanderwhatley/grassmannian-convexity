// Independent direct and reverse-reachability audit of the optimal 52-sign rank.
// and every move-labeled augmented edge, using only algebraic sign filters.
// Shares the old 50-sign state enumerator/rank file, but does not include
// g_features.hpp, g_tight_search.cpp, the SCC code, or the G-search BFS.
// The old event table and the new six events are read/reconstructed directly.
// Run from this directory, after g_reachable_50_nohalf.bin has been created.
#define main gc37_graph_unused_main
#include "../rebuild_full_graph.cpp"
#undef main

struct Test {int move,target,a,b,sg;};
int main(){
 init();auto dirs=direction_types(true);auto masks=sign_masks();Hash H(1ull<<25);
 vector<uint64_t>keys;keys.reserve(16051200);
 for(auto&w:dirs)for(auto&z:add_axes(w)){uint64_t base=word_key(z);for(auto mask:masks){uint64_t k=base^mask;H.insert(k,keys.size());keys.push_back(k);}}
 uint32_t n=keys.size();assert(n==16051200);
 vector<uint8_t>rank(uint64_t(n)*4),allowed(n);
 ifstream rf("../new_work/augmented_optimal_rank.bin",ios::binary);rf.read((char*)rank.data(),rank.size());assert(rf.gcount()==int64_t(rank.size()));char ch;assert(!rf.read(&ch,1));
 // Independently build the filter from direct product-sign implications
 // and the two exact 3-term identities A5*G67-A6*G57+A7*G56=0
 // and B5*G67-B6*G57+B7*G56=0.  These are only necessary for the proof.
 array<uint8_t,512>qsign{},integer_realized{};
 for(int code=0;code<512;code++){
  int s[9];for(int i=0;i<9;i++)s[i]=(code>>i&1)?1:-1;
  auto forced=[](int a,int b,int want){return a==b||a==want;};
  if(!forced(s[0]*s[3],s[2]*s[1],s[6])||!forced(s[0]*s[5],s[4]*s[1],s[7])||
     !forced(s[2]*s[5],s[4]*s[3],s[8]))continue;
  if(abs(s[0]*s[8]-s[2]*s[7]+s[4]*s[6])==3)continue;
  if(abs(s[1]*s[8]-s[3]*s[7]+s[5]*s[6])==3)continue;
  qsign[code]=1;
 }
 assert(count(qsign.begin(),qsign.end(),1)==192);
 // As a diagnostic, every allowed pattern is realized by an explicit
 // integer triple and no other pattern is produced.
 vector<pair<int,int>>coords;
 for(int a:{-3,-2,-1,1,2,3})for(int b:{-3,-2,-1,1,2,3})coords.emplace_back(a,b);
 for(auto[a,b]:coords)for(auto[c,d]:coords)for(auto[e,f]:coords){
  int g56=a*d-c*b,g57=a*f-e*b,g67=c*f-e*d;if(!g56||!g57||!g67)continue;
  int vals[9]={a,b,c,d,e,f,g56,g57,g67},code=0;for(int i=0;i<9;i++)if(vals[i]>0)code|=1<<i;integer_realized[code]=1;
 }
 assert(integer_realized==qsign);
 auto orient=[&](uint64_t k,int a,int b,int c){
  int inv=(a>b)+(a>c)+(b>c);array<int,3>z={a,b,c};sort(z.begin(),z.end());
  int s=(k>>pid[z[0]][z[1]][z[2]]&1)?1:-1;return inv&1?-s:s;
 };
 auto necessary=[&](uint64_t key,int g){
  const int psign[6]={pid[1][2][5],pid[3][4][5],pid[1][2][6],pid[3][4][6],pid[1][2][7],pid[3][4][7]};
  int code=0;for(int i=0;i<6;i++)if(key>>psign[i]&1)code|=1<<i;
  if(g&1)code|=1<<6;if(g&2)code|=1<<7;if(key>>35&1)code|=1<<8;
  if(!qsign[code])return false;
  // Use all three equivalent bracket expressions for each G.  Whenever
  // the two product signs oppose, their difference has a forced sign.
  for(int i=0;i<2;i++){
   pair<int,int> pp[3]={{1,2},{3,4},{5,i?7:6}};int want=(g>>i&1)?1:-1;
   for(int t=0;t<3;t++){
    auto[a,b]=pp[t];auto[c,d]=pp[(t+1)%3];auto[e,f]=pp[(t+2)%3];
    int A=orient(key,a,b,e)*orient(key,c,d,f),B=orient(key,a,b,f)*orient(key,c,d,e);
    if(A!=B&&A!=want)return false;
   }
  }
  return true;
 };

 vector<thread>threads;for(int th=0;th<8;th++)threads.emplace_back([&,th](){
  size_t lo=size_t(n)*th/8,hi=size_t(n)*(th+1)/8;
  for(size_t u=lo;u<hi;u++){uint8_t m=0;for(int g=0;g<4;g++)if(necessary(keys[u],g))m|=1u<<g;allowed[u]=m;}
 });for(auto&t:threads)t.join();threads.clear();
 vector<Test>tests;ifstream et("../event_table.txt");Test e;
 while(et>>e.move>>e.target>>e.a>>e.b>>e.sg)if(e.target<50)tests.push_back(e);assert(tests.size()==108);
 tests.push_back({2,50,pid[1][3][4],pid[3][5][6],1});tests.push_back({4,50,pid[1][2][5],pid[3][5][6],1});tests.push_back({6,50,51,-1,1});
 tests.push_back({2,51,pid[1][3][4],pid[3][5][7],1});tests.push_back({4,51,pid[1][2][5],pid[3][5][7],1});tests.push_back({5,51,35,-1,1});
 for(auto&e:tests)assert(e.a!=e.target && e.b!=e.target);
 vector<uint32_t>seeds[8];uint64_t hist[8][13]{},edgecounts[8][2]{};
 for(int th=0;th<8;th++)threads.emplace_back([&,th](){
  size_t lo=size_t(n)*th/8,hi=size_t(n)*(th+1)/8;
  for(size_t u=lo;u<hi;u++)for(int g=0;g<4;g++){
   uint32_t code=4*u+g;bool valid=allowed[u]&(1u<<g);int r=rank[code];
   if(!valid){assert(r==255);continue;}assert(r>=0&&r<=12);hist[th][r]++;uint64_t base=keys[u],key=base|(uint64_t(g)<<50);
   for(const Test&e:tests){
    int s=(key>>e.target&1)?1:-1,d=e.sg*((key>>e.a&1)?1:-1);if(e.b>=0)d*=((key>>e.b&1)?1:-1);if(s==d)continue;
    uint32_t v=u;int h=g,w=e.target==pid[1][2][3];if(e.target<50){v=H.find(base^(1ull<<e.target));if(v==UINT32_MAX)continue;}
    else h^=1<<(e.target-50);if(!(allowed[v]&(1u<<h)))continue;int q=rank[4*v+h];assert(q!=255);
    if(r<q+w){cerr<<"rank violation "<<code<<"->"<<4*v+h<<" feature="<<e.target<<"\n";abort();}
    edgecounts[th][e.target>=50]++;if(w&&r==q+1)seeds[th].push_back(code);
   }
  }
 });for(auto&t:threads)t.join();threads.clear();
 uint64_t nstates=0,npositive=0,baseedges=0,gedges=0;for(int th=0;th<8;th++){baseedges+=edgecounts[th][0];gedges+=edgecounts[th][1];for(int r=0;r<=12;r++){nstates+=hist[th][r];if(r)npositive+=hist[th][r];}}
 assert(nstates==23246848&&baseedges==209042944&&gedges==21586944);
 cout<<"PASS exact rank range and all inequalities on "<<nstates<<" states, "<<baseedges<<" base edges, "<<gedges<<" G edges\n";
 cout<<"rank histogram";for(int r=0;r<=12;r++){uint64_t c=0;for(int th=0;th<8;th++)c+=hist[th][r];cout<<' '<<r<<':'<<c;}cout<<endl;
 vector<uint8_t>seen((uint64_t(n)*4+7)/8);vector<uint32_t>queue;queue.reserve(npositive);
 auto add=[&](uint32_t code){uint8_t b=1u<<(code%8);if(seen[code/8]&b)return false;seen[code/8]|=b;queue.push_back(code);return true;};
 for(auto&v:seeds)for(uint32_t code:v){assert(rank[code]>0&&rank[code]<=12);add(code);}uint64_t initial=queue.size();
 uint64_t reached[13]{};for(auto code:queue)reached[rank[code]]++;
 for(size_t head=0;head<queue.size();head++){
  uint32_t code=queue[head],v=code/4;int g=code%4,r=rank[code];uint64_t base=keys[v],key=base|(uint64_t(g)<<50),candidates=0;
  // Each expression is unchanged when its own target bit is toggled. Thus
  // source eligibility is exactly destination sign == derivative sign.
  for(const Test&e:tests){if(e.target==pid[1][2][3])continue;int s=(key>>e.target&1)?1:-1,d=e.sg*((key>>e.a&1)?1:-1);if(e.b>=0)d*=((key>>e.b&1)?1:-1);if(s==d)candidates|=1ull<<e.target;}
  while(candidates){int bit=__builtin_ctzll(candidates);candidates&=candidates-1;uint32_t u=v;int h=g;
   if(bit<50){u=H.find(base^(1ull<<bit));if(u==UINT32_MAX)continue;}else h^=1<<(bit-50);
   if(!(allowed[u]&(1u<<h)))continue;uint32_t pred=4*u+h;if(rank[pred]!=r)continue;if(add(pred))reached[r]++;
  }
  if((head+1)%5000000==0)cerr<<"reverse examined="<<head+1<<" queued="<<queue.size()<<"\n";
 }
 cout<<"Reverse silent closure starts at "<<initial<<" tight target-edge seeds and reaches "<<queue.size()<<" of "<<npositive<<" positive-rank states\n";
 cout<<"reverse reached by rank";for(int r=1;r<=12;r++){uint64_t expected=0;for(int th=0;th<8;th++)expected+=hist[th][r];cout<<' '<<r<<':'<<reached[r]<<'/'<<expected;assert(reached[r]==expected);}cout<<endl;
 assert(queue.size()==npositive);
 ofstream f("augmented_optimal_rank_reverse_witness.bin",ios::binary);f.write((char*)seen.data(),seen.size());assert(f);
 cout<<"PASS every positive-rank state reaches a tight target edge by same-rank silent edges; induction proves exact graph optimality\n";
}
