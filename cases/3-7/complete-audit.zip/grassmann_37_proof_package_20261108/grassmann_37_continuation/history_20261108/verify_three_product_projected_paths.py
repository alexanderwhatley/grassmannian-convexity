#!/usr/bin/env python3
"""Verify stronger-path sign rules by direct oriented products, not bit masks."""
from itertools import combinations, permutations, product
from pathlib import Path
P=list(combinations(range(1,8),3));pid={p:i for i,p in enumerate(P)}
def sg(k,b):return 1 if k>>b&1 else -1
def p(k,a,b,c):
 q=(a,b,c);inversions=sum(q[i]>q[j] for i in range(3) for j in range(i+1,3))
 return (-1 if inversions%2 else 1)*sg(k,pid[tuple(sorted(q))])
def rules(k,g):
 for feat in range(2):
  groups=[(1,2),(3,4),(5,7 if feat else 6)]
  for perm in permutations(range(3)):
   inv=sum(perm[i]>perm[j] for i in range(3) for j in range(i+1,3))
   for flips in product(range(2),repeat=3):
    pairs=[groups[u][::-1] if flips[j] else groups[u] for j,u in enumerate(perm)]
    (a,b),(c,d),(e,f)=pairs
    if p(k,a,b,c)*p(k,a,d,e)!=p(k,a,b,e)*p(k,a,c,d):continue
    if p(k,a,c,e)*p(k,d,e,f)!=p(k,a,e,f)*p(k,c,d,e):continue
    expected=p(k,a,b,d)*p(k,c,e,f);sign=(-1 if (inv+sum(flips))%2 else 1)*(1 if g>>feat&1 else -1)
    if expected!=sign:return False
 return True
root=Path(__file__).resolve().parent
for keep,name,expected in [(0,'g56',184),(1,'g57',173)]:
 drop=1-keep;rows=[tuple(map(int,l.split())) for l in (root/f'{name}_threeprod_common_hidden_path14.txt').read_text().splitlines()]
 assert len(rows)==expected and sum(x[2]==0 for x in rows)==14
 for i,(x,y,bit,move,h) in enumerate(rows):
  assert (x^y)==1<<bit and (not i or rows[i-1][1]==x) and h in (0,1)
  gx=(((x>>(50+keep))&1)<<keep)|(h<<drop);gy=(((y>>(50+keep))&1)<<keep)|(h<<drop)
  assert rules(x,gx) and rules(y,gy)
 print(f'PASS {name}: all {len(rows)} projected edges satisfy all 96 oriented three-product rules on both sides')
