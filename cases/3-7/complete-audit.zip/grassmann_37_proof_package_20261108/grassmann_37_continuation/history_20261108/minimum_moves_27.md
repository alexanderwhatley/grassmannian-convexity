# At least 27 moves for twelve target flips

Every generic `(3,7)` trajectory with 12 changes of `p123` uses **at least 27 positive elementary moves**. This is a lower bound on the number of discrete moves, not on the number of sign changes. The bound combines the proven `(3,7)` pointwise certificate `r(M)<=8+m(M)` with the published rank-two cyclic-word theorem and the elementary terminal theorem.

## A strict `(3,5)` bound away from the alternating chamber

A generic `3`-by-`5` matrix has at most six future target changes; if its maximal minors are not alternating, it has at most five. This follows directly from rank-two duality.

Choose a `2`-by-`5` Gale dual `Q`, meaning `Q M^T=0`, and put `P=Q D R`, where `D_ii=(-1)^i` and `R` reverses the five columns. If `M'=M U_j(t)`, take `Q'=Q U_j(t)^{-T}`. Then
\[
 P'=Q'DR=P U_{5-j}(t),\tag{1}
\]
so positive `3`-by-`5` moves become positive rank-two moves. Complementary-minor duality gives a common nonzero scalar `c` such that
\[
 \det(P_i,P_j)=c\,p_{[5]\setminus\{6-j,6-i\}}(M),\qquad i<j.\tag{2}
\]
In particular, the rank-two target `det(P1,P2)` is a fixed nonzero scalar multiple of `p123(M)` throughout a trajectory. The rank-two cyclic prerank is at most `2(5-2)=6` and decreases at each target sign change. By [Saldanha–Shapiro–Shapiro, Lemma 3.16 and Proposition 3.17](https://arxiv.org/abs/1902.09741), it equals 6 **only** for the totally negative cyclic word, whose pair-minor signs, with its last pair positive, are `(-1)^{i+j+1}`. Equation (2) identifies this word exactly with alternating maximal minors of `M`. Thus a nonalternating initial `M` has rank-two prerank at most 5, proving the strict statement.

`verify_dual_rank2_3x5.py/.log` independently checks (1) and (2) on 40 exact generic matrices, the alternating/negative-word sign correspondence on all 192 necessary Plücker-sign states, and a single integer witness that separates all 12 pairs of same-move active-minor events. The separate `grassmann_37_continuation/new_work/small_3_5_sign_graph.py` checks the stronger pointwise bound `r<=4+m5` on its 192-state, 576-edge over-approximation, but that finite check is not needed below.

## At least two moves at index 5

Suppose a 12-flip trajectory contains at most one move at index 5. Its first five columns evolve autonomously by positive moves except possibly at that one index-5 move; index 6 moves do not affect these columns. Thus the portions before and after the index-5 move are `(3,5)` trajectories with at most six target flips each. With no index-5 move, 12 is impossible. With exactly one, each portion must have exactly six.

At the end of the first portion the first five columns have zero future `(3,5)` rank: a further positive change would extend a six-change trajectory beyond the rank-two upper bound. The all-dimensional zero-future-flips theorem in `zero_future_flips_all_k_n.md` therefore implies that their ten maximal minors all have the same sign. In particular `p123` and `p124` have the same sign. The single index-5 move changes neither of these two minors, so they still have the same sign immediately afterward. Alternating maximal minors require opposite signs for `p123` and `p124`; hence the second portion starts nonalternating and has at most five target changes, a contradiction. This argument is insensitive to how the last first-five minor is normalized after the index-5 move.

## The remaining mandatory moves

There are at least 12 index-3 moves, because no other index changes `p123`. Between any two of those target-changing moves there must be an index-2 or index-4 move: without either, `p124` is constant, and each index-3 move changes `p123` in the same direction. Thus there are at least 11 such separators.

At least one index-1 move is necessary. Otherwise `v1` is fixed; project `v2,...,v7` to the quotient by `Rv1`. Their six-vector rank-two prerank is at most 8, and its target determinant has the same sign changes as `p123`.

At least one index-6 move is necessary. Otherwise the first six columns form an autonomous generic `(3,6)` trajectory and `v6` is fixed. Choose a functional giving at most three sign variations on the initial six columns; such a functional exists by the elementary `m<=n-k` lemma in `elementary_positive_chart_and_global_rank.md`. Append a fixed `v7` sufficiently near `v6` to have the same functional sign, avoiding the finitely many proper planes that would make a recorded triple singular. Then the padded `(3,7)` start has `m<=3`, all recorded seven-column matrices are generic, and its target changes agree with the original ones. The already certified pointwise `(3,7)` bound `r<=8+m` gives at most 11. Hence 12 changes require index 6. This proof uses the existing certificate rather than an additional `(3,6)` theorem.

The five disjoint classes of required moves therefore contribute
\[
 12\ (j=3)+11\ (j=2\text{ or }4)+2\ (j=5)+1\ (j=1)+1\ (j=6)=27.
\]
Genericity concerns only the recorded matrices. Rank-two or terminal-theorem arguments can perturb finitely many move parameters and starting columns if needed to separate intermediate wall events, while preserving every strict recorded sign change.
