// Independent exact classification of rank-12 and m=4 sign states.
// and every move-labeled augmented edge, using only algebraic sign filters.
// Shares the old 50-sign state enumerator/rank file, but does not include
// g_features.hpp, g_tight_search.cpp, the SCC code, or the G-search BFS.
// The old event table and the new six events are read/reconstructed directly.
// Run from this directory, after g_reachable_50_nohalf.bin has been created.
#define main gc37_graph_unused_main
#include "../rebuild_full_graph.cpp"
#undef main

struct Test {int move,target,a,b,sg;};
int main(){
 init();auto dirs=direction_types(true);auto masks=sign_masks();Hash H(1ull<<25);
 vector<uint64_t>keys;keys.reserve(16051200);
 for(auto&w:dirs)for(auto&z:add_axes(w)){uint64_t base=word_key(z);for(auto mask:masks){uint64_t k=base^mask;H.insert(k,keys.size());keys.push_back(k);}}
 uint32_t n=keys.size();assert(n==16051200);
 vector<uint8_t>rank(uint64_t(n)*4);
 ifstream rf("../new_work/augmented_optimal_rank.bin",ios::binary);rf.read((char*)rank.data(),rank.size());assert(rf.gcount()==int64_t(rank.size()));char ch;assert(!rf.read(&ch,1));
 // Compute minimal covector variation independently by the 35 oriented
 // four-circuit tests, and cross-check the Karp cocircuit formula used by
 // the search. Exact computation is needed only when R >= 9.
 struct Circuit {int ids[4];uint64_t bad[16];}; vector<Circuit> circuits;
 for(int a=1;a<=7;a++)for(int b=a+1;b<=7;b++)for(int c=b+1;c<=7;c++)for(int d=c+1;d<=7;d++){
  Circuit C{};C.ids[0]=pid[b][c][d];C.ids[1]=pid[a][c][d];C.ids[2]=pid[a][b][d];C.ids[3]=pid[a][b][c];
  int labs[]={a,b,c,d};for(int signs=0;signs<16;signs++)for(int pat=0;pat<64;pat++){
   int q=signs;for(int i=0;i<4;i++)if(labs[i]<7&&(pat>>(labs[i]-1)&1))q^=1<<i;
   if(q==0||q==15)C.bad[signs]|=1ull<<pat;}
  circuits.push_back(C);
 }
 uint64_t atmost[7]{};
 for(int pat=0;pat<64;pat++){
  int prev=(pat&1)?-1:1,var=0;for(int i=1;i<7;i++){int cur=(i<6&&(pat>>i&1))?-1:1;var+=cur!=prev;prev=cur;}
  for(int q=var;q<7;q++)atmost[q]|=1ull<<pat;
 }
 auto mv_circuit=[&](uint64_t k){uint64_t feasible=~0ull;
  for(const Circuit&C:circuits){int q=0;for(int i=0;i<4;i++)if(k&(1ull<<C.ids[i]))q|=1<<i;feasible&=~C.bad[q^10];}
  assert(feasible);int m=0;while(!(feasible&atmost[m]))m++;assert(m<=4);return m;};
 auto mv_karp=[&](uint64_t k){int largest=0;
  for(int a=1;a<=7;a++)for(int b=a+1;b<=7;b++){
   int prev=0,v=0;for(int i=1;i<=7;i++)if(i!=a&&i!=b){array<int,3>z={a,b,i};sort(z.begin(),z.end());
    int s=(k>>pid[z[0]][z[1]][z[2]]&1)?1:-1;if(i&1)s=-s;if(prev&&prev!=s)v++;prev=s;}
   largest=max(largest,v);
  }return 4-largest;};


 // Independently build the filter from direct product-sign implications
 // and the two exact 3-term identities A5*G67-A6*G57+A7*G56=0
 // and B5*G67-B6*G57+B7*G56=0.  These are only necessary for the proof.
 array<uint8_t,512>qsign{},integer_realized{};
 for(int code=0;code<512;code++){
  int s[9];for(int i=0;i<9;i++)s[i]=(code>>i&1)?1:-1;
  auto forced=[](int a,int b,int want){return a==b||a==want;};
  if(!forced(s[0]*s[3],s[2]*s[1],s[6])||!forced(s[0]*s[5],s[4]*s[1],s[7])||
     !forced(s[2]*s[5],s[4]*s[3],s[8]))continue;
  if(abs(s[0]*s[8]-s[2]*s[7]+s[4]*s[6])==3)continue;
  if(abs(s[1]*s[8]-s[3]*s[7]+s[5]*s[6])==3)continue;
  qsign[code]=1;
 }
 assert(count(qsign.begin(),qsign.end(),1)==192);
 // As a diagnostic, every allowed pattern is realized by an explicit
 // integer triple and no other pattern is produced.
 vector<pair<int,int>>coords;
 for(int a:{-3,-2,-1,1,2,3})for(int b:{-3,-2,-1,1,2,3})coords.emplace_back(a,b);
 for(auto[a,b]:coords)for(auto[c,d]:coords)for(auto[e,f]:coords){
  int g56=a*d-c*b,g57=a*f-e*b,g67=c*f-e*d;if(!g56||!g57||!g67)continue;
  int vals[9]={a,b,c,d,e,f,g56,g57,g67},code=0;for(int i=0;i<9;i++)if(vals[i]>0)code|=1<<i;integer_realized[code]=1;
 }
 assert(integer_realized==qsign);
 auto orient=[&](uint64_t k,int a,int b,int c){
  int inv=(a>b)+(a>c)+(b>c);array<int,3>z={a,b,c};sort(z.begin(),z.end());
  int s=(k>>pid[z[0]][z[1]][z[2]]&1)?1:-1;return inv&1?-s:s;
 };
 auto necessary=[&](uint64_t key,int g){
  const int psign[6]={pid[1][2][5],pid[3][4][5],pid[1][2][6],pid[3][4][6],pid[1][2][7],pid[3][4][7]};
  int code=0;for(int i=0;i<6;i++)if(key>>psign[i]&1)code|=1<<i;
  if(g&1)code|=1<<6;if(g&2)code|=1<<7;if(key>>35&1)code|=1<<8;
  if(!qsign[code])return false;
  // Use all three equivalent bracket expressions for each G.  Whenever
  // the two product signs oppose, their difference has a forced sign.
  for(int i=0;i<2;i++){
   pair<int,int> pp[3]={{1,2},{3,4},{5,i?7:6}};int want=(g>>i&1)?1:-1;
   for(int t=0;t<3;t++){
    auto[a,b]=pp[t];auto[c,d]=pp[(t+1)%3];auto[e,f]=pp[(t+2)%3];
    int A=orient(key,a,b,e)*orient(key,c,d,f),B=orient(key,a,b,f)*orient(key,c,d,e);
    if(A!=B&&A!=want)return false;
   }
  }
  return true;
 };

 vector<thread>threads;uint64_t h12[8]{},m4bases[8]{},m4rank[8][13]{},m4sign[8][13][4]{};
 for(int th=0;th<8;th++)threads.emplace_back([&,th](){
  size_t lo=size_t(n)*th/8,hi=size_t(n)*(th+1)/8;
  for(size_t u=lo;u<hi;u++){
   uint64_t key=keys[u];int m=mv_circuit(key);assert(m==mv_karp(key));
   if(m==4){m4bases[th]++;for(int i=0;i<35;i++){auto p=ps[i];int expected=(p[0]+p[1]+p[2])%2==0;assert(int((key>>i)&1)==expected);}}
   for(int g=0;g<4;g++){
    int r=rank[4*u+g];bool valid=necessary(key,g);
    if(!valid){assert(r==255);continue;}assert(r>=0&&r<=12);
    if(m==4){m4rank[th][r]++;m4sign[th][r][g]++;}
    if(r==12){h12[th]++;assert(m==4&&g==2&&!(key&(1ull<<35)));}
   }
  }
 });for(auto&t:threads)t.join();uint64_t count12=0,countbase=0;for(int t=0;t<8;t++){count12+=h12[t];countbase+=m4bases[t];}
 assert(count12==12&&countbase==12);
 cout<<"PASS 12 rank-12 states, all m=4, with p_ijk=(-1)^(i+j+k), G56<0<G57, and G67<0\n";
 cout<<"PASS 12 m=4 base states; all 35 minor signs alternate\n";
 for(int r=0;r<=12;r++){uint64_t count=0;for(int t=0;t<8;t++)count+=m4rank[t][r];if(!count)continue;
  cout<<"m4 rank="<<r<<" count="<<count<<" G-sign counts";for(int g=0;g<4;g++){uint64_t c=0;for(int t=0;t<8;t++)c+=m4sign[t][r][g];cout<<' '<<g<<':'<<c;}cout<<"\n";
  if(r>10)assert(r==12&&count==12);
 }
}
