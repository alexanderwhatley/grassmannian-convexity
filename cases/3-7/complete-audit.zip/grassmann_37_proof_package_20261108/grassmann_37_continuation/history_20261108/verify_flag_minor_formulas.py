#!/usr/bin/env python3
"""Exact checks for the finite-sweep and exponential flag minors."""
from fractions import Fraction as Q
from itertools import combinations
from math import comb,factorial,prod

def det(a):
 a=[[Q(x) for x in row] for row in a];n=len(a);out=Q(1)
 for j in range(n):
  pivot=next((i for i in range(j,n) if a[i][j]),None)
  if pivot is None:return Q(0)
  if pivot!=j:a[j],a[pivot]=a[pivot],a[j];out=-out
  x=a[j][j];out*=x
  for i in range(j+1,n):
   q=a[i][j]/x
   for h in range(j+1,n):a[i][h]-=q*a[j][h]
 return out
def mul(A,B):
 n=len(A);return [[sum(A[i][h]*B[h][j] for h in range(n)) for j in range(n)] for i in range(n)]
for n in range(2,10):
 I=[[int(i==j) for j in range(n)] for i in range(n)];S=I
 for j in range(n-1,0,-1):
  U=[row[:] for row in I];U[j][j-1]=1;S=mul(S,U)
 assert S==[[int(i>=j) for j in range(n)] for i in range(n)]
 B=I
 for k in range(1,n):
  B=mul(B,S)
  assert B==[[comb(k+i-j-1,k-1) if i>=j else 0 for j in range(n)] for i in range(n)]
print('PASS finite descending-sweep matrix and its k-th power')
checks=0
for n in range(2,10):
 for k in range(1,n):
  for J in combinations(range(1,n+1),k):
   v=prod(J[j]-J[i] for i in range(k) for j in range(i+1,k))
   expdet=det([[Q(1,factorial(i-j)) if i>=j else 0 for j in range(1,k+1)] for i in J])
   sweepdet=det([[comb(k+i-j-1,k-1) if i>=j else 0 for j in range(1,k+1)] for i in J])
   assert expdet==Q(v,prod(factorial(i-1) for i in J))>0
   assert sweepdet==Q(v,prod(factorial(i) for i in range(k)))>0
   checks+=1
print('PASS exponential and k-sweep Vandermonde flag-minor formulas on',checks,'exact index sets')
# Nontrivial 3x7 example: positive target, a negative minor, then two flips.
v=[[Q((-1)**i),Q((-1)**i*i),Q((-1)**i*i*i)] for i in range(1,8)]
def p(a,b,c):
 x,y,z=(v[j-1] for j in (a,b,c));return x[0]*(y[1]*z[2]-y[2]*z[1])-x[1]*(y[0]*z[2]-y[2]*z[0])+x[2]*(y[0]*z[1]-y[1]*z[0])
seq=[p(1,2,3)];assert p(5,6,7)>0 and p(1,2,4)<0
for j,t in [(3,Q(7,10)),(4,Q(3,4)),(3,Q(1))]:
 v[j-1]=[a+t*b for a,b in zip(v[j-1],v[j])]
 assert all(p(*I) for I in combinations(range(1,8),3));assert p(5,6,7)>0;seq.append(p(1,2,3))
assert seq==[Q(2),Q(-11,5),Q(-11,5),Q(4,5)]
print('PASS generic 3x7 example: p123 sequence',','.join(map(str,seq)),'gives two target flips')

# Verify the explicit finite shear word itself, including the sufficient L,
# on generic small integer matrices and every target minor in each matrix.
from random import Random
rng=Random(37021);target_checks=0
for n in range(2,7):
 for k in range(1,n):
  allI=list(combinations(range(1,n+1),k))
  for trial in range(3):
   while True:
    A=[[rng.randint(-5,5) for _ in range(n)] for _ in range(k)]
    minors={I:det([[A[r][j-1] for j in I] for r in range(k)]) for I in allI}
    if all(minors.values()):break
   def coeff(I):return Q(prod(I[j]-I[i] for i in range(k) for j in range(i+1,k)),prod(factorial(i) for i in range(k)))
   for I in allI:
    lead=abs(minors[I])*coeff(I);tail=sum(abs(minors[J])*coeff(J) for J in allI if J!=I)
    ratio=tail/lead;L=ratio.numerator//ratio.denominator+2
    d=[L if i in I else 1 for i in range(1,n+1)]
    V=[[Q(x) for x in row] for row in A]
    for _ in range(k):
     for j in range(n-1,0,-1):
      t=Q(d[j],d[j-1]);assert t>0
      for r in range(k):V[r][j-1]+=t*V[r][j]
    result=det([row[:k] for row in V]);assert result and (result>0)==(minors[I]>0)
    target_checks+=1
print('PASS explicit k-sweep sign targeting, with sufficient integer L, on',target_checks,'generic small examples')
