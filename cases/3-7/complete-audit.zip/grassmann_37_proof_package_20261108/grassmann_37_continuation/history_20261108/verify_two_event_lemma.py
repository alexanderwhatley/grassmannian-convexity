#!/usr/bin/env python3
"""Check exact identities, sign hypotheses, and two abstract witness rows."""
from itertools import combinations
from pathlib import Path
import sympy as s
P=list(combinations(range(1,8),3));pid={p:i for i,p in enumerate(P)}
M=s.Matrix(3,7,lambda i,j:s.Symbol(f'v{i+1}{j+1}'))
def p(a,b,c):return M[:,[a-1,b-1,c-1]].det()
g56=p(1,2,5)*p(3,4,6)-p(1,2,6)*p(3,4,5)
g57=p(1,2,5)*p(3,4,7)-p(1,2,7)*p(3,4,5)
g67=p(1,2,6)*p(3,4,7)-p(1,2,7)*p(3,4,6)
assert s.expand(p(1,2,5)*g67-p(1,2,6)*g57+p(1,2,7)*g56)==0
assert s.expand(g57-p(1,3,4)*p(2,5,7)+p(2,3,4)*p(1,5,7))==0
expect={2:p(1,3,4)*p(3,5,7),4:p(1,2,5)*p(3,5,7),5:g67}
for j in range(1,7):
 d=sum(s.diff(g57,M[i,j-1])*M[i,j] for i in range(3))
 assert s.expand(d-expect.get(j,0))==0
 assert s.expand(sum(s.diff(d,M[i,j-1])*M[i,j] for i in range(3)))==0
print('PASS two exact polynomial identities and all six G57 affine move laws')
V=[[1,1,2],[2,-2,-1],[-1,-2,-1],[2,1,1],[0,2,-1],[1,2,-1],[-2,-1,-2]]
def det(a,b,c):
 x,y,z=(V[i-1] for i in (a,b,c))
 return x[0]*(y[1]*z[2]-y[2]*z[1])-x[1]*(y[0]*z[2]-y[2]*z[0])+x[2]*(y[0]*z[1]-y[1]*z[0])
q={t:det(*t) for t in P};assert all(q.values())
A=q[(1,2,5)];B=q[(1,2,6)];C=q[(1,2,7)]
D=q[(3,4,5)];E=q[(3,4,6)];F=q[(3,4,7)]
G56=A*E-B*D;G57=A*F-C*D;G67=B*F-C*E
assert G56>0 and G57<0 and G67<0
for t in [(1,2,5),(1,2,6),(1,3,4),(1,5,7)]:assert q[t]>0
for t in [(1,2,7),(2,3,4),(3,5,7)]:assert q[t]<0
for i,j,k,l in combinations(range(1,6),4):
 for a,b,c,d in [(i,j,k,l),(i,k,j,l),(i,l,j,k)]:assert det(a,b,6)*det(c,d,7)-det(a,b,7)*det(c,d,6)
print('PASS generic integer matrix satisfies the hypotheses; G56,G57,G67=',G56,G57,G67)
root=Path(__file__).resolve().parent
full=[tuple(map(int,x.split())) for x in (root/'g56_common_hidden_path14.txt').read_text().splitlines()]
window=[tuple(map(int,x.split())) for x in (root/'g56_shortest_nolift_window.txt').read_text().splitlines()]
assert full[106:108]==window and len(window)==2
x,y,z=window[0][0],window[0][1],window[1][1]
assert y==window[1][0] and x^y==1<<50 and y^z==1<<pid[(1,3,4)]
def sign(k,bit):return 1 if k>>bit&1 else -1
assert sign(x,50)==1 and sign(y,50)==-1 and sign(x,pid[(1,3,4)])==sign(y,pid[(1,3,4)])==1 and sign(z,pid[(1,3,4)])==-1
for k in (x,y,z):
 for t in [(1,2,5),(1,5,7)]:assert sign(k,pid[t])==1
 for t in [(2,3,4),(3,5,7)]:assert sign(k,pid[t])==-1
 assert sign(k,35)==-1
for t in [(1,2,6)]:assert sign(x,pid[t])==1
for t in [(1,2,7)]:assert sign(x,pid[t])==-1
print('PASS exact abstract witness rows 107 and 108: G56 +->-, then p134 +->-')

# The dual wall-order obstruction uses G56 rather than G57.
assert s.expand(g56-p(1,2,4)*p(3,5,6)+p(1,2,3)*p(4,5,6))==0
expect56={2:p(1,3,4)*p(3,5,6),4:p(1,2,5)*p(3,5,6),6:g57}
for j in range(1,7):
 d=sum(s.diff(g56,M[i,j-1])*M[i,j] for i in range(3))
 assert s.expand(d-expect56.get(j,0))==0
 assert s.expand(sum(s.diff(d,M[i,j-1])*M[i,j] for i in range(3)))==0
print('PASS cyclic G56 identity and all six affine move laws')
def wall_eval(v):
 def f(a,b,c):
  x,y,z=(v[i-1] for i in (a,b,c))
  return x[0]*(y[1]*z[2]-y[2]*z[1])-x[1]*(y[0]*z[2]-y[2]*z[0])+x[2]*(y[0]*z[1]-y[1]*z[0])
 q={t:f(*t) for t in P}
 v56=q[(1,2,5)]*q[(3,4,6)]-q[(1,2,6)]*q[(3,4,5)]
 v57=q[(1,2,5)]*q[(3,4,7)]-q[(1,2,7)]*q[(3,4,5)]
 for i,j,k,l in combinations(range(1,6),4):
  for a,b,c,d in [(i,j,k,l),(i,k,j,l),(i,l,j,k)]:assert f(a,b,6)*f(c,d,7)-f(a,b,7)*f(c,d,6)
 return q,v56,v57
VA=[[-2,1,-2],[-2,-2,-2],[-2,0,2],[2,1,-2],[4,1,4],[-1,2,2],[0,0,1]]
VB=[[-1,-1,1],[-2,1,-2],[2,-4,6],[2,2,1],[2,-2,1],[1,-1,1],[-1,0,-2]]
qa,a56,a57=wall_eval(VA);qb,b56,b57=wall_eval(VB)
assert qa[(1,2,5)]==0 and all(qa[t] for t in P if t!=(1,2,5))
assert qb[(1,2,3)]==0 and all(qb[t] for t in P if t!=(1,2,3))
assert qa[(1,2,6)]>0 and qa[(3,4,5)]<0 and qa[(1,3,4)]>0 and qa[(3,5,6)]>0 and a57>0 and a56>0
assert qb[(1,2,4)]<0 and qb[(1,2,5)]>0 and qb[(1,3,4)]>0 and qb[(3,5,6)]>0 and b57>0 and b56<0
print('PASS separate exact wall witnesses: G56,G57=',(a56,a57),(b56,b57))
full=[tuple(map(int,x.split())) for x in (root/'g57_common_hidden_path14.txt').read_text().splitlines()]
window=[tuple(map(int,x.split())) for x in (root/'g57_shortest_nolift_window.txt').read_text().splitlines()]
assert full[69:79]==window and len(window)==10
ks=[window[0][0]]+[row[1] for row in window]
assert window[0][2]==pid[(1,2,5)] and sign(ks[0],pid[(1,2,5)])==-1 and all(sign(k,pid[(1,2,5)])==1 for k in ks[1:])
assert window[-1][2]==pid[(1,2,3)] and all(sign(k,pid[(1,2,3)])==1 for k in ks[:-1]) and sign(ks[-1],pid[(1,2,3)])==-1
for k in ks:
 for t in [(1,2,6),(1,3,4),(3,5,6)]:assert sign(k,pid[t])==1
 for t in [(1,2,4),(3,4,5)]:assert sign(k,pid[t])==-1
 assert sign(k,51)==1
print('PASS exact abstract witness rows 70 through 79: p125 -->+, then p123 +->-')

# Each wall is also approached and left by one genuine positive move while
# satisfying the required open signs locally; the two walls are not connected.
from fractions import Fraction as Q
def sides(v,j):
 before=[[Q(x) for x in w] for w in v];after=[[Q(x) for x in w] for w in v]
 for i in range(3):before[j-1][i]-=Q(1,100)*before[j][i];after[j-1][i]+=Q(1,100)*after[j][i]
 return before,after
for v,j,t in [(VA,5,(1,2,5)),(VB,3,(1,2,3))]:
 before,after=sides(v,j);lo,x56,x57=wall_eval(before);hi,y56,y57=wall_eval(after)
 assert all(lo.values()) and all(hi.values()) and x56 and y56 and x57 and y57
 assert (lo[t]<0<hi[t]) if j==5 else (lo[t]>0>hi[t])
 for w in (lo,hi):
  assert w[(1,3,4)]>0 and w[(3,5,6)]>0 and w[(1,2,4)]<0
 assert x57>0 and y57>0
print('PASS each separate wall has exact generic endpoints on a local positive crossing')
