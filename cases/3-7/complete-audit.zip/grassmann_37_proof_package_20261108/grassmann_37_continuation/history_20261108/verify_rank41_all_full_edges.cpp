// Independent direct check of an external 41-sign rank potential.
// Reads ONLY rank_41_F41_F44_F47.bin. No projected edges or SCC data are read.
// Reconstructs the full 50-sign keys, exact feature derivatives and tie witness,
// and independently builds the 816 oriented cubic rules.
#define main gc37_old_main
#include "standalone_data_free_checked.cpp"
#undef main
#include <fstream>
#include <chrono>
struct IndependentRule {uint64_t trigger,value;int tp,vp,feature;};
struct IndependentCubic {
 vector<IndependentRule>rules;
 IndependentCubic(){
  for(int f=0;f<17;f++){
   array<Edge,3>base;
   if(f<15){auto z=flabs[f];base={Edge{z[0],z[1]},Edge{z[2],z[3]},Edge{6,7}};}
   else base={Edge{1,2},Edge{3,4},Edge{5,f==15?6:7}};
   array<int,3>perm={0,1,2};do{
    int inv=(perm[0]>perm[1])+(perm[0]>perm[2])+(perm[1]>perm[2]);
    for(int flips=0;flips<8;flips++){
     Edge e[3]={base[perm[0]],base[perm[1]],base[perm[2]]};
     for(int j=0;j<3;j++)if(flips>>j&1)swap(e[j].first,e[j].second);
     auto[A,B]=e[0];auto[C,D]=e[1];auto[E,F]=e[2];
     auto product=[&](initializer_list<array<int,3>> ls){uint64_t mask=0;int par=0;
      for(auto x:ls){par^=(x[0]>x[1])^(x[0]>x[2])^(x[1]>x[2]);sort(x.begin(),x.end());mask^=1ull<<pid[x[0]][x[1]][x[2]];}
      return pair<uint64_t,int>{mask,par};};
     auto z=product({{A,B,E},{A,C,D},{D,E,F},{A,B,D},{A,E,F},{C,D,E}});
     auto q=product({{A,B,E},{A,C,D},{D,E,F},{A,D,E}});q.second^=(inv+__builtin_popcount(unsigned(flips)))&1;
     rules.push_back({z.first,q.first,z.second,q.second,f});
    }
   }while(next_permutation(perm.begin(),perm.end()));
  }
  assert(rules.size()==816);
  auto less=[](const auto&a,const auto&b){return tie(a.feature,a.trigger,a.tp,a.value,a.vp)<tie(b.feature,b.trigger,b.tp,b.value,b.vp);};
  auto same=[](const auto&a,const auto&b){return tie(a.feature,a.trigger,a.tp,a.value,a.vp)==tie(b.feature,b.trigger,b.tp,b.value,b.vp);};
  sort(rules.begin(),rules.end(),less);rules.erase(unique(rules.begin(),rules.end(),same),rules.end());assert(rules.size()==272);
 }
 unsigned apply(uint64_t k,unsigned mask)const{
  if(!mask)return 0;for(auto r:rules){
   if(__builtin_parityll(k&r.trigger)^r.tp)continue;
   bool signpositive=1^__builtin_parityll(k&r.value)^r.vp;
   if(r.feature<15){if(bool(k>>(35+r.feature)&1)!=signpositive)return 0;}
   else{unsigned positive=r.feature==15?0xA:0xC;mask&=signpositive?positive:(15^positive);if(!mask)return 0;}
  }return mask;
 }
};
void verify_cubic_symbolic(){
 auto f=feature({1,2},{3,4},{5,6});
 auto a=mul(determinant(1,4,5),f);
 auto b=mul(mul(determinant(1,2,5),determinant(1,3,4)),determinant(4,5,6));
 auto c=mul(mul(determinant(1,2,4),determinant(1,5,6)),determinant(3,4,5));
 assert(add(add(a,b,-1),c,-1).empty());
 array<Edge,3>base={Edge{1,2},Edge{3,4},Edge{5,6}};array<int,3>p={0,1,2};int count=0;
 do{int inv=(p[0]>p[1])+(p[0]>p[2])+(p[1]>p[2]);for(int mask=0;mask<8;mask++){
  Edge e[3]={base[p[0]],base[p[1]],base[p[2]]};for(int j=0;j<3;j++)if(mask>>j&1)swap(e[j].first,e[j].second);
  Poly h=feature(e[0],e[1],e[2]);if((inv+__builtin_popcount(unsigned(mask)))&1)h=neg(h);assert(h==f);count++;
 }}while(next_permutation(p.begin(),p.end()));assert(count==48);
 cout<<"PASS symbolic cubic identity and all 48 six-label feature orientations"<<endl;
}
int main(int argc,char**argv){
 assert(argc==2);labels();check_affine_normalization();auto tests=symbolic_events();verify_cubic_symbolic();IndependentCubic cubic;
 cout<<"PASS independently constructed 816 oriented rules (272 distinct)"<<endl;
 auto full=generate_keys();const uint32_t n=full.size();Hash fullhash(1ull<<25);for(uint32_t u=0;u<n;u++)fullhash.insert(full[u],u);
 const uint64_t keep=((1ull<<36)-1)|(1ull<<41)|(1ull<<44)|(1ull<<47);
 vector<uint64_t>proj=full;for(auto&k:proj)k&=keep;sort(proj.begin(),proj.end());proj.erase(unique(proj.begin(),proj.end()),proj.end());
 assert(proj.size()==3378432);Hash projected(1ull<<23);for(uint32_t u=0;u<proj.size();u++)projected.insert(proj[u],u);
 vector<uint8_t>rank(size_t(proj.size())*4);ifstream input(argv[1],ios::binary);assert(input);input.read((char*)rank.data(),rank.size());assert(input.gcount()==int64_t(rank.size()));assert(input.peek()==EOF);
 vector<uint32_t>pindex(n);vector<uint8_t>valid(n);vector<thread>threads;
 for(int th=0;th<8;th++)threads.emplace_back([&,th](){size_t lo=size_t(n)*th/8,hi=size_t(n)*(th+1)/8;
  for(size_t u=lo;u<hi;u++){uint64_t k=full[u];uint32_t p=projected.find(k&keep);assert(p!=UINT32_MAX);pindex[u]=p;
   unsigned mask=0;for(int g=0;g<4;g++)if(gvalid(k,g))mask|=1u<<g;valid[u]=cubic.apply(k,mask);
  }
 });for(auto&t:threads)t.join();threads.clear();
 Variation variation;uint64_t sc[8]{},bc[8]{},gc[8]{},badm[8][5]{},mcount[8][5]{};int maxr[8][5]{};
 for(int th=0;th<8;th++)threads.emplace_back([&,th](){size_t lo=size_t(n)*th/8,hi=size_t(n)*(th+1)/8;
  for(size_t u=lo;u<hi;u++)if(valid[u]){
   uint64_t base=full[u];int m=variation.karp(base);assert(0<=m&&m<=4);
   for(int g=0;g<4;g++)if(valid[u]&(1u<<g)){
    int r=rank[size_t(4)*pindex[u]+g];if(r>12){cerr<<"rank missing/out of range full="<<u<<" g="<<g<<" rank="<<r<<endl;abort();}
    sc[th]++;mcount[th][m]++;maxr[th][m]=max(maxr[th][m],r);badm[th][m]+=r>8+m;
    uint64_t ext=base|(uint64_t(g)<<50);
    for(auto e:tests){int x=signbit(ext,e.target),d=e.e.sg*signbit(ext,e.e.a);if(e.e.b>=0)d*=signbit(ext,e.e.b);if(x==d)continue;
     uint32_t v=u;int h=g;if(e.target<50){v=fullhash.find(base^(1ull<<e.target));if(v==UINT32_MAX||!(valid[v]&(1u<<h)))continue;}
     else{h=g^(1<<(e.target-50));if(!(valid[v]&(1u<<h)))continue;}
     int rr=rank[size_t(4)*pindex[v]+h];if(rr>12||r<rr+int(e.target==0)){
      cerr<<"edge failure full="<<u<<" feature="<<e.target<<" move="<<e.move<<" ranks="<<r<<','<<rr<<endl;abort();
     }
     if(e.target<50)bc[th]++;else gc[th]++;
    }
   }
  }
 });for(auto&t:threads)t.join();
 uint64_t ns=0,nb=0,ng=0;for(int t=0;t<8;t++){ns+=sc[t];nb+=bc[t];ng+=gc[t];}
 assert(ns==22667264&&nb==205457664&&ng==19848192);
 cout<<"PASS 0<=rank<=12 on "<<ns<<" cubic-valid full 52-sign states"<<endl;
 cout<<"PASS direct rank inequalities on "<<nb<<" base and "<<ng<<" G move-labeled edges"<<endl;
 const uint64_t expected_counts[5]={7791872,12102558,2713248,59574,12};
 cout<<"m maxima / rank>8+m full-state counts";for(int m=0;m<5;m++){int mr=0;uint64_t bad=0,tot=0;for(int t=0;t<8;t++){mr=max(mr,maxr[t][m]);bad+=badm[t][m];tot+=mcount[t][m];}assert(mr==8+m&&bad==0&&tot==expected_counts[m]);cout<<' '<<m<<':'<<mr<<'/'<<bad<<'/'<<tot;}cout<<endl;
 cout<<"PASS exact per-m maxima, zero violations, and state counts"<<endl;
}
