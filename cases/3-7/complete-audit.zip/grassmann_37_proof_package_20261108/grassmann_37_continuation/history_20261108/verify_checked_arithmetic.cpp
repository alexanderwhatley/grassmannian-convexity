// Unit tests the checked verifier's signed-arithmetic guards.
#define main checked_full_verifier_not_called
#include "standalone_data_free_checked.cpp"
#undef main
#include <string>
int main(int argc,char**argv){
 string mode=argc>1?argv[1]:"normal";
 int64_t hi=numeric_limits<int64_t>::max(),lo=numeric_limits<int64_t>::min();
 unsigned __int128 all=~static_cast<unsigned __int128>(0);
 __int128 hi128=static_cast<__int128>(all>>1),lo128=-hi128-1;
 if(mode=="add64")return int(add64(hi,1));
 if(mode=="sub64")return int(sub64(lo,1));
 if(mode=="mul64")return int(mul64(hi,2));
 if(mode=="neg64")return int(neg64(lo));
 if(mode=="add128")return int(add128(hi128,1));
 if(mode=="sub128")return int(sub128(lo128,1));
 if(mode=="mul128")return int(mul128(hi128,2));
 assert(add64(hi,0)==hi&&sub64(lo,0)==lo);
 assert(mul64(hi,1)==hi&&neg64(hi)==-hi);
 assert(add128(hi128,0)==hi128&&sub128(lo128,0)==lo128&&mul128(hi128,1)==hi128);
 return 0;
}
