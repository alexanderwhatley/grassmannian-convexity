// A looser 41-sign graph: visible states need a hidden lift, but a visible
// edge needs only visible endpoint states and a derivative sign compatible
// with retained factors. If a derivative uses a forgotten factor, allow it
// either sign. No common forgotten lift is required across that edge.
#define main gc37_old_main
#include "standalone_data_free_checked.cpp"
#undef main
#include <fstream>
int main(int argc,char**argv){
 uint64_t keepmask=(1ull<<36)-1;
 for(int a=1;a<argc;a++){int bit=atoi(argv[a]);assert(bit>=36&&bit<50);keepmask|=1ull<<bit;}
 cout<<"retained feature mask="<<keepmask<<endl;
 labels();auto tests=symbolic_events();auto fullkeys=generate_keys();auto keys=fullkeys;
 for(auto&x:keys)x&=keepmask;sort(keys.begin(),keys.end());keys.erase(unique(keys.begin(),keys.end()),keys.end());
 uint32_t n=keys.size();assert(n==3378432);cout<<"projected base states="<<n<<endl;
 Hash H(n<(1u<<22)?(1u<<23):(1u<<24));for(uint32_t u=0;u<n;u++)H.insert(keys[u],u);
 vector<uint8_t>valid(n);vector<uint32_t>dense(size_t(n)*4,UINT32_MAX),code;
 for(uint32_t u=0;u<n;u++)for(int g=0;g<4;g++)if(gvalid(keys[u],g)){
  valid[u]|=1<<g;dense[4*u+g]=code.size();code.push_back(4*u+g);
 }
 uint32_t N=code.size();assert(N==4960256);cout<<"projected augmented states="<<N<<endl;
 vector<uint32_t>off(N+1),arcs;arcs.reserve(size_t(N)*8);
 for(uint32_t id=0;id<N;id++){
  uint32_t c=code[id],u=c/4;int g=c%4;uint64_t key=keys[u],full=key|(uint64_t(g)<<50),candidate=0;
  for(auto e:tests){
   int bit=e.target;if(bit<50 && !(keepmask>>bit&1))continue;
   auto known=[&](int q){return q<0 || q>=50 || (keepmask>>q&1);};
   if(known(e.e.a)&&known(e.e.b)){
    int s=signbit(full,bit),d=e.e.sg*signbit(full,e.e.a);if(e.e.b>=0)d*=signbit(full,e.e.b);if(s==d)continue;
   }
   candidate|=1ull<<bit;
  }
  while(candidate){int bit=__builtin_ctzll(candidate);candidate&=candidate-1;uint32_t v=u;int h=g;
   if(bit<50){v=H.find(key^(1ull<<bit));if(v==UINT32_MAX||!(valid[v]&(1<<h)))continue;}
   else {h=g^(1<<(bit-50));if(!(valid[v]&(1<<h)))continue;}
   uint32_t dest=dense[4*v+h];assert(dest<N);arcs.push_back(dest|(uint32_t(bit==0)<<31));
  }
  off[id+1]=arcs.size();
 }
 uint32_t E=arcs.size();cout<<"distinct sign-flip edges="<<E<<endl;
 vector<uint32_t>roff(N+1);for(auto x:arcs)roff[(x&0x7fffffffu)+1]++;
 for(uint32_t i=0;i<N;i++)roff[i+1]+=roff[i];vector<uint32_t>cur=roff,rarcs(E);
 for(uint32_t u=0;u<N;u++)for(uint32_t z=off[u];z<off[u+1];z++)rarcs[cur[arcs[z]&0x7fffffffu]++]=u;
 vector<uint32_t>().swap(cur);vector<uint8_t>vis(N),next(N);vector<uint32_t>order,stack;order.reserve(N);
 for(uint32_t root=0;root<N;root++)if(!vis[root]){
  vis[root]=1;stack.push_back(root);while(!stack.empty()){
   uint32_t u=stack.back();if(uint32_t(next[u])<off[u+1]-off[u]){
    uint32_t v=arcs[off[u]+next[u]++]&0x7fffffffu;if(!vis[v]){vis[v]=1;stack.push_back(v);}
   }else{stack.pop_back();order.push_back(u);}
  }
 }
 assert(order.size()==N);vector<uint32_t>comp(N,UINT32_MAX);uint32_t nc=0,largest=0;
 for(size_t z=N;z>0;z--){uint32_t root=order[z-1];if(comp[root]!=UINT32_MAX)continue;
  comp[root]=nc;stack.push_back(root);uint32_t size=0;
  while(!stack.empty()){uint32_t u=stack.back();stack.pop_back();size++;
   for(uint32_t e=roff[u];e<roff[u+1];e++){uint32_t v=rarcs[e];if(comp[v]==UINT32_MAX){comp[v]=nc;stack.push_back(v);}}}
  largest=max(largest,size);nc++;
 }
 uint64_t internal=0;for(uint32_t u=0;u<N;u++)for(uint32_t e=off[u];e<off[u+1];e++)if((arcs[e]>>31)&&comp[u]==comp[arcs[e]&0x7fffffffu])internal++;
 cout<<"SCCs="<<nc<<" largest="<<largest<<" target-edges inside SCC="<<internal<<endl;
 uint32_t base=H.find(625507671825077ull&keepmask);assert(base!=UINT32_MAX);uint32_t seed=dense[4*base+2];assert(seed<N);
 vector<uint32_t>parent(N,UINT32_MAX),queue;parent[seed]=seed;queue.push_back(seed);uint32_t bad=UINT32_MAX;
 for(size_t head=0;head<queue.size()&&bad==UINT32_MAX;head++){
  uint32_t u=queue[head];for(uint32_t e=off[u];e<off[u+1];e++){
   uint32_t x=arcs[e],v=x&0x7fffffffu;if((x>>31)&&comp[u]==comp[v]){bad=u;break;}
   if(parent[v]==UINT32_MAX){parent[v]=u;queue.push_back(v);}
  }
 }
 if(internal){cout<<"target-positive SCC; seed-reachable="<<(bad!=UINT32_MAX)<<endl;return 0;}
 vector<uint32_t>coff(nc+1);for(auto c:comp)coff[c+1]++;for(uint32_t c=0;c<nc;c++)coff[c+1]+=coff[c];vector<uint32_t>fill=coff,members(N);
 for(uint32_t u=0;u<N;u++)members[fill[comp[u]]++]=u;vector<int>rank(nc,0);
 for(uint32_t zz=nc;zz>0;zz--){uint32_t c=zz-1;for(uint32_t i=coff[c];i<coff[c+1];i++){
  uint32_t u=members[i];for(uint32_t e=off[u];e<off[u+1];e++){uint32_t x=arcs[e],v=x&0x7fffffffu,d=comp[v],w=x>>31;
   if(d==c){assert(!w);continue;}assert(d>c);rank[c]=max(rank[c],int(w)+rank[d]);}}
 }
 int mx=*max_element(rank.begin(),rank.end());cout<<"Unfiltered projected maximum="<<mx<<" alternating root="<<rank[comp[seed]]<<" reached="<<queue.size()<<endl;
 const uint64_t want=((1ull<<36)-1)|(1ull<<41)|(1ull<<44)|(1ull<<47);assert(keepmask==want);
 Variation variation;uint64_t bym[5]{},over[5]{};int maxm[5]={};
 for(uint32_t u=0;u<n;u++){int m=variation.karp(keys[u]);assert(0<=m&&m<=4);for(int g=0;g<4;g++)if(valid[u]&(1<<g)){
  uint32_t id=dense[4*u+g];int r=rank[comp[id]];assert(0<=r);bym[m]++;maxm[m]=max(maxm[m],r);over[m]+=r>8+m;
 }}
 for(uint32_t u=0;u<N;u++)for(uint32_t e=off[u];e<off[u+1];e++){
  uint32_t x=arcs[e],v=x&0x7fffffffu,w=x>>31;assert(rank[comp[u]]>=rank[comp[v]]+int(w));
 }
 cout<<"PASS direct rank inequalities on "<<E<<" edges"<<endl;
 cout<<"m maxima and rank>8+m counts";for(int m=0;m<=4;m++)cout<<' '<<m<<':'<<maxm[m]<<'/'<<over[m]<<'/'<<bym[m];cout<<endl;
}
