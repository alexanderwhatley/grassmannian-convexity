# A monotone cyclic prerank for a suffix halfspace

This gives an explicit monotone potential for the previously established suffix-halfspace bound. It is independent of the 50- and 52-sign computations. Its rank-two input is the cyclic-word prerank of Saldanha, Shapiro and Shapiro, [Grassmann convexity and multiplicative Sturm theory, revisited](https://arxiv.org/abs/1902.09741), Definition 3.13, Lemma 3.16 and Proposition 3.17.

## Statement

Let `n>=4`, let `M=(v_1,...,v_n)` be a generic real `3`-by-`n` matrix, and suppose a fixed linear functional `omega` satisfies
\[
 x_i:=\omega(v_i)>0\qquad(2\le i\le n).
\]
Positive moves add a positive multiple of column `j+1` to column `j`. For every finite trajectory with generic recorded matrices, the number of sign changes of `p123` is at most
\[
 2(n-3)+1=2n-5.\tag{1}
\]
If initially `p123` and `p_{n-2,n-1,n}` have the same sign, the bound improves to `2n-6`.

For `n=7` these are the bounds **9** and **8**. The existing exact 37-move example `analytic_agent/sharp_nine_generic_trajectory.json`, independently checked by `analytic_agent/verify_sharp_nine.py`, shows the 9 bound is attained. The result does not by itself give a global bound when no functional is positive on columns `2,...,n`.

## The potential

The suffix remains positive under every positive move. On a chart with `x1!=0`, write `H=ker(omega)` and
\[
 w_i=v_{i+1}-\frac{x_{i+1}}{x_i}v_i\in H,\qquad 1\le i<n.
\]
All these vectors are nonzero, since any three columns of a generic `3`-by-`n` matrix are independent. Choose a fixed orientation of `H` such that `det_H(w_{n-2},w_{n-1})>0`. This can be done throughout the trajectory, because
\[
 p_{i,i+1,i+2}=x_i\det_H(w_i,w_{i+1}),\tag{2}
\]
up to one fixed orientation sign, and the last consecutive three-column minor is invariant under every positive move while `x_{n-2}>0`.

Let `rho` be the rank-two cyclic-word prerank of the `N=n-1` projected vectors, with the last pair positively oriented. The cited rank-two result gives
\[
 0\le\rho\le 2(N-2),\qquad
 \rho\equiv[\det_H(w_1,w_2)<0]\pmod 2,\tag{3}
\]
and says that `rho` is nonincreasing under positive rank-two moves and positive column scalings, dropping by at least one whenever the first pair determinant changes sign. Define
\[
 P(M,\omega)=\rho(w_1,...,w_{n-1})+{\bf1}_{x_1<0}.\tag{4}
\]
At generic states, `P` is a nonnegative integer and
\[
 P\equiv[\operatorname{sgn}p_{123}\ne
           \operatorname{sgn}p_{n-2,n-1,n}]\pmod2.\tag{5}
\]
We show that `P` is nonincreasing along all positive moves and strictly decreases whenever `p123` changes sign. It follows at once that the number of target changes is at most the initial `P`, which is at most `2(n-3)+1`. Equation (5) makes `P` even, hence at most `2n-6`, in the equal-sign case.

## Behavior away from the scalar pole

For a move at index `j>=2`, both `x_j` and `x_{j+1}` are positive. Put `alpha=1+t x_{j+1}/x_j>0`. Direct calculation gives
\[
 w'_{j-1}=\alpha w_{j-1}+t w_j,\qquad
 w'_j=\alpha^{-1}w_j,\tag{6}
\]
with all other projected vectors unchanged. Thus the projected motion is a positive rank-two move, followed by positive scalings. The indicator in (4) does not change. By (2), any target sign change in such a chart is a first projected-pair sign change, so it strictly decreases `P`.

For a move at `j=1`,
\[
 x'_1=x_1+t x_2,\qquad w'_1=\frac{x_1}{x'_1}w_1,\tag{7}
\]
with all other `w_i` fixed. As long as `x1` keeps its sign, (7) is a positive scaling and `P` is constant. Also `p123` is constant during this move, because adding a multiple of its second column to its first leaves its determinant unchanged.

## The cyclic-word reversal lemma

A `j=1` move can cross `x1=0` only from negative to positive, and at most once. On the two sides of such a pole, (7) reverses the first projected direction and leaves all other directions unchanged. We prove directly from the cyclic rank formula that this changes `rho` by exactly `+1` or `-1`.

Place the `N` directed vectors and their negatives as `2N` cyclically ordered labels. Let `delta_i`, `1<=i<N`, be the signed number of label positions in the short arc from `w_i` to `w_{i+1}`; genericity gives `1<=|delta_i|<=N-1`. Split `(delta_1,...,delta_{N-1})` into maximal runs of equal sign. If their absolute lengths are `L_1,...,L_s`, the source's cyclic-word rank is
\[
 \rho=2\sum_{a=1}^s\left\lfloor\frac{L_a}{N}\right\rfloor+s-1.\tag{8}
\]
Reversing only `w1` changes `delta_1` to `-sgn(delta_1)(N-|delta_1|)` and leaves every later step unchanged: it merely exchanges the two antipodal labels of the first vector. Set `q=|delta_1|` and let `S` be the length of the first run among `delta_2,...,delta_{N-1}`. Such a run exists because `N>=3`.

* If `delta_1` initially has the same sign as that run, reversal separates it into a new run, and
\[
 \rho_{after}-\rho_{before}=
 1-2\left(\left\lfloor\frac{S+q}{N}\right\rfloor-
             \left\lfloor\frac SN\right\rfloor\right)\in\{-1,1\}.
\]
* If the signs differ, reversal merges the first step into that run, and
\[
 \rho_{after}-\rho_{before}=
 2\left(\left\lfloor\frac{S+N-q}{N}\right\rfloor-
           \left\lfloor\frac SN\right\rfloor\right)-1\in\{-1,1\}.
\]

At the scalar pole the indicator in (4) decreases by 1, so `P` changes by `-2` or `0`; `p123` does not change. This completes the proof of the prerank claim.

## Degeneracies

The calculation is made first when all projected pair directions are distinct at recorded vertices and no scalar pole occurs at a vertex. For a given finite trajectory, arbitrarily small perturbations of the initial matrix, functional and positive move parameters achieve these generic conditions while retaining strict positivity of `x_2,...,x_n`, strict recorded maximal minors and every recorded `p123` sign. During a `j>=2` move only one projected direction moves, with monotone positive coefficient `t/alpha`; all other directed lines are fixed up to positive scalings. Consequently generic crossings are separated. During a `j=1` move the projected direction is constant on each side of its sole possible scalar pole, where it reverses exactly. Passing to the original trajectory proves the stated finite sign-change bound without assuming its intermediate states are generic.

`python3 grassmann_37_continuation/history_20261108/verify_cyclic_first_reversal.py` checks the reversal and first-deletion identities on every cyclic word for `N=3,...,7`. In particular, for `N=6` the 1,920 words split into 960 upward and 960 downward unit jumps. These finite checks are an audit of the run formula; the proof of the unit jump above holds for all `N>=3`.
