// Build an overapproximation of one U6 shear projected to first-six minor
// signs, retaining a common hidden 50-sign state throughout the entire jump.
// All 50-sign states are reconstructed from scratch; output is a 23,808-word
// uint64_t table in ascending 20-bit first-six-sign order.
#define main gc37_old_main
#include "../../trajectory_search_20261108/standalone_data_free.cpp"
#undef main
#include <fstream>
#include <functional>
int main(){
 labels();auto keys=generate_keys();uint32_t n=keys.size();Hash H(1ull<<25);for(uint32_t u=0;u<n;u++)H.insert(keys[u],u);
 vector<array<int,3>> p6;for(auto p:plabs)if(p[2]<=6)p6.push_back(p);assert(p6.size()==20);
 auto project=[&](uint64_t key){uint32_t z=0;for(int i=0;i<20;i++){auto p=p6[i];z|=((key>>pid[p[0]][p[1]][p[2]])&1)<<i;}return z;};
 vector<uint32_t>states;states.reserve(n);for(uint64_t k:keys)states.push_back(project(k));sort(states.begin(),states.end());states.erase(unique(states.begin(),states.end()),states.end());assert(states.size()==23808);
 vector<int>id(1<<20,-1);for(size_t i=0;i<states.size();i++)id[states[i]]=i;
 vector<vector<int>>groups(1024);vector<int>group(states.size()),loc(states.size());
 for(size_t u=0;u<states.size();u++){
  int g=0,z=0;for(int i=0;i<20;i++)if(p6[i][2]<=5)g|=((states[u]>>i)&1)<<z++;
  assert(z==10);group[u]=g;loc[u]=groups[g].size();groups[g].push_back(u);
 }
 int numgroups=0;for(auto&g:groups)if(!g.empty()){numgroups++;assert(g.size()==62);}assert(numgroups==384);
 vector<uint16_t>projected(n);for(uint32_t u=0;u<n;u++){int x=id[project(keys[u])];assert(x>=0&&x<65535);projected[u]=x;}
 vector<uint64_t>reach(n,0),jump(states.size(),0);vector<uint8_t>status(n,0);uint64_t multiple=0,edges=0,calls=0;
 function<uint64_t(uint32_t,int)>dfs=[&](uint32_t u,int depth)->uint64_t{
  assert(depth<=10);if(status[u]==2)return reach[u];assert(status[u]==0);status[u]=1;calls++;
  uint64_t k=keys[u],out=1ull<<loc[projected[u]];int num=0;
  for(int a=1;a<=5;a++)for(int b=a+1;b<=5;b++){
   int bit=pid[a][b][6],der=pid[a][b][7];if(((k>>bit)^(k>>der))%2==0)continue;
   uint32_t v=H.find(k^(1ull<<bit));if(v==UINT32_MAX)continue;
   assert(group[projected[u]]==group[projected[v]]);out|=dfs(v,depth+1);num++;edges++;
  }
  if(num>1)multiple++;status[u]=2;return reach[u]=out;
 };
 for(uint32_t u=0;u<n;u++){jump[projected[u]]|=dfs(u,0);if((u+1)%4000000==0)cerr<<"processed="<<u+1<<"\n";}
 uint64_t total=0,minc=100,maxc=0;for(uint64_t bits:jump){int m=__builtin_popcountll(bits);total+=m;minc=min(minc,uint64_t(m));maxc=max(maxc,uint64_t(m));}
 cout<<"PASS U6 projected jump relation: states="<<states.size()<<" full="<<n<<" relation_pairs="<<total<<" min="<<minc<<" max="<<maxc<<" full_U6_edges="<<edges<<" multi-outgoing="<<multiple<<" calls="<<calls<<endl;
 ofstream out("u6_jump_projection_le64.bin",ios::binary);out.write((char*)jump.data(),jump.size()*sizeof(uint64_t));assert(out);
}
