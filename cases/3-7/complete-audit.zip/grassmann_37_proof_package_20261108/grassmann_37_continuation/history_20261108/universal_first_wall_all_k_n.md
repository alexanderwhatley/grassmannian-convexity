# The first target wall in the maximal-variation chamber, for all \(k,n\)

Let \(0<k<n\), and let \(M=(v_1,\ldots,v_n)\) have all \(k\times k\) minors nonzero. Define
\[
m(M)=\min_{\ell:\,\ell(v_i)\ne0\ \forall i}
 \operatorname{var}(\ell(v_1),\ldots,\ell(v_n)).
\]
Suppose \(m(M)=n-k\). Equivalently, after reorienting column \(i\) by \((-1)^i\) and, if necessary, changing the left orientation, every maximal minor is positive. Then the single positive move at index \(k\),
\[
v_k\longmapsto v_k+t v_{k+1},
\]
has the following properties:

1. The first maximal minor to vanish is \(p_{1,\ldots,k}\), strictly before every other affected maximal minor.
2. Immediately after that wall, only \(p_{1,\ldots,k}\) has changed sign, and the minimum variation is \(n-k-1\).

This is a statement about maximal-minor walls. Other polynomial features, if tracked, may vanish before or at the same time. It does not claim any particular number of subsequent target crossings.

## Proof of the first wall

Write \(w_i=(-1)^i v_i\), with all increasing maximal minors \(\Delta\) positive. The move is \(w_k\mapsto w_k-tw_{k+1}\). An affected minor has the form
\[
\Delta_{I\cup\{k\}}-t\Delta_{I\cup\{k+1\}},
\qquad |I|=k-1,\quad I\cap\{k,k+1\}=\varnothing.
\]
Its positive zero time is
\(r(I)=\Delta_{I\cup\{k\}}/\Delta_{I\cup\{k+1\}}\). We show that the unique minimum is achieved at \(I_0=\{1,\ldots,k-1\}\).

For \(k\ge2\), if \(I\ne I_0\), select \(a\in I_0\setminus I\) and \(b\in I\setminus I_0\). Since \(I\) excludes \(k,k+1\), necessarily \(a<k<k+1<b\). Put \(S=I\setminus\{b\}\). The Plücker relation, with each displayed subset written in increasing order, is
\[
\begin{aligned}
&\Delta_{S\cup\{a,k+1\}}\Delta_{S\cup\{k,b\}}
 -\Delta_{S\cup\{a,k\}}\Delta_{S\cup\{k+1,b\}}\\
&\hspace{3em}=\Delta_{S\cup\{a,b\}}\Delta_{S\cup\{k,k+1\}}>0.
\end{aligned}\tag{1}
\]
The orientation in (1) remains correct even when elements of \(S\) lie between \(a,k,k+1,b\). To see this, write \(S\) increasingly and temporarily append each pair \(x<y\) after it. Sorting that minor contributes \((-1)^{N_S(x)+N_S(y)}\), where \(N_S(x)=|\{s\in S:s>x\}|\). In each of the three products in the usual Plücker relation, the same four indices occur once, so the product of sorting signs is identical in all three terms. Thus (1) has the displayed signs for increasing minors.

All factors are positive, so \(r(I)>r(S\cup\{a\})\). Repeating this replacement reaches \(I_0\), proving the strict minimum. For \(k=1\) there is only one affected minor, so the claim is immediate.

## Minimum variation after the crossing

The generic Karp sign-variation formula is
\[
m(M)=n-k-\max_{|J|=k-1}\operatorname{var}
 \bigl(((-1)^i p_{J\cup\{i\}})_{i\notin J}\bigr),\tag{2}
\]
where the entries are ordered by \(i\) and each minor is written in increasing index order. The hypothesis \(m=n-k\) says that every sequence in (2) is constant. Once only \(p_{[k]}\) flips, a sequence changes precisely when \(J\subset[k]\); then the changed entry is the first entry, because the one index of \([k]\setminus J\) precedes every index outside \([k]\). Its variation is exactly one. Other sequences remain constant, so the maximum is one and \(m=n-k-1\).

For the equivalence in the opening sentence, the constant sequences in (2) imply that all signed minors \((-1)^{\sum I}p_I\) have the same sign: any two \(k\)-subsets can be joined by exchanges of one index. Alternating column reorientation therefore makes all minors have one common sign, which a left orientation change makes positive. The converse is immediate from (2).

The \((3,7)\) specialization, with all ten affected ratios and an exact sharp 11-crossing \(m=3\) suffix, is in `universal_m4_first_wall.md`. Formula (1) is the ordinary three-term Plücker relation; formula (2) is the external sign-variation theorem. This note makes no claim that the universal first crossing preserves the maximal possible number of real future crossings.

`python3 verify_general_first_wall.py` independently checks 191 ordered Plücker identities on exact integer matrices, 120 positive-plane wall ratios, and the post-flip sign sequences for 27 small \((k,n)\) pairs. These tests illustrate the orientation conventions; the proof above is not limited to those cases.
