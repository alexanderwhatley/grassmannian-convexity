#pragma once
// Necessary sign tests from p_ade F_ab,cd^ef = p_abe p_acd p_def + p_abd p_aef p_cde.
// Compile all 48 orientations of each of 17 tracked six-index features.
struct CubicRule {uint64_t x,z;int px,pz,feature;};
struct CubicFilter {
 vector<CubicRule>rules;
 CubicFilter(){
  for(int target=0;target<17;target++){
   array<pair<int,int>,3> groups;
   if(target<15){auto f=flabs[target];groups={pair<int,int>{f[0],f[1]},{f[2],f[3]},{6,7}};}
   else groups={pair<int,int>{1,2},{3,4},{5,target==15?6:7}};
   array<int,3>perm={0,1,2};
   do{int ip=(perm[0]>perm[1])+(perm[0]>perm[2])+(perm[1]>perm[2]);
    for(int flip=0;flip<8;flip++){
     int v[6];for(int j=0;j<3;j++){auto[a,b]=groups[perm[j]];if(flip>>j&1)swap(a,b);v[2*j]=a;v[2*j+1]=b;}
     auto [a,b,c,d,e,f]=array<int,6>{v[0],v[1],v[2],v[3],v[4],v[5]};
     auto X=[&](initializer_list<array<int,3>> minor){uint64_t bits=0;int parity=0;
      for(auto z:minor){parity^=(z[0]>z[1])^(z[0]>z[2])^(z[1]>z[2]);sort(z.begin(),z.end());bits^=1ull<<pid[z[0]][z[1]][z[2]];}
      return pair<uint64_t,int>{bits,parity};};
     auto x=X({{a,b,e},{a,c,d},{d,e,f},{a,b,d},{a,e,f},{c,d,e}});
     auto z=X({{a,b,e},{a,c,d},{d,e,f},{a,d,e}});z.second^=(ip+__builtin_popcount(unsigned(flip)))&1;
     rules.push_back({x.first,z.first,x.second,z.second,target});
    }
   }while(next_permutation(perm.begin(),perm.end()));
  }
  auto order=[](const auto&a,const auto&b){return tie(a.feature,a.x,a.px,a.z,a.pz)<tie(b.feature,b.x,b.px,b.z,b.pz);};
  auto equal=[](const auto&a,const auto&b){return tie(a.feature,a.x,a.px,a.z,a.pz)==tie(b.feature,b.x,b.px,b.z,b.pz);};
  sort(rules.begin(),rules.end(),order);rules.erase(unique(rules.begin(),rules.end(),equal),rules.end());assert(rules.size()==272);
 }
 unsigned apply(uint64_t key,unsigned mask)const{
  for(const auto&r:rules){
   if(__builtin_parityll(key&r.x)^r.px)continue;bool positive=1^__builtin_parityll(key&r.z)^r.pz;
   if(r.feature<15){if(bool(key>>(35+r.feature)&1)!=positive)return 0;}
   else{unsigned posmask=r.feature==15?0xA:0xC;mask &= positive?posmask:(15^posmask);if(!mask)return 0;}
  }return mask;
 }
};
