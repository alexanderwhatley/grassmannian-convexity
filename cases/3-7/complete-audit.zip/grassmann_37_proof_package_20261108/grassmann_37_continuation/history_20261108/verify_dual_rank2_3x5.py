#!/usr/bin/env python3
"""Exact orientation and generic-event audits for the 3x5 rank-two duality."""
import itertools
import random
import sympy as s
from collections import Counter

n=5
subs=list(itertools.combinations(range(1,n+1),3))
def shear(j,t):
 U=s.eye(n);U[j,j-1]=t;return U
D=s.diag(*[(-1)**i for i in range(1,n+1)])
R=s.zeros(n)
for i in range(n):R[i,n-1-i]=1
rng=random.Random(3504)
checks=0
while checks<40:
 M=s.Matrix(3,n,lambda i,j:rng.randrange(-12,13))
 vals={I:M[:,[a-1 for a in I]].det() for I in subs}
 if not all(vals.values()):continue
 Q=s.Matrix.hstack(*M.nullspace()).T
 assert Q.shape==(2,5) and Q*M.T==s.zeros(2,3)
 P=Q*D*R
 factors=[]
 for i,j in itertools.combinations(range(1,6),2):
  remain=tuple(a for a in range(1,6) if a not in (6-j,6-i))
  factors.append(s.cancel(P[:,[i-1,j-1]].det()/vals[remain]))
 assert len(set(factors))==1 and factors[0]!=0
 for j in range(1,5):
  M1=M*shear(j,2);Q1=Q*shear(j,2).inv().T
  assert Q1*M1.T==s.zeros(2,3)
  assert Q1*D*R==P*shear(5-j,2)
 checks+=1
print('PASS Gale dual and reversed positive shear identities:',checks,'generic matrices')

Psubs=list(itertools.combinations(range(1,6),3));index={p:i for i,p in enumerate(Psubs)}
def oriented(key,a,b,c):
 seq=(a,b,c);invs=sum(seq[i]>seq[j] for i in range(3) for j in range(i+1,3))
 return (-1 if invs&1 else 1)*(1 if key>>index[tuple(sorted(seq))]&1 else -1)
def okay(key):
 if not key>>index[(3,4,5)]&1:return False
 for z in range(1,6):
  a,b,c,d=[j for j in range(1,6) if j!=z]
  v=[oriented(key,z,a,b)*oriented(key,z,c,d),-oriented(key,z,a,c)*oriented(key,z,b,d),oriented(key,z,a,d)*oriented(key,z,b,c)]
  if abs(sum(v))==3:return False
 return True
states=[key for key in range(1<<10) if okay(key)];assert len(states)==192
for key in states:
 alt=all((1 if key>>index[I]&1 else -1)==(-1)**sum(I) for I in Psubs)
 pplus={}
 for i,j in itertools.combinations(range(1,6),2):
  rest=tuple(a for a in range(1,6) if a not in (6-j,6-i))
  pplus[i,j]=1 if key>>index[rest]&1 else -1
 negword=all(pplus[i,j]==(-1)**(i+j+1) for i,j in pplus)
 assert alt==negword
print('PASS alternating <-> totally-negative dual on all',len(states),'necessary sign states')

# One exact witness separates every pair of simultaneously active minor roots.
v=[[19,16,2],[0,-3,0],[-2,19,9],[4,-6,5],[9,-6,-3]]
def det(a,b,c):return a[0]*(b[1]*c[2]-b[2]*c[1])-a[1]*(b[0]*c[2]-b[2]*c[0])+a[2]*(b[0]*c[1]-b[1]*c[0])
p=[det(*(v[a-1] for a in I)) for I in subs]
assert all(p)
ct=0
for j in range(1,5):
 v1=[a[:] for a in v];v1[j-1]=[x+y for x,y in zip(v[j-1],v[j])]
 p1=[det(*(v1[a-1] for a in I)) for I in subs]
 active=[i for i,I in enumerate(subs) if j in I and j+1 not in I]
 d=[p1[i]-p[i] for i in range(len(p))]
 assert all(d[i] for i in active)
 for i,h in itertools.combinations(active,2):assert p[i]*d[h]-p[h]*d[i]!=0;ct+=1
print('PASS exact nonzero resultant witness for',ct,'active-event pairs')
