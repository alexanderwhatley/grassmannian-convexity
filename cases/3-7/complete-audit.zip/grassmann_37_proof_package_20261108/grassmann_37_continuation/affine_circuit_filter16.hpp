#pragma once
// 16-circuit exact strict-sign filter. Bit ordering matches affine_circuit_filter.hpp.
static constexpr unsigned short gc37_small_denominator_masks[] = {15,15,15,23,23,23,27,27,27,29,29,29,30,30,30};
static constexpr unsigned short gc37_small_plus[] = {65,16385,514,2,4,1028,8200,16,2080,4160,17,8737,4106,66,16396,10308};
static constexpr unsigned short gc37_small_minus[] = {8,2048,16,8448,4128,128,1024,16512,256,512,5376,128,2176,17440,768,16};
inline bool gc37_pass_circuits16(unsigned x_positive, unsigned f_positive) {
  unsigned q=0;
  for (unsigned i=0;i<15;++i) {
    unsigned negative=((~x_positive)&31u)&gc37_small_denominator_masks[i];
    unsigned bit=((f_positive>>i)&1u)^(__builtin_popcount(negative)&1u);
    q|=(bit<<i);
  }
  for (unsigned i=0;i<16;++i) {
    unsigned p=gc37_small_plus[i], m=gc37_small_minus[i];
    unsigned s=q&(p|m); if (s==p || s==m) return false;
  }
  return true;
}
