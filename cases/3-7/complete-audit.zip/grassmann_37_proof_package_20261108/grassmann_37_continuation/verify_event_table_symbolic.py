#!/usr/bin/env python3
"""Symbolically verify all event derivatives for features 2,3,7,8.

Run the graph program with extra2 extra3 extra7 extra8 eventdump first. This script
independently differentiates the actual determinant polynomials; it does not
use random samples.
"""
from itertools import combinations
from pathlib import Path
import sympy as s

triples=list(combinations(range(1,8),3))
flab=[(1,2,3,4),(1,3,2,4),(1,4,2,3),(1,2,3,5),(1,3,2,5),(1,5,2,3),
      (1,2,4,5),(1,4,2,5),(1,5,2,4),(1,3,4,5),(1,4,3,5),(1,5,3,4),
      (2,3,4,5),(2,4,3,5),(2,5,3,4)]
extras=[((2,4),(3,6),(5,7)),((2,4),(3,7),(5,6)),((2,6),(3,5),(4,7)),((2,6),(3,7),(4,5))]
symbols=s.symbols('x0:21');v=[symbols[3*i:3*i+3] for i in range(7)]
def det(a,b,c):return a[0]*(b[1]*c[2]-b[2]*c[1])-a[1]*(b[0]*c[2]-b[2]*c[0])+a[2]*(b[0]*c[1]-b[1]*c[0])
def p(a,b,c):return det(v[a-1],v[b-1],v[c-1])
def feature(ab,cd,ef):
 a,b=ab;c,d=cd;e,f=ef
 return s.expand(p(a,b,e)*p(c,d,f)-p(a,b,f)*p(c,d,e))
values=[s.expand(p(*x)) for x in triples]+[feature((a,b),(c,d),(6,7)) for a,b,c,d in flab]
values += [feature(*p) for p in extras]
events={}
for line in Path('event_table.txt').read_text().splitlines():
 j,target,a,b,sign=map(int,line.split());assert (j,target) not in events;events[j,target]=(a,b,sign)
for j in range(1,7):
 for target,poly in enumerate(values):
  derivative=s.expand(sum(s.diff(poly,v[j-1][k])*v[j][k] for k in range(3)))
  if (j,target) not in events:assert derivative==0,(j,target);continue
  a,b,sign=events[j,target]
  expected=sign*values[a]*(1 if b<0 else values[b])
  assert s.expand(derivative-expected)==0,(j,target)
print('PASS all',len(events),'event derivative identities and all inactive events, symbolically')
