#!/usr/bin/env bash
set -euo pipefail

root="$(cd -- "$(dirname -- "$0")" && pwd)"
base="$root/grassmann_37_continuation"
build_dir="$(mktemp -d)"
trap 'rm -rf -- "$build_dir"' EXIT
cxx="${CXX:-c++}"

cd "$root"
sha256sum --check certificate_hashes.sha256
python3 examples/verify_sharp_examples.py
python3 m1_analytic_20261108/audit_neville_lower12_independent.py
python3 trajectory_search_20261108/verify_circuit_filter_necessity.py

cd "$base"
python3 verify_feature_classification.py
python3 new_work/audit_old_affine.py
python3 new_work/audit_affine_sign_formulas.py
python3 new_work/audit_g_symbolic_independent.py
python3 new_work/audit_52_sign_ties.py
python3 new_work/audit_circuit_header.py
python3 history_20261108/audit_compiled_16_filters.py
python3 history_20261108/verify_two_event_lemma.py
python3 history_20261108/verify_flag_minor_formulas.py
python3 history_20261108/verify_general_first_wall.py
python3 history_20261108/verify_positive_cell_jacobian.py
python3 history_20261108/verify_general_rectangular_chart.py
python3 history_20261108/verify_elementary_positive_chart.py
python3 history_20261108/check_elementary_rectangular_chart.py
python3 history_20261108/check_rectangular_inverse_rational.py
python3 history_20261108/verify_cyclic_first_reversal.py
python3 history_20261108/verify_human_potential_obstructions.py
python3 history_20261108/verify_dual_rank2_3x5.py
python3 history_20261108/verify_minimum_28_independent.py
python3 "$root/trajectory_search_20261108/verify_3x6_separation.py"
"$cxx" -O3 -std=c++17 -pthread history_20261108/verify_3x6_runs_independent.cpp -o "$build_dir/verify_3x6_runs"
"$build_dir/verify_3x6_runs"
python3 new_work/verify_neville_lower12.py
python3 new_work/small_3_5_sign_graph.py

cd "$base/new_work"
"$cxx" -O3 -std=c++17 -pthread audit_directions_gp.cpp -o "$build_dir/audit_directions_gp"
"$build_dir/audit_directions_gp"
"$cxx" -O3 -std=c++17 -pthread audit_50_generator_independent.cpp -o "$build_dir/audit_50_generator_independent"
"$build_dir/audit_50_generator_independent"
"$cxx" -O3 -std=c++17 -pthread check_q_actual_events.cpp -o "$build_dir/check_q_actual_events"
"$build_dir/check_q_actual_events"
"$cxx" -O3 -std=c++17 -pthread analyze_three_product_rules.cpp -o "$build_dir/analyze_three_product_rules"
"$build_dir/analyze_three_product_rules"
python3 verify_scalar_four_sample.py
"$cxx" -O3 -std=c++17 -pthread lookup_scalar_four.cpp -o "$build_dir/lookup_scalar_four"
"$build_dir/lookup_scalar_four"

cd "$base/history_20261108"
"$cxx" -O3 -std=c++17 -pthread verify_g_pointwise_intrinsic.cpp -o "$build_dir/verify_g_pointwise_intrinsic"
"$build_dir/verify_g_pointwise_intrinsic"
"$cxx" -O3 -std=c++17 -pthread verify_h12_classification.cpp -o "$build_dir/verify_h12_classification"
"$build_dir/verify_h12_classification"
"$cxx" -O3 -std=c++17 -pthread verify_projected_51_common_path.cpp -o "$build_dir/verify_projected_51_common_path"
"$build_dir/verify_projected_51_common_path" g56
"$build_dir/verify_projected_51_common_path" g57

cd "$root/trajectory_search_20261108"
python3 verify_positive_cell_factorization.py
python3 "$base/new_work/verify_compact_witness.py" neville_105_simple.json
python3 verify_constructed_12.py exact_construct_simple_117.json
python3 "$base/new_work/verify_compact_witness.py" neville_43_six_digit.json
python3 verify_constructed_12.py exact_construct_simple_55.json
python3 "$base/new_work/verify_compact_witness.py" witness_29_simplified.json
python3 "$base/new_work/verify_compact_witness.py" "$base/new_work/witness_29_integer.json"
python3 "$base/new_work/verify_compact_witness.py" witness_28_simplified.json
python3 "$base/new_work/verify_compact_witness.py" witness_28_integer.json
python3 "$base/new_work/verify_compact_witness.py" witness_28_variant_2507_integer.json
python3 "$base/new_work/verify_compact_witness.py" torus_2400_6plus.json
python3 "$base/new_work/verify_compact_witness.py" torus_1152_6plus.json
python3 "$base/new_work/verify_compact_witness.py" moment_29_simplified.json
python3 verify_at_most_one_j1_two_j5.py
python3 verify_constructed_12.py exact_construct_simple_41.json
python3 verify_constructed_12.py exact_construct_simple_40.json
python3 exact_ift_construct_rational.py matrix_simple.json \
  witness_28_simplified.json "$build_dir/constructed.json"
python3 verify_constructed_12.py "$build_dir/constructed.json"
for file in exact_ift_12_*.json; do
  python3 verify_constructed_12.py "$file" > "$build_dir/constructed_replay.log"
done
printf 'PASS exact independently replayed rational constructions for all included starts\n'
for file in moment_curve_12_compact_*.json; do
  tag="${file##*_}"
  tag="${tag%.json}"
  python3 verify_one_moment_curve_12.py "$tag" "$file" > "$build_dir/moment_$tag.log"
done
printf 'PASS exact 12-crossing moment-curve examples in all 12 extremal sign chambers\n'
"$cxx" -O3 -std=c++17 -pthread verify_variation_rank_all_edges.cpp -o "$build_dir/verify_variation_rank_all_edges"
"$build_dir/verify_variation_rank_all_edges"
"$cxx" -O3 -std=c++17 -pthread standalone_q_verifier.cpp -o "$build_dir/standalone_q_verifier"
"$build_dir/standalone_q_verifier"
"$cxx" -O3 -std=c++17 -pthread standalone_s_one_array.cpp -o "$build_dir/standalone_s_one_array"
"$build_dir/standalone_s_one_array"
"$cxx" -O3 -std=c++17 -pthread standalone_data_free.cpp -o "$build_dir/standalone_data_free"
mkdir "$build_dir/empty"
cd "$build_dir/empty"
"$build_dir/standalone_data_free"
"$cxx" -O3 -std=c++17 -pthread "$base/history_20261108/standalone_data_free_checked.cpp" -o "$build_dir/standalone_data_free_checked"
"$build_dir/standalone_data_free_checked"

cd "$root/m1_analytic_20261108"
python3 audit_positive_cell_elimination.py
python3 verify_finite_backwards_extension.py
python3 check_ideal_shear_lemma.py
python3 verify_rank4_residual_independent.py
python3 verify_sample289_case.py
python3 verify_28_witness_direct.py
python3 verify_28_witness_direct.py ../trajectory_search_20261108/witness_28_variant_2507_integer.json
"$cxx" -O3 -std=c++17 -pthread verify_3x6_one_three_rank.cpp -o "$build_dir/verify_3x6_one_three_rank"
"$build_dir/verify_3x6_one_three_rank"
"$cxx" -O3 -std=c++17 -pthread check_rank3_sign_ideal.cpp -o "$build_dir/check_rank3_sign_ideal"
"$build_dir/check_rank3_sign_ideal"
"$cxx" -O3 -std=c++17 -pthread analyze_pencil_lower_bound.cpp -o "$build_dir/analyze_pencil_lower_bound"
"$build_dir/analyze_pencil_lower_bound"
python3 verify_plucker_sign_identities.py
python3 verify_universal_two_flip_example.py
python3 verify_three_product_sign_rule.py
python3 verify_h12_moment_examples.py
"$cxx" -O3 -std=c++17 -pthread verify_h12_moment_lookup.cpp -o "$build_dir/verify_h12_moment_lookup"
"$build_dir/verify_h12_moment_lookup"
python3 build_lower12_vertex_keys.py
"$cxx" -O3 -std=c++17 -pthread verify_lower12_saturates_preranks.cpp -o "$build_dir/verify_lower12_saturates_preranks"
"$build_dir/verify_lower12_saturates_preranks"
"$cxx" -O3 -std=c++17 -pthread verify_refined_rank_8_plus_m.cpp -o "$build_dir/verify_refined_rank_8_plus_m"
"$build_dir/verify_refined_rank_8_plus_m"

printf '\nAll certificate checks passed.\n'
