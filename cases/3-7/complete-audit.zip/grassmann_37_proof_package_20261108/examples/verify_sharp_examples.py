#!/usr/bin/env python3
"""Check sharp examples for m=0,1,2,3,4 by exact matrix arithmetic.

This is separate from the upper-bound certificate.  Each file contains one
initial 3x7 matrix and a word of positive rational shears.  Every vertex is
checked for 35 nonzero maximal minors, and the target crossings are counted.
The initial m is independently obtained from four-column circuit signs.
"""
from fractions import Fraction as Q
from itertools import combinations
from pathlib import Path
import json
import sys
sys.set_int_max_str_digits(0)

here=Path(__file__).resolve().parent
triples=list(combinations(range(7),3))
quadruples=list(combinations(range(7),4))
def det(a,b,c):
    return (a[0]*(b[1]*c[2]-b[2]*c[1])
            -a[1]*(b[0]*c[2]-b[2]*c[0])
            +a[2]*(b[0]*c[1]-b[1]*c[0]))
def allminors(v):
    p={I:det(*(v[i] for i in I)) for I in triples}
    assert all(p.values())
    return p
def minvariation(p):
    best=7
    for pattern in range(64):
        signs=[-1 if pattern>>i&1 else 1 for i in range(6)]+[1]
        for a,b,c,d in quadruples:
            z=(signs[a]*p[b,c,d],-signs[b]*p[a,c,d],
               signs[c]*p[a,b,d],-signs[d]*p[a,b,c])
            if all(t>0 for t in z) or all(t<0 for t in z):
                break
        else:
            best=min(best,sum(x!=y for x,y in zip(signs,signs[1:])))
    assert 0<=best<=4
    return best

for m in range(5):
    z=json.loads((here/f'm{m}_sharp.json').read_text())
    assert z['expected_variation']==m and z['expected_crossings']==8+m
    v=[[Q(x) for x in col] for col in z['initial_columns']]
    p=allminors(v);assert minvariation(p)==m
    sign=(p[0,1,2]>0)-(p[0,1,2]<0);flips=[]
    for step,(j,t) in enumerate(z['moves'],1):
        j-=1;t=Q(t);assert 0<=j<6 and t>0
        v[j]=[x+t*y for x,y in zip(v[j],v[j+1])]
        p=allminors(v)
        new=(p[0,1,2]>0)-(p[0,1,2]<0)
        if new!=sign:flips.append(step)
        sign=new
    assert len(flips)==8+m
    print(f'PASS m={m}, {len(z["moves"])} positive moves, {len(flips)} target crossings; all vertices generic')
